-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2020 at 06:57 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `itour_travelworl`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_notification`
--

CREATE TABLE IF NOT EXISTS `admin_notification` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `click_count` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `airline_master`
--

CREATE TABLE IF NOT EXISTS `airline_master` (
  `airline_id` int(11) NOT NULL,
  `airline_code` varchar(100) NOT NULL,
  `airline_name` varchar(200) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  PRIMARY KEY (`airline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `airline_master`
--

INSERT INTO `airline_master` (`airline_id`, `airline_code`, `airline_name`, `active_flag`) VALUES
(1, '098', 'Air India', 'Active'),
(2, '508', 'Jet Airways', 'Active'),
(3, '312', 'IndiGo', 'Active'),
(4, '098', 'Air India Express', 'Active'),
(5, '775', 'SpiceJet', 'Active'),
(6, 'G8', 'GoAir', 'Active'),
(7, '091', 'AirAsia India', 'Active'),
(8, '228', 'Vistara', 'Active'),
(9, 'LLR ', 'Alliance Air', 'Active'),
(10, '829', 'Bangkok Airways', 'Active'),
(11, '508', 'Jet Asia Airways', 'Active'),
(12, '895', 'Air China', 'Active'),
(13, '898', 'Beijing Capital Airlines', 'Active'),
(14, '781', 'China Eastern Airlines', 'Active'),
(15, '590', 'Bassaka Air', 'Active'),
(16, '188', 'Cambodia Angkor Air', 'Active'),
(17, '043', 'Cathay Dragon', 'Active'),
(18, '160', 'Cathay Pacific', 'Active'),
(19, '851', 'Hong Kong Airlines ', 'Active'),
(20, '126', 'Airfast Indonesia', 'Active'),
(21, '210', 'Aviastar', 'Active'),
(22, '938', 'Batik Air', 'Active'),
(23, 'AJX', 'Air Japan', 'Active'),
(24, 'WAJ', 'AirAsia Japan', 'Active'),
(25, '918', 'Firefly', 'Active'),
(26, '887', 'Air Bagan', 'Active'),
(27, '314', 'Air KBZ', 'Active'),
(28, 'BHA', 'Buddha Air', 'Active'),
(29, '375', 'Jetstar Asia Airways', 'Active'),
(30, '668', 'Scoot', 'Active'),
(31, ' 629', 'SilkAir', 'Active'),
(32, '603', 'SriLankan Airlines', 'Active'),
(33, '514', 'Air Arabia', 'Active'),
(34, '176', 'Emirates', 'Active'),
(35, '607', 'Etihad Airways', 'Active'),
(36, '141', 'Flydubai', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `airport_master`
--

CREATE TABLE IF NOT EXISTS `airport_master` (
  `airport_id` int(100) NOT NULL,
  `city_id` int(50) NOT NULL,
  `airport_name` varchar(100) NOT NULL,
  `airport_code` varchar(50) NOT NULL,
  `flag` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`airport_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `airport_master`
--

INSERT INTO `airport_master` (`airport_id`, `city_id`, `airport_name`, `airport_code`, `flag`, `created_at`) VALUES
(1, 346, 'Veer Savarkar International Airport', 'Ixy', 'Active', '2009-03-18 12:12:00'),
(2, 366, 'Vijayawada International Airport', 'VGA', 'Active', '2009-03-18 12:12:00'),
(3, 12, 'Tirupati International Airport', 'TIR', 'Active', '2009-03-18 12:12:00'),
(4, 11, 'Visakhapatnam International Airport', 'VTZ', 'Active', '2009-03-18 12:12:00'),
(5, 367, 'Silchar Airport', 'IXS', 'Active', '2009-03-18 12:12:00'),
(6, 368, 'Dibrugarh Airport', 'DIB', 'Active', '2009-03-18 12:12:00'),
(7, 369, 'Jorhat Airport', 'JRH', 'Active', '2009-03-18 12:12:00'),
(8, 232, 'Goa International Airport', 'GOI', 'Active', '2009-03-18 12:12:00'),
(9, 62, 'Vadodara Airport', 'BDQ', 'Active', '2009-03-18 12:12:00'),
(10, 68, 'Bhavnagar Airport', 'BHU', 'Active', '2009-03-18 12:12:00'),
(11, 64, 'Surat International Airport', 'STV', 'Active', '2009-03-18 12:12:00'),
(12, 370, 'Kullu?Manali Airport', 'KUU', 'Active', '2009-03-18 12:12:00'),
(13, 371, 'Kangra Airport', 'DHM', 'Active', '2009-03-18 12:12:00'),
(14, 74, 'Shimla Airport ', 'SLV', 'Active', '2009-03-18 12:12:00'),
(15, 237, 'Jammu Airport ', 'IXJ', 'Active', '2009-03-18 12:12:00'),
(16, 310, 'Sheikh ul-Alam International Airport', 'SXR', 'Active', '2009-03-18 12:12:00'),
(17, 239, 'Kushok Bakula Rimpochee Airport', 'IXL', 'Active', '2009-03-18 12:12:00'),
(18, 372, 'Hubballi Airport', 'HBX', 'Active', '2009-03-18 12:12:00'),
(19, 90, 'Belgaum Airport', 'IXG', 'Active', '2009-03-18 12:12:00'),
(20, 88, 'Mangalore International Airport', 'IXE', 'Active', '2009-03-18 12:12:00'),
(21, 170, 'Trivandrum International Airport', 'TRV', 'Active', '2009-03-18 12:12:00'),
(22, 373, 'Calicut International Airport', 'CCJ', 'Active', '2009-03-18 12:12:00'),
(23, 304, 'Cochin International Airport', 'COK', 'Active', '2009-03-18 12:12:00'),
(24, 374, 'Khajuraho Airport', 'HJR', 'Active', '2009-03-18 12:12:00'),
(25, 111, 'Devi Ahilya Bai Holkar Airport', 'IDR', 'Active', '2009-03-18 12:12:00'),
(26, 110, 'Raja Bhoj Airport', 'BHO', 'Active', '2009-03-18 12:12:00'),
(27, 241, 'Chhatrapati Shivaji International AirportA', 'BOM', 'Inactive', '2009-03-18 12:12:00'),
(28, 269, 'Dr. Babasaheb Ambedkar International Airport', 'NAG', 'Active', '2009-03-18 12:12:00'),
(29, 121, 'Pune Airport', 'PNQ', 'Active', '2009-03-18 12:12:00'),
(30, 383, 'Pondicherry Airport', 'PNY', 'Active', '2009-03-18 12:12:00'),
(31, 2, 'Maharana Pratap Airport Udaipur', 'UDR', 'Active', '2009-03-18 12:12:00'),
(32, 1, 'Jaipur International Airport', 'JAI', 'Active', '2009-03-18 12:12:00'),
(33, 4, 'Jaisalmer Airport', 'JSA', 'Active', '2009-03-18 12:12:00'),
(34, 183, 'Pakyong Airport ', 'PYG', 'Active', '2009-03-18 12:12:00'),
(35, 358, 'Bagdogra International Airport', 'IXB', 'Active', '2009-03-18 12:12:00'),
(36, 197, 'Tiruchirappalli International Airport', 'TRZ', 'Active', '2009-03-18 12:12:00'),
(37, 375, 'Salem Airport', 'SXV', 'Active', '2009-03-18 12:12:00'),
(38, 192, 'Madurai Airport', 'IXM', 'Active', '2009-03-18 12:12:00'),
(39, 376, 'Allahabad Airport ?', 'IXD', 'Active', '2009-03-18 12:12:00'),
(40, 377, 'Kanpur Airport ?', 'KNU', 'Active', '2009-03-18 12:12:00'),
(41, 365, 'Lal Bahadur Shastri International Airport', 'VNS', 'Active', '2009-03-18 12:12:00'),
(42, 378, 'Pantnagar Airport', 'PGH', 'Active', '2009-03-18 12:12:00'),
(43, 207, 'Dehradun Airport', 'DED', 'Active', '2009-03-18 12:12:00'),
(44, 379, 'Behala Airport', 'VEBA', 'Active', '2009-03-18 12:12:00'),
(45, 380, 'Balurghat Airport', 'RGH', 'Active', '2009-03-18 12:12:00'),
(46, 358, 'Bagdogra Airport', 'IXB', 'Active', '2009-03-18 12:12:00'),
(47, 381, 'Don Mueang International Airport', 'DMK', 'Active', '2009-03-18 12:12:00'),
(48, 381, 'Suvarnabhumi Airport', 'BKK', 'Active', '2009-03-18 12:12:00'),
(49, 253, 'Hotan Airport', 'HTN', 'Active', '2009-03-18 12:12:00'),
(50, 253, 'Shigatse Peace Airport ', 'RKZ', 'Active', '2009-03-18 12:12:00'),
(51, 253, 'Qiemo Airport', 'IQM', 'Active', '2009-03-18 12:12:00'),
(52, 260, 'Battambang Airport', 'BBM', 'Active', '2009-03-18 12:12:00'),
(53, 293, 'Steung Treng Airport', 'TNX', 'Active', '2009-03-18 12:12:00'),
(54, 293, 'Kampong Chhnang Airport', 'KZC', 'Active', '2009-03-18 12:12:00'),
(55, 261, 'Hong Kong International Airport', 'HKG', 'Active', '2009-03-18 12:12:00'),
(56, 262, 'Binaka Airport', 'GNS', 'Active', '2009-03-18 12:12:00'),
(57, 262, 'Iskandar Airport', 'PKN', 'Active', '2009-03-18 12:12:00'),
(58, 262, 'Mozes Kilangin International Airport', 'TIM', 'Active', '2009-03-18 12:12:00'),
(59, 294, 'Mehrabad International Airport', 'THR', 'Active', '2009-03-18 12:12:00'),
(60, 294, 'Tehran Imam Khomeini International Airport', 'IKA', 'Active', '2009-03-18 12:12:00'),
(61, 294, 'Iranshahr Airport', 'IHR', 'Active', '2009-03-18 12:12:00'),
(62, 252, 'Chubu Centrair International Airport', 'NGO', 'Active', '2009-03-18 12:12:00'),
(63, 252, 'Okadama Airport', 'OKD', 'Active', '2009-03-18 12:12:00'),
(64, 252, 'Kobe Airport', 'UKB', 'Active', '2009-03-18 12:12:00'),
(65, 295, 'Kuwait International Airport', 'KWI', 'Active', '2009-03-18 12:12:00'),
(66, 264, 'Kuala Lumpur airports', 'KUL', 'Active', '2009-03-18 12:12:00'),
(67, 264, 'Kota Kinabalu (Malaysia) airport', 'BKI', 'Active', '2009-03-18 12:12:00'),
(68, 264, 'Kuching (Malaysia) airport', 'KCH', 'Active', '2009-03-18 12:12:00'),
(69, 296, 'Kaadedhdhoo Airport??', 'KDM', 'Active', '2009-03-18 12:12:00'),
(70, 296, 'Hanimaadhoo International Airport', 'HAQ', 'Active', '2009-03-18 12:12:00'),
(71, 296, 'Kadhdhoo Airport', 'KDO', 'Active', '2009-03-18 12:12:00'),
(72, 297, 'Mawlamyine Airport', 'MNU', 'Active', '2009-03-18 12:12:00'),
(73, 297, 'Sittwe Airport', 'AKY', 'Active', '2009-03-18 12:12:00'),
(74, 297, 'Dawei Airport ', 'TVY', 'Active', '2009-03-18 12:12:00'),
(75, 242, 'Janakpur Airport', 'JKR', 'Active', '2009-03-18 12:12:00'),
(76, 242, 'Gautam Buddha Airport', 'BWA', 'Active', '2009-03-18 12:12:00'),
(77, 242, 'Bharatpur Airport', 'BHR', 'Active', '2009-03-18 12:12:00'),
(78, 298, 'Phuket International Airport', 'HKT', 'Active', '2009-03-18 12:12:00'),
(79, 299, 'Hamad International Airport', 'DOH', 'Active', '2009-03-18 12:12:00'),
(80, 299, 'Doha International Airport', 'OTBD', 'Active', '2009-03-18 12:12:00'),
(81, 300, 'Najran Domestic Airport', 'EAM', 'Active', '2009-03-18 12:12:00'),
(82, 300, 'Wadi al-Dawasir Domestic Airport', 'WAE', 'Active', '2009-03-18 12:12:00'),
(83, 300, 'Arar Domestic Airport', 'RAE', 'Active', '2009-03-18 12:12:00'),
(84, 265, 'Singapore Changi Airport', 'SIN', 'Active', '2009-03-18 12:12:00'),
(85, 265, 'Seletar Airport', 'XSP', 'Active', '2009-03-18 12:12:00'),
(86, 265, 'Paya Lebar Air Base', 'QPG', 'Active', '2009-03-18 12:12:00'),
(87, 301, 'Jaffna Airport', 'JAF', 'Active', '2009-03-18 12:12:00'),
(88, 301, 'Batticaloa Airport', 'BTC', 'Active', '2009-03-18 12:12:00'),
(89, 301, 'Anuradhapura Airport', 'ADP', 'Active', '2009-03-18 12:12:00'),
(90, 266, 'Taiwan Taoyuan International Airport', 'TPE', 'Active', '2009-03-18 12:12:00'),
(91, 266, 'Matsu Beigan Airport', 'MFK', 'Active', '2009-03-18 12:12:00'),
(92, 266, 'Hengchun Airport', 'HCN', 'Active', '2009-03-18 12:12:00'),
(93, 267, 'Phetchabun Airport', 'PHY', 'Active', '2009-03-18 12:12:00'),
(94, 252, 'Tak Airport', 'TAK', 'Active', '2009-03-18 12:12:00'),
(95, 267, 'Loei Airport', 'LOE', 'Active', '2009-03-18 12:12:00'),
(96, 302, 'Istanbul Atat?rk Airport', 'IST', 'Active', '2009-03-18 12:12:00'),
(97, 302, 'Esenbo?a International Airport', 'ESB', 'Active', '2009-03-18 12:12:00'),
(98, 302, 'Adana ?akirpa?a Airport', 'ADA', 'Active', '2009-03-18 12:12:00'),
(99, 281, '  Al Bateen Executive Airport', 'AZI', 'Active', '2009-03-18 12:12:00'),
(100, 382, 'Fujairah International Airport', 'FJR', 'Active', '2009-03-18 12:12:00'),
(101, 281, 'Al Ain International Airport', 'AAN', 'Active', '2009-03-18 12:12:00'),
(102, 230, 'Yongphulla Airport', 'YON', 'Active', '2009-03-18 12:12:00'),
(103, 230, 'Paro Airport', 'PBH', 'Active', '2009-03-18 12:12:00'),
(104, 230, 'Gelephu Airport', 'Glu', 'Active', '2009-03-18 12:12:00'),
(105, 346, 'Port Blair Airport', 'IXZ', 'Inactive', '2018-09-28 13:09:45'),
(106, 119, 'Chhatrapati Shivaji International Airport', 'Bom', 'Active', '2018-12-13 15:42:21'),
(107, 44, 'Indira Gandhi Airport', '04123', 'Active', '2018-12-13 15:43:20'),
(108, 121, 'Pune International Airport', 'PNQ', 'Active', '2019-02-23 12:08:47'),
(109, 250, 'Dubai International Airport', 'DXB', 'Active', '2019-02-23 12:09:17'),
(110, 358, 'Bagdogra International Airporta', ' IXB', 'Inactive', '2019-02-25 15:28:07'),
(111, 262, 'Ngurah Rai International Airport', 'DPS', 'Active', '2019-02-25 18:19:48'),
(112, 242, 'Tribhuvan International Airport', 'KTM', 'Active', '2019-02-25 18:34:02'),
(113, 254, 'Port Louis', 'MRU', 'Active', '2019-02-26 16:00:56'),
(114, 301, 'Bandaranaike International Airport', 'CMB', 'Active', '2019-02-27 11:03:14'),
(115, 262, 'Denpasar', 'DPS', 'Active', '2019-03-19 11:13:08');

-- --------------------------------------------------------

--
-- Table structure for table `all_tour_other_expense`
--

CREATE TABLE IF NOT EXISTS `all_tour_other_expense` (
  `expense_id` int(11) NOT NULL,
  `booking_type` varchar(200) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_color_scheme`
--

CREATE TABLE IF NOT EXISTS `app_color_scheme` (
  `id` int(11) NOT NULL,
  `theme_color` varchar(100) NOT NULL,
  `theme_color_dark` varchar(100) NOT NULL,
  `theme_color_2` varchar(100) NOT NULL,
  `sidebar_color` varchar(100) NOT NULL,
  `topbar_color` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE IF NOT EXISTS `app_settings` (
  `setting_id` int(50) NOT NULL,
  `app_version` varchar(100) NOT NULL,
  `app_email_id` varchar(200) NOT NULL,
  `currency` int(11) NOT NULL,
  `app_smtp_status` varchar(300) NOT NULL,
  `app_smtp_host` varchar(300) NOT NULL,
  `app_smtp_port` varchar(300) NOT NULL,
  `app_smtp_password` varchar(300) NOT NULL,
  `app_smtp_method` varchar(300) NOT NULL,
  `app_contact_no` varchar(200) NOT NULL,
  `app_landline_no` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `tax_name` varchar(500) NOT NULL,
  `app_address` text NOT NULL,
  `app_website` varchar(300) NOT NULL,
  `app_name` varchar(200) NOT NULL,
  `app_cin` varchar(150) NOT NULL,
  `bank_acc_no` varchar(200) NOT NULL,
  `acc_name` varchar(300) NOT NULL,
  `bank_name` text NOT NULL,
  `bank_branch_name` varchar(300) NOT NULL,
  `bank_ifsc_code` varchar(300) NOT NULL,
  `bank_swift_code` varchar(300) NOT NULL,
  `sms_username` varchar(200) NOT NULL,
  `sms_password` varchar(200) NOT NULL,
  `server_link` varchar(500) NOT NULL,
  `server_username` varchar(200) NOT NULL,
  `server_password` varchar(200) NOT NULL,
  `policy_url` varchar(200) NOT NULL,
  `state_id` int(200) NOT NULL,
  `accountant_email` varchar(50) NOT NULL,
  `tax_type` varchar(200) NOT NULL,
  `tax_pay_date` date NOT NULL,
  `credit_card_charges` varchar(50) NOT NULL,
  `quot_format` int(11) NOT NULL,
  `quot_img_url` text NOT NULL,
  `ip_addresses` varchar(500) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `baddy_emp_cust_email`
--

CREATE TABLE IF NOT EXISTS `baddy_emp_cust_email` (
  `mail_status_id` int(100) NOT NULL,
  `emp_cust_id` int(100) NOT NULL,
  `member_type` varchar(200) NOT NULL,
  `date_mail` date NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`mail_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_cash_book_master`
--

CREATE TABLE IF NOT EXISTS `bank_cash_book_master` (
  `register_id` int(100) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_entry_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `particular` text NOT NULL,
  `clearance_status` varchar(200) NOT NULL,
  `payment_side` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  PRIMARY KEY (`register_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_list_master`
--

CREATE TABLE IF NOT EXISTS `bank_list_master` (
  `bank_id` int(100) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(400) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `bank_list_master`
--

INSERT INTO `bank_list_master` (`bank_id`, `bank_name`) VALUES
(1, 'Allahabad Bank.'),
(2, 'Andhra Bank.'),
(3, 'Bank of India.'),
(4, 'Bank of Baroda.'),
(5, 'Bank of Maharashtra.'),
(6, 'Canara Bank.'),
(7, 'Central Bank of India.'),
(8, 'Corporation Bank.'),
(9, 'ICICI Bank'),
(10, 'Bandhan Bank[3]'),
(11, 'Catholic Syrian Bank'),
(12, 'City Union Bank'),
(13, 'Dhanlaxmi Bank'),
(14, 'DCB Bank'),
(15, 'Federal Bank'),
(16, 'HDFC Bank'),
(17, 'Tamilnad Mercantile Bank Limited'),
(18, 'Karnataka Bank'),
(19, 'IndusInd Bank'),
(20, 'Jammu and Kashmir Bank'),
(21, 'Karur Vysya Bank'),
(22, 'Kotak Mahindra Bank[4]'),
(23, 'Lakshmi Vilas Bank'),
(24, 'Nainital Bank'),
(25, 'RBL Bank'),
(26, 'South Indian Bank'),
(27, 'Yes Bank'),
(28, 'Axis Bank');

-- --------------------------------------------------------

--
-- Table structure for table `bank_master`
--

CREATE TABLE IF NOT EXISTS `bank_master` (
  `bank_id` int(50) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `address` text NOT NULL,
  `account_no` varchar(300) NOT NULL,
  `ifsc_code` varchar(300) NOT NULL,
  `swift_code` varchar(300) NOT NULL,
  `account_type` varchar(300) NOT NULL,
  `mobile_no` varchar(300) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `gl_id` int(50) NOT NULL,
  `active_flag` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_name_master`
--

CREATE TABLE IF NOT EXISTS `bank_name_master` (
  `bank_name_id` int(50) NOT NULL,
  `label` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  PRIMARY KEY (`bank_name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_name_master`
--

INSERT INTO `bank_name_master` (`bank_name_id`, `label`, `bank_name`) VALUES
(1, 'idbi', 'IDBI Bank'),
(2, 'punjab_national', 'Punjab National Bank'),
(3, 'corporation', 'Corporation Bank'),
(4, 'bank_of_india', 'Bank Of India'),
(5, 'central_bank_of_india', 'Central Bank Of India'),
(6, 'state_bank_of_india', 'State Bank Of India'),
(7, 'bank_of_baroda', 'Bank Of Baroda'),
(8, 'canara', 'Canara Bank'),
(9, 'union_bank', 'Union Bank'),
(10, 'axis_bank', 'Axis Bank'),
(11, 'hdfc_bank', 'HDFC Bank'),
(12, 'bank_of_maharashtra', 'Bank Of Maharashtra');

-- --------------------------------------------------------

--
-- Table structure for table `bank_reconcl_credit_for`
--

CREATE TABLE IF NOT EXISTS `bank_reconcl_credit_for` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `credit_for` text NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_reconcl_debit_for`
--

CREATE TABLE IF NOT EXISTS `bank_reconcl_debit_for` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `debit_for` text NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_reconcl_master`
--

CREATE TABLE IF NOT EXISTS `bank_reconcl_master` (
  `id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `reconcl_date` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `book_balance` decimal(50,2) NOT NULL,
  `cheque_deposit` decimal(50,2) NOT NULL,
  `cheque_payment` decimal(50,2) NOT NULL,
  `bank_debit_amount` decimal(50,2) NOT NULL,
  `bank_credit_amount` decimal(50,2) NOT NULL,
  `reconcl_amount` decimal(50,2) NOT NULL,
  `bank_book_balance` decimal(50,2) NOT NULL,
  `diff_amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_reconcl_payment`
--

CREATE TABLE IF NOT EXISTS `bank_reconcl_payment` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `cheque_no` varchar(100) NOT NULL,
  `purchase` varchar(300) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_reconcl_receipt`
--

CREATE TABLE IF NOT EXISTS `bank_reconcl_receipt` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `cheque_no` varchar(200) NOT NULL,
  `sale` varchar(300) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `booker_incentive_group_tour`
--

CREATE TABLE IF NOT EXISTS `booker_incentive_group_tour` (
  `incentive_id` int(100) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `tourwise_traveler_id` int(50) NOT NULL,
  `basic_amount` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `incentive_amount` decimal(50,2) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  PRIMARY KEY (`incentive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `booker_incentive_package_tour`
--

CREATE TABLE IF NOT EXISTS `booker_incentive_package_tour` (
  `incentive_id` int(100) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `basic_amount` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `incentive_amount` decimal(50,2) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  PRIMARY KEY (`incentive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `booker_incentive_payment_master`
--

CREATE TABLE IF NOT EXISTS `booker_incentive_payment_master` (
  `payment_id` int(100) NOT NULL,
  `emp_id` int(150) NOT NULL,
  `financial_year_id` int(200) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(300) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(100) NOT NULL,
  `clearance_status` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE IF NOT EXISTS `branches` (
  `branch_id` int(50) NOT NULL,
  `location_id` int(50) NOT NULL,
  `branch_name` tinytext NOT NULL,
  `branch_address` text NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `email_id` tinytext NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `city` varchar(200) NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `acc_name` varchar(200) NOT NULL,
  `bank_acc_no` varchar(50) NOT NULL,
  `bank_branch_name` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `branch_assign`
--

CREATE TABLE IF NOT EXISTS `branch_assign` (
  `id` int(100) NOT NULL,
  `role_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `rank` varchar(50) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `description` varchar(400) NOT NULL,
  `icon` text NOT NULL,
  `branch_status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch_assign`
--

INSERT INTO `branch_assign` (`id`, `role_id`, `name`, `link`, `rank`, `priority`, `description`, `icon`, `branch_status`) VALUES
(1, 1, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', 'disabled'),
(2, 1, 'Admin Master', '', '2', '1', '', 'fa fa-user', 'disabled'),
(3, 1, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', 'disabled'),
(4, 1, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', 'disabled'),
(5, 1, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', 'disabled'),
(6, 1, 'Role Management', 'role_mgt/assign_user_roles.php', '2', '2', 'This is form where we assign menu to user.', 'fa fa-users', 'disabled'),
(7, 1, 'Branchwise Management', 'branch_mgt/assign_branch_filter.php', '2', '2', 'This is form where we assign branch to user.', 'fa fa-filter', 'disabled'),
(8, 1, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', 'disabled'),
(9, 1, 'Opening Balance', 'finance_master/opening_balance/index.php', '2', '2', 'Opening balance master', 'fa fa-hourglass-end', 'disabled'),
(10, 1, 'Tour Master', '', '3', '1', '', 'fa fa-book', 'disabled'),
(11, 1, 'Other Masters', 'other_masters/index.php', '3', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', 'disabled'),
(12, 1, 'Bus/Car', 'transport_agency/bus/transport_agency_bus_master_save.php', '3', '2', 'Here we add transport bus name.', 'fa fa-bus', 'disabled'),
(13, 1, 'Group Tours', 'tours/master/index.php', '3', '2', 'This is tour master', 'fa fa-users', 'disabled'),
(14, 1, 'Package Tours', 'custom_packages/master/index.php', '3', '2', 'This is Customized Packages', 'fa fa-user-plus', 'disabled'),
(15, 1, 'Visa', 'visa_master/index.php', '3', '2', 'Visa Master home.', 'fa fa-cc-visa', 'disabled'),
(16, 1, 'Excursion', 'paid_services/index.php', '3', '2', 'Tour paid services master', 'fa fa-thumb-tack', 'disabled'),
(17, 1, 'B2B Packages', 'b2b_packages/index.php', '3', '2', 'B2B Packages', 'fa fa-eye', 'disabled'),
(18, 1, 'Supplier Packages', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', 'disabled'),
(19, 1, 'Supplier Master', '', '4', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', 'disabled'),
(20, 1, 'Hotels', 'hotels/master/index.php', '4', '2', 'This is hotels master.', 'fa fa-bed', 'disabled'),
(21, 1, 'Transport', 'transport_agency/master/index.php', '4', '2', 'This is Transport module master.', 'fa fa-car', 'disabled'),
(22, 1, 'DMC', 'dmc/index.php', '4', '2', 'This is main menu of DMC information.', 'fa fa-truck', 'disabled'),
(23, 1, 'Car rental', 'car_rental/vendor/index.php', '4', '2', 'Car Rental agency', 'fa fa-car', 'disabled'),
(24, 1, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '4', '2', 'This visa vendor.', 'fa fa-cc-visa', 'disabled'),
(25, 1, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-plane', 'disabled'),
(26, 1, 'Excursion', 'site_seeing/vendor/index.php', '4', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', 'disabled'),
(27, 1, 'Cruise', 'cruise/index.php', '4', '2', 'This Cruise vendor.', 'fa fa-subway', 'disabled'),
(28, 1, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-subway', 'disabled'),
(29, 1, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '4', '2', 'This passport vendor', 'fa fa-id-card-o', 'disabled'),
(30, 1, 'Insurance', 'insuarance_vendor/index.php', '4', '2', 'This insuarance vendor', 'fa fa-shield', 'disabled'),
(31, 1, 'Other Suppliers', 'other_vendor/index.php', '4', '2', 'Other vendors master', 'fa fa-arrows', 'disabled'),
(32, 1, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', 'disabled'),
(33, 1, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', 'disabled'),
(34, 1, 'TAX Type', 'finance_master/tax_type_master/index.php', '5', '2', 'TAX type Master information', 'fa fa-list-ul', 'disabled'),
(35, 1, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', 'disabled'),
(36, 1, 'TDS Entry', 'finance_master/tds_entry/index.php', '5', '2', 'TDS Entry master', 'fa fa-money', 'disabled'),
(37, 1, 'Tax Payable', 'finance_master/gst_payable/index.php', '5', '2', 'TDS Entry master', 'fa fa-money', 'disabled'),
(38, 1, 'SL Master', 'finance_master/sl_master/index.php', '5', '2', 'SL Master information', 'fa fa-cog', 'disabled'),
(39, 1, 'GL Master', 'finance_master/gl_master/index.php', '5', '2', 'GL Master information', 'fa fa-cogs', 'disabled'),
(40, 1, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', 'disabled'),
(41, 1, 'Bank/Cash Book', 'finance_master/bank_cash_report/index.php', '5', '2', 'Bank/Cash Book Report', 'fa fa-money', 'disabled'),
(42, 1, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', 'disabled'),
(43, 1, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', 'disabled'),
(44, 1, 'Complete Group Cancel', 'tour_cancelation_and_refund/cancel_tour_main.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', 'disabled'),
(45, 1, 'Complete Tour Refund', 'tour_cancelation_and_refund/refund_tour/refund_cancelled_tour_group.php', '9', '2', 'This is refund of cancelled tour.', 'fa fa-angle-right', 'disabled'),
(46, 1, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', 'disabled'),
(47, 1, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', 'disabled'),
(48, 1, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', 'disabled'),
(49, 1, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', 'disabled'),
(50, 1, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', 'disabled'),
(51, 1, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', 'disabled'),
(52, 1, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', 'disabled'),
(53, 1, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', 'disabled'),
(54, 1, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', 'disabled'),
(55, 1, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', 'disabled'),
(56, 1, 'Bus Refund', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', 'disabled'),
(57, 1, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', 'disabled'),
(58, 1, 'Other Income', 'tour_estimate/other_income/index.php', '10', '2', 'Other income resources.', 'fa fa-arrows', 'disabled'),
(59, 1, 'Airline Supplier', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', 'disabled'),
(60, 1, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '14', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', 'disabled'),
(61, 1, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '14', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', 'disabled'),
(62, 1, 'Support', '#', '15', '1', 'This is promotions parent menu', 'fa fa-question', 'disabled'),
(63, 1, 'User Manual', 'user_manual/index.html', '15', '2', 'Documentation home', 'fa fa-info', 'disabled'),
(64, 1, 'Ticket Support', 'support/index.html', '15', '2', 'Support System home', 'fa fa-ticket', 'disabled'),
(65, 1, 'Daily Activities', 'daily_activity/index.php', '12', '2', 'This is daily activities.', 'fa fa-calendar-check-o', 'disabled'),
(66, 1, 'Visa Supplier', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', 'disabled'),
(71, 1, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', 'disabled'),
(72, 1, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', 'disabled'),
(76, 0, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', 'disabled'),
(81, 0, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', 'disabled'),
(82, 0, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', 'yes'),
(83, 0, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', 'yes'),
(84, 0, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', 'yes'),
(85, 0, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', 'yes'),
(86, 0, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', 'yes'),
(87, 0, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', 'yes'),
(88, 0, 'Inventory', 'inventory/index.php', '6', '2', 'This is Inventory management.', 'fa fa-list-ul', 'yes'),
(89, 0, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', 'yes'),
(90, 0, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', 'yes'),
(91, 0, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', 'yes'),
(92, 0, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', 'yes'),
(93, 0, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', 'yes'),
(94, 0, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', 'yes'),
(95, 0, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', 'yes'),
(96, 0, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', 'yes'),
(97, 0, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', 'yes'),
(98, 0, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', 'yes'),
(99, 0, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', 'yes'),
(100, 0, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', 'yes'),
(101, 0, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', 'yes'),
(102, 0, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', 'yes'),
(103, 0, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', 'yes'),
(104, 0, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', 'yes'),
(105, 0, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', 'yes'),
(106, 0, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', 'yes'),
(107, 0, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', 'yes'),
(108, 0, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', 'yes'),
(109, 0, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', 'yes'),
(110, 0, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', 'yes'),
(111, 0, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', 'yes'),
(112, 0, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', 'yes'),
(113, 0, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', 'yes'),
(114, 0, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `bus_booking_entries`
--

CREATE TABLE IF NOT EXISTS `bus_booking_entries` (
  `entry_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `company_name` varchar(300) NOT NULL,
  `seat_type` varchar(300) NOT NULL,
  `bus_type` varchar(500) NOT NULL,
  `pnr_no` varchar(300) NOT NULL,
  `origin` varchar(300) NOT NULL,
  `destination` varchar(300) NOT NULL,
  `date_of_journey` datetime NOT NULL,
  `reporting_time` varchar(100) NOT NULL,
  `boarding_point_access` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_booking_master`
--

CREATE TABLE IF NOT EXISTS `bus_booking_master` (
  `booking_id` int(100) NOT NULL,
  `customer_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(50) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `refund_net_total` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_booking_payment_master`
--

CREATE TABLE IF NOT EXISTS `bus_booking_payment_master` (
  `payment_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_booking_refund_master`
--

CREATE TABLE IF NOT EXISTS `bus_booking_refund_master` (
  `refund_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_master`
--

CREATE TABLE IF NOT EXISTS `bus_master` (
  `bus_id` int(30) NOT NULL,
  `bus_name` varchar(200) NOT NULL,
  `capacity` varchar(100) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_master`
--

INSERT INTO `bus_master` (`bus_id`, `bus_name`, `capacity`) VALUES
(1, '35 seater', '35'),
(2, '14 seater', '14'),
(3, '17 seater', '17'),
(4, '49 seater', '49'),
(5, '27 seater', '27'),
(6, '19 seater', '19');

-- --------------------------------------------------------

--
-- Table structure for table `bus_seat_arrangment_master`
--

CREATE TABLE IF NOT EXISTS `bus_seat_arrangment_master` (
  `id` int(200) NOT NULL,
  `tour_id` int(100) NOT NULL,
  `tour_group_id` int(100) NOT NULL,
  `bus_id` int(100) NOT NULL,
  `seat_no` int(100) NOT NULL,
  `traveler_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_tour_booking`
--

CREATE TABLE IF NOT EXISTS `bus_tour_booking` (
  `id` int(30) NOT NULL,
  `tour_id` int(30) NOT NULL,
  `tour_group_id` int(30) NOT NULL,
  `seats_booked` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_booking`
--

CREATE TABLE IF NOT EXISTS `car_rental_booking` (
  `booking_id` int(100) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `pass_name` varchar(200) NOT NULL,
  `total_pax` varchar(100) NOT NULL,
  `days_of_traveling` varchar(100) NOT NULL,
  `traveling_date` datetime NOT NULL,
  `enquiry_date` date NOT NULL,
  `vehicle_type` varchar(100) NOT NULL,
  `travel_type` varchar(100) NOT NULL,
  `places_to_visit` text NOT NULL,
  `vendor_id` int(50) NOT NULL,
  `daily_min_average` int(11) NOT NULL,
  `rate_per_km` decimal(50,2) NOT NULL,
  `extra_km` decimal(50,2) NOT NULL,
  `km_total_fee` decimal(50,2) NOT NULL,
  `actual_cost` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(50) NOT NULL,
  `service_tax` varchar(50) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `driver_allowance` decimal(50,2) NOT NULL,
  `permit_charges` decimal(50,2) NOT NULL,
  `toll_and_parking` decimal(50,2) NOT NULL,
  `state_entry_tax` decimal(50,2) NOT NULL,
  `total_fees` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_booking_vehicle_entries`
--

CREATE TABLE IF NOT EXISTS `car_rental_booking_vehicle_entries` (
  `entry_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `vehicle_id` int(50) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_payment`
--

CREATE TABLE IF NOT EXISTS `car_rental_payment` (
  `payment_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_quotation_master`
--

CREATE TABLE IF NOT EXISTS `car_rental_quotation_master` (
  `quotation_id` int(200) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `enquiry_id` int(200) NOT NULL,
  `login_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `total_pax` int(200) NOT NULL,
  `days_of_traveling` int(200) NOT NULL,
  `traveling_date` date NOT NULL,
  `vehicle_type` varchar(200) NOT NULL,
  `travel_type` varchar(200) NOT NULL,
  `places_to_visit` text NOT NULL,
  `vehicle_name` varchar(200) NOT NULL,
  `from_date` datetime NOT NULL,
  `to_date` datetime NOT NULL,
  `trip_type` varchar(200) NOT NULL,
  `route` varchar(200) NOT NULL,
  `extra_km_cost` decimal(50,2) NOT NULL,
  `extra_hr_cost` decimal(50,2) NOT NULL,
  `daily_km` int(200) NOT NULL,
  `subtotal` decimal(50,2) NOT NULL,
  `markup_cost` decimal(50,2) NOT NULL,
  `markup_cost_subtotal` decimal(50,2) NOT NULL,
  `taxation_id` int(200) NOT NULL,
  `service_tax` int(200) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `permit` decimal(50,2) NOT NULL,
  `toll_parking` decimal(50,2) NOT NULL,
  `driver_allowance` decimal(50,2) NOT NULL,
  `total_tour_cost` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  `quotation_date` date NOT NULL,
  `total_days` int(200) NOT NULL,
  `valid_km` decimal(50,2) NOT NULL,
  `extra_km` decimal(50,2) NOT NULL,
  `exclusions` text NOT NULL,
  `inclusions` text NOT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_refund_master`
--

CREATE TABLE IF NOT EXISTS `car_rental_refund_master` (
  `refund_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_vendor`
--

CREATE TABLE IF NOT EXISTS `car_rental_vendor` (
  `vendor_id` int(100) NOT NULL,
  `city_id` int(200) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_rental_vendor_vehicle_entries`
--

CREATE TABLE IF NOT EXISTS `car_rental_vendor_vehicle_entries` (
  `vehicle_id` int(100) NOT NULL,
  `vendor_id` int(50) NOT NULL,
  `vehicle_name` varchar(200) NOT NULL,
  `vehicle_no` varchar(200) NOT NULL,
  `vehicle_driver_name` varchar(300) NOT NULL,
  `vehicle_mobile_no` varchar(200) NOT NULL,
  `vehicle_year_of_purchase` varchar(150) NOT NULL,
  `vehicle_rate` varchar(200) NOT NULL,
  `vehicle_type` varchar(200) NOT NULL,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_denomination_master`
--

CREATE TABLE IF NOT EXISTS `cash_denomination_master` (
  `denom_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `denomination` varchar(300) NOT NULL,
  `numbers` varchar(300) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`denom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_deposit_master`
--

CREATE TABLE IF NOT EXISTS `cash_deposit_master` (
  `deposit_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `evidence_url` text NOT NULL,
  `transaction_date` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`deposit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_reconcl_master`
--

CREATE TABLE IF NOT EXISTS `cash_reconcl_master` (
  `id` int(11) NOT NULL,
  `reconcl_date` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `system_cash` decimal(50,2) NOT NULL,
  `till_cash` decimal(50,2) NOT NULL,
  `diff_prior` decimal(50,2) NOT NULL,
  `reconcl_amount` decimal(50,2) NOT NULL,
  `diff_reconcl` decimal(50,2) NOT NULL,
  `approval_status` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_reconcl_master_entries`
--

CREATE TABLE IF NOT EXISTS `cash_reconcl_master_entries` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_withdraw_master`
--

CREATE TABLE IF NOT EXISTS `cash_withdraw_master` (
  `withdraw_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `evidence_url` text NOT NULL,
  `transaction_date` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`withdraw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checklist_email_status`
--

CREATE TABLE IF NOT EXISTS `checklist_email_status` (
  `mail_status_id` int(100) NOT NULL,
  `tour_id` int(100) NOT NULL,
  `date_mail` date NOT NULL,
  `tour_type` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`mail_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checklist_entities`
--

CREATE TABLE IF NOT EXISTS `checklist_entities` (
  `entity_id` int(50) NOT NULL,
  `entity_for` varchar(300) NOT NULL,
  `tour_id` varchar(200) NOT NULL,
  `tour_group_id` varchar(200) NOT NULL,
  `booking_id` varchar(200) NOT NULL,
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checklist_group_tour`
--

CREATE TABLE IF NOT EXISTS `checklist_group_tour` (
  `id` int(100) NOT NULL,
  `tour_id` int(50) NOT NULL,
  `tour_group_id` int(50) NOT NULL,
  `entity_id` int(50) NOT NULL,
  `status` varchar(200) NOT NULL,
  `date_of_mail` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `checklist_package_tour`
--

CREATE TABLE IF NOT EXISTS `checklist_package_tour` (
  `id` int(100) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `entity_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `city_master`
--

CREATE TABLE IF NOT EXISTS `city_master` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `active_flag` varchar(20) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_master`
--

INSERT INTO `city_master` (`city_id`, `city_name`, `active_flag`) VALUES
(1, 'Jaipur', 'Active'),
(2, 'Udaipur', 'Active'),
(3, 'Jodhpur', 'Active'),
(4, 'Jaisalmer', 'Active'),
(5, 'Bikaner', 'Active'),
(6, 'Pushkar', 'Active'),
(7, 'Sawai Madhopur', 'Active'),
(8, 'Chittorgarh', 'Active'),
(9, 'Mount Abu', 'Active'),
(10, 'Alwar', 'Active'),
(11, 'Visakhapatnam', 'Active'),
(12, 'Tirupati', 'Active'),
(13, 'Nellore', 'Active'),
(14, 'Chittoor', 'Active'),
(15, 'Amalapuram', 'Active'),
(16, 'Srikakulam', 'Active'),
(17, 'Kakinada', 'Active'),
(18, 'Kadapa', 'Active'),
(19, 'Tawang', 'Active'),
(20, 'Roing', 'Active'),
(21, 'Itanagar', 'Active'),
(22, 'Bomdila', 'Active'),
(23, 'Ziro', 'Active'),
(24, 'Bhalukpong', 'Active'),
(25, 'Pasighat', 'Active'),
(26, 'Anini', 'Active'),
(27, 'Along', 'Active'),
(28, 'Kaziranga', 'Active'),
(29, 'Agnigarh Hill', 'Active'),
(30, 'Digboi', 'Active'),
(31, 'Diphu', 'Active'),
(32, 'Umrangshu', 'Active'),
(33, 'Patna', 'Active'),
(34, 'Gaya', 'Active'),
(35, 'Bihar Sharif', 'Active'),
(36, 'Motihari', 'Active'),
(37, 'Muzaffarpur', 'Active'),
(38, 'Madhubani', 'Active'),
(39, 'Arrah', 'Active'),
(40, 'Rajgir', 'Active'),
(41, 'Chhapra', 'Active'),
(42, 'Hajipur', 'Active'),
(43, 'Munger', 'Active'),
(44, 'New Delhi', 'Active'),
(45, 'Connaught Place', 'Active'),
(46, 'Delhi Cantonment', 'Active'),
(47, 'Dwarka', 'Active'),
(48, 'Karol Bagh', 'Active'),
(49, 'Shahdara', 'Active'),
(50, 'Rohini', 'Active'),
(51, 'Janakpuri', 'Active'),
(52, 'Pitam Pura', 'Active'),
(53, 'Panaji', 'Active'),
(54, 'Margao', 'Active'),
(55, 'Vasco da Gama', 'Active'),
(56, 'Mapusa', 'Active'),
(57, 'Ponda', 'Active'),
(58, 'Mormugao', 'Active'),
(59, 'Calangute', 'Active'),
(60, 'Old Goa', 'Active'),
(61, 'Candolim', 'Active'),
(62, 'Vadodara', 'Active'),
(63, 'Rajkot', 'Active'),
(64, 'Surat', 'Active'),
(65, 'Gandhinagar', 'Active'),
(66, 'Bhuj', 'Active'),
(67, 'Jamnagar', 'Active'),
(68, 'Bhavnagar', 'Active'),
(69, 'Nadiad', 'Active'),
(70, 'Ankleshwar', 'Active'),
(71, 'Gandhidham', 'Active'),
(72, 'Veraval', 'Active'),
(73, 'Dharamsala', 'Active'),
(74, 'Shimla', 'Active'),
(75, 'Manali', 'Active'),
(76, 'Dalhousie', 'Active'),
(77, 'Nahan', 'Active'),
(78, 'Kasauli', 'Active'),
(79, 'Palampur', 'Active'),
(80, 'Parwanoo', 'Active'),
(81, 'Sundar Nagar', 'Active'),
(82, 'Nalagarh', 'Active'),
(83, 'Solan', 'Active'),
(84, 'Jogindernagar', 'Active'),
(85, 'Kullu', 'Active'),
(86, 'Paonta Sahib', 'Active'),
(87, 'Bengaluru', 'Active'),
(88, 'Mangalore', 'Active'),
(89, 'Hubli', 'Active'),
(90, 'Belgaum', 'Active'),
(91, 'Gulbarga', 'Active'),
(92, 'Bijapur', 'Active'),
(93, 'Hassan', 'Active'),
(94, 'Mysore', 'Active'),
(95, 'Shimoga', 'Active'),
(96, 'Udupi', 'Active'),
(97, 'Davanagere', 'Active'),
(98, 'Bidar', 'Active'),
(99, 'Kochin', 'Inactive'),
(100, 'Kozhikode', 'Active'),
(101, 'Thiruvananthapuram', 'Active'),
(102, 'Alappuzha', 'Active'),
(103, 'Thrissur', 'Active'),
(104, 'Kollam', 'Active'),
(105, 'Palakkad', 'Active'),
(106, 'Munnar', 'Active'),
(107, 'Varkala', 'Active'),
(108, 'Kovalam', 'Active'),
(109, 'Thekkady', 'Active'),
(110, 'Bhopal', 'Active'),
(111, 'Indore', 'Active'),
(112, 'Jabalpur', 'Active'),
(113, 'Gwalior', 'Active'),
(114, 'Sagar', 'Active'),
(115, 'Rewa', 'Active'),
(116, 'Pachmarhi', 'Active'),
(117, 'Ujjain', 'Active'),
(118, 'Maheshwar', 'Active'),
(119, 'Mumbai', 'Active'),
(120, 'Wardha', 'Active'),
(121, 'Pune', 'Active'),
(122, 'Nashik', 'Active'),
(123, 'Aurangabad', 'Active'),
(124, 'Amravati', 'Active'),
(125, 'Solapur', 'Active'),
(126, 'Navi Mumbai', 'Active'),
(127, 'Thane', 'Active'),
(128, 'Kalyan', 'Active'),
(129, 'Kolhapur', 'Active'),
(130, 'Latur', 'Active'),
(131, 'Jalgaon', 'Active'),
(132, 'Mahabaleshwar', 'Active'),
(133, 'Pimpri-Chinchwad', 'Active'),
(134, 'Satara', 'Active'),
(135, 'Lonavla', 'Active'),
(136, 'Manipur', 'Active'),
(137, 'Imphal', 'Active'),
(138, 'Bishnupur', 'Active'),
(139, 'Ukhrul', 'Active'),
(140, 'Thoubal', 'Active'),
(141, 'Senapati', 'Active'),
(142, 'Chandel', 'Active'),
(143, 'Temenglong', 'Active'),
(144, 'Churachanpur', 'Active'),
(145, 'Meghalaya', 'Active'),
(146, 'Shillong', 'Active'),
(147, 'Cherrapunji', 'Active'),
(148, 'Mizoram', 'Active'),
(149, 'Aizawl', 'Active'),
(150, 'Champhai', 'Active'),
(151, 'Lunglei', 'Active'),
(152, 'Serchhip', 'Active'),
(153, 'Lawngtlai', 'Active'),
(154, 'Kolasib', 'Active'),
(155, 'Nagaland', 'Active'),
(156, 'Dimapur', 'Active'),
(157, 'Kohima', 'Active'),
(158, 'Kiphire', 'Active'),
(159, 'Orissa', 'Active'),
(160, 'Bhubaneshwar', 'Active'),
(161, 'Cuttack', 'Active'),
(162, 'Puri', 'Active'),
(163, 'Rourkela', 'Active'),
(164, 'Konark', 'Active'),
(165, 'Barbil', 'Active'),
(166, 'Bargarh', 'Active'),
(167, 'Paradeep', 'Active'),
(168, 'Jeypore', 'Active'),
(169, 'Brahmapur', 'Active'),
(170, 'Trivandrum', 'Active'),
(171, 'Punjab', 'Active'),
(172, 'Amritsar', 'Active'),
(173, 'Pathankot', 'Active'),
(174, 'Jalandhar', 'Active'),
(175, 'Chandigarh', 'Active'),
(176, 'Ludhiana', 'Active'),
(177, 'Bhatinda', 'Active'),
(178, 'Patiala', 'Active'),
(179, 'Mohali', 'Active'),
(180, 'Ropar', 'Active'),
(181, 'Kapurthala', 'Active'),
(182, 'Sikkim', 'Active'),
(183, 'Gangtok', 'Active'),
(184, 'Yuksom', 'Active'),
(185, 'Namchi', 'Active'),
(186, 'Tamil Nadu', 'Active'),
(187, 'Chennai', 'Active'),
(188, 'Coimbatore', 'Active'),
(189, 'Kanchipuram', 'Active'),
(190, 'Kanyakumari', 'Active'),
(191, 'Kodaikanal', 'Active'),
(192, 'Madurai', 'Active'),
(193, 'Mahabalipuram', 'Active'),
(194, 'Ooty', 'Active'),
(195, 'Tirunelveli', 'Active'),
(196, 'Vellore', 'Active'),
(197, 'Tiruchirappalli', 'Active'),
(198, 'Rameswaram', 'Active'),
(199, 'Coonoor', 'Active'),
(200, 'Yelagiri', 'Active'),
(201, 'Yercaud', 'Active'),
(202, 'Thanjavur', 'Active'),
(203, 'Tripura', 'Active'),
(204, 'Agartala', 'Active'),
(205, 'Uttarakhand', 'Active'),
(206, 'Almora', 'Active'),
(207, 'Dehradun', 'Active'),
(208, 'Haridwar', 'Active'),
(209, 'Kausani', 'Active'),
(210, 'Kedarnath', 'Active'),
(211, 'Badrinath', 'Active'),
(212, 'Mussoorie', 'Active'),
(213, 'Nainital', 'Active'),
(214, 'Pitoragarh', 'Active'),
(215, 'Ranikhet', 'Active'),
(216, 'Rishikesh', 'Active'),
(217, 'Lansdowne', 'Active'),
(218, 'Mukteshwar', 'Active'),
(219, 'Naukuchiatal', 'Active'),
(220, 'Pauri', 'Active'),
(221, 'Munsiyari', 'Active'),
(222, 'Auli', 'Active'),
(223, 'Lohaghat', 'Active'),
(224, 'Landour', 'Active'),
(225, 'Havelock Islands', 'Active'),
(226, 'Andaman', 'Active'),
(227, 'Andhra Pradesh', 'Active'),
(228, 'Assam', 'Active'),
(229, 'Bengal', 'Active'),
(230, 'Bhutan', 'Active'),
(231, 'Chattisgarh', 'Active'),
(232, 'Goa', 'Active'),
(233, 'Gujarat', 'Active'),
(234, 'Himachal Pradesh ', 'Active'),
(235, 'Uttar Pradesh', 'Active'),
(236, 'Karnataka', 'Active'),
(237, 'Jammu Kashmir', 'Active'),
(238, 'Kerala', 'Active'),
(239, 'Leh Ladakh', 'Active'),
(240, 'Madhya Pradesh', 'Active'),
(241, 'Maharashtra', 'Active'),
(242, 'Nepal', 'Active'),
(243, 'North East', 'Active'),
(244, 'Rajasthan', 'Active'),
(245, 'Uttaranchal', 'Active'),
(246, 'Bekal', 'Active'),
(247, 'America', 'Active'),
(248, 'Australia', 'Active'),
(249, 'New Zealand', 'Active'),
(250, 'Dubai', 'Active'),
(251, 'Muscat', 'Active'),
(252, 'Japan', 'Active'),
(253, 'China', 'Active'),
(254, 'Mauritius', 'Active'),
(255, 'South Africa', 'Active'),
(256, 'keniya', 'Active'),
(257, 'shrilanka', 'Active'),
(258, 'Egypt', 'Active'),
(259, 'Kanada', 'Active'),
(260, 'Cambodia', 'Active'),
(261, 'HongKong', 'Active'),
(262, 'Indonesia', 'Active'),
(263, 'South Korea', 'Active'),
(264, 'Malaysia', 'Active'),
(265, 'Singapore', 'Active'),
(266, 'Taiwan', 'Active'),
(267, 'Thiland', 'Active'),
(268, 'bhuvneshwara', 'Active'),
(269, 'Nagpur', 'Active'),
(270, 'NagpurInactive', 'Active'),
(271, 'Pandharpur', 'Active'),
(272, 'Simla', 'Active'),
(273, 'tokioInactive', 'Active'),
(274, 'nnnnn', 'Inactive'),
(275, 'Lopp', 'Active'),
(276, 'Noida', 'Active'),
(277, 'Loni', 'Active'),
(278, 'South', 'Inactive'),
(279, 'Auran', 'Active'),
(280, 'Alibaug', 'Active'),
(281, 'Abu dhabi', 'Active'),
(282, 'Bangalore', 'Active'),
(283, 'Sangali', 'Active'),
(284, 'Matheran', 'Active'),
(285, 'Kashmir', 'Active'),
(286, 'BombayInactive', 'Active'),
(287, 'Alleppey', 'Active'),
(288, 'Ahmednagar', 'Active'),
(289, 'punea', 'Inactive'),
(290, 'Puducherry', 'Active'),
(291, ' West Bengal', 'Active'),
(292, 'Bangkok', 'Active'),
(293, 'Combodia', 'Active'),
(294, 'Iran', 'Active'),
(295, 'Kuwait', 'Active'),
(296, 'Maldives', 'Active'),
(297, ' Myanmar Burma', 'Active'),
(298, 'Phuket', 'Active'),
(299, 'Qatar', 'Active'),
(300, 'Saudi Arabia', 'Active'),
(301, 'Sri Lanka', 'Active'),
(302, 'Turkey', 'Active'),
(303, 'UAE', 'Active'),
(304, 'Cochin', 'Active'),
(305, 'Lachung', 'Active'),
(306, 'Pelling', 'Active'),
(307, 'Kalimpong', 'Active'),
(308, 'Darjeeling', 'Active'),
(309, 'Pattaya', 'Active'),
(310, 'Srinagar', 'Active'),
(311, 'Kargil', 'Active'),
(312, 'Nubra', 'Active'),
(313, 'Pangong', 'Active'),
(314, 'Leh', 'Active'),
(315, 'Sonamarg', 'Active'),
(316, 'Coorg', 'Active'),
(317, 'Wayanad', 'Active'),
(318, 'Gulmarg', 'Active'),
(319, 'Pahalgam', 'Active'),
(320, 'Krabi', 'Active'),
(321, 'Katmandu', 'Active'),
(322, 'Pokhara', 'Active'),
(323, 'Chitwan', 'Active'),
(324, 'Nagarkot', 'Active'),
(325, 'New City ', 'Inactive'),
(326, 'Paris', 'Active'),
(327, 'Zurich', 'Active'),
(328, 'London', 'Active'),
(329, 'Vienna', 'Active'),
(330, 'Prague', 'Active'),
(331, 'Budapest', 'Active'),
(332, 'Paro', 'Active'),
(333, 'Thinphu', 'Active'),
(334, 'Wangdi', 'Active'),
(335, 'Punakha', 'Active'),
(336, 'Thimphu', 'Active'),
(337, 'Macau', 'Active'),
(338, 'Kathmandu', 'Active'),
(339, 'Bali Kuta', 'Active'),
(340, 'Bali Seminyak', 'Active'),
(341, 'Bali Ubud', 'Active'),
(342, 'Denpasar Bali', 'Active'),
(343, 'Baku', 'Active'),
(344, 'Lucerne', 'Active'),
(345, 'Disneyland', 'Active'),
(346, 'Port Blair', 'Active'),
(347, 'Gywahati', 'Active'),
(348, 'Guwahati', 'Active'),
(349, 'Banglore', 'Active'),
(350, 'Nanded', 'Active'),
(351, 'XYZ', 'Inactive'),
(352, 'Ramasa', 'Active'),
(353, 'Old Mumbai', 'Inactive'),
(354, 'Pusad', 'Active'),
(355, ' Guwahati', 'Active'),
(356, 'Italy', 'Active'),
(357, 'Amalner', 'Active'),
(358, 'Bagdogra', 'Active'),
(359, 'Colombo', 'Active'),
(360, 'Secunderabad', 'Active'),
(361, 'Murudeshwar', 'Active'),
(362, 'Sirsi', 'Active'),
(363, 'Junagadh', 'Active'),
(364, 'Somnath ', 'Active'),
(365, 'Varanasi', 'Active'),
(366, 'Vijayawada', 'Active'),
(367, 'Kumbhirgram', 'Active'),
(368, 'Mohanbari', 'Active'),
(369, 'Rowriah', 'Active'),
(370, 'Bhuntar', 'Active'),
(371, 'Kangra', 'Active'),
(372, 'Hubballi', 'Active'),
(373, 'Karipur', 'Active'),
(374, 'Khajuraho', 'Active'),
(375, 'Salem', 'Active'),
(376, 'Allahabad', 'Active'),
(377, 'Kanpur', 'Active'),
(378, 'Pantnagar', 'Active'),
(379, 'Kolkata', 'Active'),
(380, 'Balurghat', 'Active'),
(381, 'Thailand', 'Active'),
(382, 'Fujairah', 'Active'),
(383, 'Pondicherry', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `cms_master`
--

CREATE TABLE IF NOT EXISTS `cms_master` (
  `id` int(11) NOT NULL,
  `draft_for` varchar(300) NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_master`
--

INSERT INTO `cms_master` (`id`, `draft_for`, `type_id`) VALUES
(1, 'New User Login', 1),
(2, 'New Customer Login', 1),
(3, 'Supplier Login', 1),
(4, 'Enquiry Acknowledgement', 1),
(5, 'Enquiry Assigned', 1),
(6, 'Enquiry Form Send ', 1),
(7, 'Quotation Email to Backoffice', 1),
(8, 'Quotation', 1),
(9, 'Customer Quotation Viewed', 1),
(10, 'Lead Converted Successfully', 1),
(11, 'Customer Interested for Tour', 1),
(12, 'Visa Details Email', 1),
(13, 'Group Tour Booking Confirmation', 1),
(14, 'Package Tour Booking Confirmation', 1),
(15, 'Visa Tour Booking Confirmation', 1),
(16, 'Flight Tour Booking Confirmation', 1),
(17, 'Train Tour Booking Confirmation', 1),
(18, 'Hotel Tour Booking Confirmation', 1),
(19, 'Bus Tour Booking Confirmation', 1),
(20, 'Car Rental Tour Booking Confirmation', 1),
(21, 'Passport Tour Booking Confirmation', 1),
(22, 'Forex Tour Booking Confirmation', 1),
(23, 'Quotation Request', 1),
(24, 'Supplier Quotation Feedback', 1),
(25, 'Purchase Confirmation', 1),
(26, 'Group Tour Cancel', 1),
(27, 'Group Tour Refund', 1),
(28, 'Package Tour Cancel', 1),
(29, 'Package Tour Refund', 1),
(30, 'Visa Tour Cancel', 1),
(31, 'Visa Tour Refund', 1),
(32, 'Flight Tour Cancel', 1),
(33, 'Flight Tour Refund', 1),
(34, 'Train Tour Cancel', 1),
(35, 'Train Tour Refund', 1),
(36, 'Bus Tour Cancel', 1),
(37, 'Bus Tour Refund', 1),
(38, 'Hotel Cancel', 1),
(39, 'Hotel Refund', 1),
(40, 'Car Rental Cancel', 1),
(41, 'Car Rental Refund', 1),
(42, 'Excursion Cancel', 1),
(43, 'Excursion Refund', 1),
(44, 'Group Tour Installment', 1),
(45, 'Package Tour Installment', 1),
(46, 'Car Rental Installment', 1),
(47, 'Visa Booking Installment', 1),
(48, 'Flight Booking Installment', 1),
(49, 'Train Booking Installment', 1),
(50, 'Hotel Booking Installment', 1),
(51, 'Bus Booking Installment', 1),
(52, 'Passport Booking Installment', 1),
(53, 'Forex Booking Installment', 1),
(54, 'Excursion Booking Installment', 1),
(55, 'Group Tour Payment Correction', 1),
(56, 'Package Tour Payment Correction', 1),
(57, 'Visa Booking Payment Correction', 1),
(58, 'Flight Booking Payment Correction', 1),
(59, 'Train Booking Payment Correction', 1),
(60, 'Hotel Booking Payment Correction', 1),
(61, 'Bus Booking Payment Correction', 1),
(62, 'Passport Booking Payment Correction', 1),
(63, 'Forex Booking Payment Correction', 1),
(64, 'Excursion Booking Payment Correction', 1),
(65, 'Airline Topup recharge', 1),
(66, 'Visa Topup recharge', 1),
(67, 'App Setting', 2),
(68, 'Tour Checklist reminder', 2),
(69, 'Enquiry Followup', 2),
(70, 'Customer passport renewal', 2),
(71, 'Task Reminder', 2),
(72, 'User Birthday', 2),
(73, 'Customer Birthday', 2),
(74, 'Happy Journey', 2),
(75, 'Airline Low Balance', 2),
(76, 'Visa Low Balance', 2),
(77, 'Employee Anniversary reminder', 2),
(78, 'FIT customer feedback', 2),
(79, 'GIT Customer Feedback', 2),
(80, 'Group Tour Payment Reminder', 2),
(81, 'Package Tour Payment Reminder', 2),
(82, 'Visa payment Reminder', 2),
(83, 'Flight Payment Reminder', 2),
(84, 'Train payment Reminder', 2),
(85, 'Hotel payment Reminder', 2),
(87, 'Car Rental payment Reminder', 2),
(88, 'Passport payment Reminder ', 2),
(89, 'Excursion Payment Reminder ', 2),
(90, 'Tax pay', 2),
(91, 'User Visa Status', 2),
(92, 'vendor payment reminder', 2),
(93, 'Weekly Summary report', 2),
(94, 'Excursion Booking Confirmation', 1),
(95, 'Leave Reply', 1),
(96, 'Leave Reject ', 1),
(97, 'Miscellaneous Booking Installment', 1),
(98, 'Miscellaneous Booking Payment Correction', 1),
(99, 'Miscellaneous Cancellation Confirmation', 1),
(100, 'Miscellaneous Cancellation Refund', 1),
(101, 'Miscellaneous Booking confirmation', 1),
(102, 'Hotel Inventory Reminder', 1),
(103, 'Excursion Inventory Reminder', 1),
(104, 'B2B Portal Registration Request!', 1),
(105, 'B2B Customer Login', 1),
(106, 'About Credit Limit Increase', 1),
(107, 'Credit Limit Increase Acknowledgment', 1),
(108, 'Miscellaneous Payment Reminder ', 2),
(109, 'Passport Tour Cancel', 1),
(110, 'Passport Tour Refund', 1),
(111, 'Car Rental Payment Correction', 1),
(112, 'B2B Portal Registration Request!', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_master_entries`
--

CREATE TABLE IF NOT EXISTS `cms_master_entries` (
  `entry_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `subject` text NOT NULL,
  `draft` text NOT NULL,
  `signature` text NOT NULL,
  `active_flag` varchar(300) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_master_entries`
--

INSERT INTO `cms_master_entries` (`entry_id`, `id`, `subject`, `draft`, `signature`, `active_flag`) VALUES
(1, 1, 'Welcome aboard!', '<div style="text-align: justify; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear User,&nbsp;</b></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></b></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Greeting!</font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is to keep up the trend of Creating Delighted User, we are sure that you are the best fit for the role you are appointed for &amp; would ensure that you exceed thee our Soul objective expectations that we have with you.</font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For any queries or concerns you may have or come across while you work feel free to get in touch with us and we should make sure that you become a Champ and never get bothered by it again. We have highly sophisticated system in place, to&nbsp;</font><span style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;" trebuchet="" ms",="" sans-serif;"="">keep you comfortable, agile &amp; highly responsive so that you can respond to your clients efficiently and win them. So letâ€™s get going and may you have the best of your time with us.</span></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; text-align: start; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Wishing you All the Best!</font></div></div>', '<span style="font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><i>Warm Regards,</i></font></span><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></div>', 'Active'),
(2, 2, 'Welcome aboard!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for Choosing us for your exciting vacation with your family or friends. We assure you best of the services to ensure that you simply enjoy the tour, create cherishing memories &amp; leave all the worries about making your tour a great one to us.</font>&nbsp;</div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your highest convenience we are happy to provide you access to our system where in you can check our upcoming offers, download various documents like Service Vouchers, Invoices, Air Tickets Booked through us etc. With this we Hope that you travel long with us, your ultimate choice when it comes to create cherishing memories and lasting experience.</font></div></div>', '<span style="font-family: Roboto, sans-serif; font-size: initial; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i>Warm Regards,</i></font></span>', 'Active'),
(3, 3, 'Welcome Aboard', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif;">Dear Supplier,</b></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Greetings!</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Our entire team welcomes you from the bottom of our heart. We hereby look forward to succeed &amp; grow mutually with you.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(4, 4, 'Enquiry Acknowledgment', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are glad to confirm you that we''ve received your tour request.&nbsp;</font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Your personal travel concierge will call you soon! Please find the details of your query as below:-</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(5, 5, 'Enquiry Assignment :', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Team,</font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">New Enquiry has been assigned to you with following details.</font></span></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(6, 6, 'Tour Enquiry Information', '<div class="gmail_default" style="background-color: rgb(255, 255, 255); line-height: 21px;"><div class="gmail_default" style="line-height: 21px; background-color: rgb(255, 255, 255);"><div class="gmail_default" style="line-height: 21px;"><font color="#333333" face="Roboto, sans-serif" size="2"><b>Dear Customer,</b></font></div><div class="gmail_default" style="line-height: 21px;"><font color="#333333" face="Roboto, sans-serif" size="2"><br></font></div><div class="gmail_default" style="line-height: 21px;"><font color="#333333" face="Roboto, sans-serif" size="2">Please provide general information of your tour enquiry to prepare &amp; best proposal &amp; services.&nbsp;</font></div><div class="gmail_default" style="line-height: 21px;"><font color="#333333" face="Roboto, sans-serif" size="2"><br></font></div><div class="gmail_default" style="line-height: 21px;"><font color="#333333" face="Roboto, sans-serif" size="2">Our team will connect you in shortly.&nbsp;</font></div></div></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(7, 7, 'Confirmed Quotation Details : ', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Team,</b></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></b></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Below quotation is confirmed by the customer. Request you to process the booking.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(8, 8, 'New Quotation : ', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</b></font></span></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></b></font></span></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing us. Herewith forwarding your quotation details.</span>&nbsp;Please review and feel free to call us if any query.</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(9, 9, 'Customer viewed quotation', '<span style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Team,&nbsp;</b></font></span><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">New customer recently viewed your quotation. You may take further followup as earlier.</font></div>', '<i trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(10, 10, 'The new lead converted successfully!', '<span style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Team,&nbsp;</b></font></span><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">The new lead converted successfully!</font></div>', '<i trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(11, 11, 'New Customer Interested', '<span style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Team,&nbsp;</b></font></span><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="font-family: Roboto, sans-serif; font-size: small; background-color: transparent; color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">New customer is interested. Please note the following details.</font></div>', '<i trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(12, 12, 'Visa Enquiry Details', 'Dear Customer,<div style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Thank you for Visa enquiry. Please refer the following information and feel free to call us for further.</div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: initial; background-color: transparent; line-height: 21px;">Warm Regards,</span><br></div>', 'Active'),
(13, 13, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear Customer,&nbsp;</b></div><div dir="ltr" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"=""><br></span></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your convenience, we are providing login details where you can view &amp; download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingertips&nbsp;anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.</font></div></div></div></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""><i>Warm Regards,</i></span><br></div>', 'Active'),
(14, 14, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear Customer,&nbsp;</b></div><div dir="ltr" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"=""><br></span></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your convenience, we are providing login details where you can view &amp; download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingertips&nbsp;anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.</font><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">&nbsp;&nbsp;</span><br></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></div></div></div></div>', '<span style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""><i>Warm Regards,</i></span>', 'Active'),
(15, 15, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear Customer,Â </b></div><div dir="ltr" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><div class="gmail_default" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</font></div><div style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"=""><br></span></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your convenience, we are providing login details where you can view & download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingertipsÂ anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.</font><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">Â Â </span></div></div></div></div>', '<div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""><i>Warm Regards,</i></span><br></div>', 'Active'),
(16, 16, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear Customer,&nbsp;</b></div><div dir="ltr" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"=""><br></span></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your convenience, we are providing login details where you can view &amp; download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingertips&nbsp;anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.</font><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">&nbsp;</span><br></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></div></div></div></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(17, 17, 'Booking confirmation acknowledgement!', 'We are thank you for choosing and I hope this journey will give you delightful experience with us. Be rest assured since we have taken all the measures to ensure that your trip is a memorable one. For your convenience, we are providing login details where you can view &amp; download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingure tip anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.', 'Warm Regards,Itours', 'Active'),
(18, 18, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear Customer,&nbsp;</b></div><div dir="ltr" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</font></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"=""><br></span></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">For your convenience, we are providing login details where you can view &amp; download your tour relevant documents like Invoice, Air Ticket, Confirmation Vouchers etc. at your fingertips&nbsp;anytime anywhere. Also needless to mention you will also be notified of our upcoming offers to various exotic locations across the planet.</font><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">&nbsp;&nbsp;</span><br></div><div style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></div></div></div></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(19, 19, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(20, 20, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</span><br></font></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(21, 21, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active');
INSERT INTO `cms_master_entries` (`entry_id`, `id`, `subject`, `draft`, `signature`, `active_flag`) VALUES
(22, 22, 'Booking confirmation acknowledgement!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(23, 23, 'New quotation request', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Supplier,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would request you to kindly consider this matter as priority and send us your quotation with terms and conditions for the mentioned requirements. Hope will get the quotation as earliest so we can process in our deadline.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(24, 24, 'Vendor Quotation Acknowlagement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<b style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for contacting us.This is&nbsp;Acknowledgment&nbsp;that we received Quotation.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(25, 25, 'Purchase Details!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><b style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Supplier,</span></b></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This letter is to confirmed our acceptance of booking purchase as per trail quotation. We are truly excited to do business with you and thank you for putting your services. Should you have any queries regarding purchase, please call us or get in touch with us directly.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Looking forward to a long and successful collaboration.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(26, 26, 'Tour Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(27, 27, 'Tour Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(28, 28, 'Tour Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(29, 29, 'Tour Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">D<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(30, 30, 'Visa Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(31, 31, 'Visa Cancellation Refund', 'Dear Customer,<div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">&nbsp;Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</div>', '<i>Warm Regards,</i>', 'Active'),
(32, 32, 'Flight Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(33, 33, 'Flight Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><br></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(34, 34, 'Train Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(35, 35, 'Train Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(36, 36, 'Bus Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(37, 37, 'Bus Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(38, 38, 'Hotel Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(39, 39, 'Hotel Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(40, 40, 'Tour Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(41, 41, 'Car Rental Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><br></div><div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active');
INSERT INTO `cms_master_entries` (`entry_id`, `id`, `subject`, `draft`, `signature`, `active_flag`) VALUES
(42, 42, 'Excursion Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹</font><span style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">ustomer</span><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(43, 43, 'Excursion Cancellation Refund', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(44, 44, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(45, 45, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(46, 46, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(47, 47, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(48, 48, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(49, 49, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(50, 50, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: initial; line-height: 21px; font-family: Roboto, sans-serif;"><i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i><br></div>', 'Active'),
(51, 51, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(52, 52, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(53, 53, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(54, 54, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(55, 55, 'Group Tour Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><b style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">â€‹â€‹<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">ustomer</span><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">&nbsp;<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(56, 56, 'Package Tour Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(57, 57, 'Visa Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active');
INSERT INTO `cms_master_entries` (`entry_id`, `id`, `subject`, `draft`, `signature`, `active_flag`) VALUES
(58, 58, 'Flight Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(59, 59, 'Train Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(60, 60, 'Hotel Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(61, 61, 'Bus Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(62, 62, 'Passport Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(63, 63, 'Forex Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(64, 64, 'Excursion Booking Payment Correction', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">ustomer</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(65, 65, 'Airline Topup :', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>Admin<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Airline&nbsp;Top-up&nbsp;successfully done with following transaction details.</font></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(66, 66, 'Visa Topup ', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">â€‹â€‹<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear&nbsp;</span>Admin<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;<span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font color="#000000" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Airline&nbsp;Top-up&nbsp;successfully done with following transaction details.</font></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(67, 67, 'App Settings Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is reminder you to fill up the all information in system app settings.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(68, 68, 'Checklist remainder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is a&nbsp;</span></font><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">pending checklist</span>&nbsp;<font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">reminder&nbsp;</span></font><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">f</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">or</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">&nbsp;following tour.</span></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(69, 69, 'Todays followup', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is a gentle reminder of today''s followups to be taken.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(70, 70, 'Passport Expiry', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Tour passenger passport expiring soon. Please renew before expired.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(71, 71, 'Task Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Your assigned task reminder. Please check in the system.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(72, 72, 'Wish You Happy Birthday', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Wish You Happy Birthday!&nbsp;<br>I hope you have a great day today and enjoy the day with endless happiness and good luck to you!</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(73, 73, 'Wish You Happy Birthday', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">Dear Customer,</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;" trebuchet="" ms",="" sans-serif;"="">&nbsp;</span><br></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Wish You Happy Birthday!<br><br>I hope you have a great day today.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(74, 74, 'Happy Journey', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;</span><br></font></div><div class="gmail_default" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hope all your bags are packed.<br><br>Wish you a very Happy Journey &amp; May You Create the Most Cherishing Moments of your Life in this Trip.</span></font></div></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(75, 75, 'Airline Low Balance Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Please upgrade the airline top-up balance.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(76, 76, 'Visa Low Balance Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Hello,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Please upgrade the airline top-up balance.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(77, 77, 'Wish You Happy Anniversary', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear User,</span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></span><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Wish You Happy Anniversary!</span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(51, 51, 51); background-color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We extend our best wishes to you on your anniversary. We thank you for your enduring loyalty and diligence.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(78, 78, 'Invite you to leave us your FEEDBACK!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would be very grateful if you take couple of minutes to complete our online feedback form by simply Login to our system.</span>&nbsp;&nbsp;</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(79, 79, 'Invite you to leave us your FEEDBACK!', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would be very grateful if you take couple of minutes to complete our online feedback form by simply Login to our system.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(80, 80, 'Group Tour Payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(81, 81, 'Package Tour Payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(82, 82, 'Visa payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(83, 83, 'Flight Payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active');
INSERT INTO `cms_master_entries` (`entry_id`, `id`, `subject`, `draft`, `signature`, `active_flag`) VALUES
(84, 84, 'Train payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(85, 85, 'Hotel payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(87, 87, 'Car Rental payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(88, 88, 'Passport payment Reminder ', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(89, 89, 'Excursion Payment Reminder ', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(90, 90, 'Tax Pay Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Your tax pay due date is</span>&nbsp;coming soon.</font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(91, 91, 'User Visa Status', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Your current visa status :</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(92, 92, 'Vendor Payment Reminder', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">This is vendor payment reminder for :</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(93, 93, 'Weekly Summary report', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><br></font></span></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font face="trebuchet ms, sans-serif" style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;"><span style="color: rgb(255, 255, 255); background-color: transparent; font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Weekly summary report emailed you.</span></font></div>', '<i style="font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i>', 'Active'),
(94, 94, 'Excursion Booking Confirmation', '<b style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">Dear Customer</b>,<div style="background-color: transparent; color: rgb(255, 255, 255); font-size: small; line-height: 21px; font-family: Roboto, sans-serif;">&nbsp;We are thank you for choosing and I hope this journey will give you delightful experience with us.</div>', '<i>Warm Regards</i>,', 'Active'),
(95, 95, 'Leave reply', 'Dear,\r\nThis is officially inform you that your leaves have been sanctioned And make sure that all the pending works get completed soon.', 'Warm Regards,\r\n', 'Active'),
(96, 96, 'Leave Reply', 'Dear,\r\nWe received your application for leave from work, but We are unable to accept it at the moment.', 'Warm Regards,', 'Active'),
(97, 97, 'Payment Acknowledgement', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">â€‹â€‹<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">ustomer</span><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">&nbsp;<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">This is the acknowledge for your payment which we received from you. We would like to take this opportunity to thank you for being a valued customer with us for so long.&nbsp;</span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">Following is the payment details.</span></font></div>', '<i>Warm regards,</i>', 'Active'),
(98, 98, 'Miscellaneous Booking Payment Correction', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><b style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">â€‹â€‹<span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">DearÂ </span>C<span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">ustomer</span><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">,</span></font></b></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">Â <span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><br></span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i>Warm regards,</i>', 'Active'),
(99, 99, 'Miscellaneous Cancellation Confirmation', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><b style="line-height: 21px;"><span trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="" style="line-height: 21px;">Dear&nbsp;</span>C<span trebuchet="" ms",="" sans-serif;"="" style="line-height: 21px;">ustomer</span><font style="line-height: 21px;"><span style="line-height: 21px;">,</span></font></b></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px;">&nbsp;<span style="line-height: 21px;"><br></span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px;"><font style="line-height: 21px;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font></font></div>', '<i>Warm regards,</i>', 'Active'),
(100, 100, 'Miscellaneous Cancellation Refund', 'Dear Customer,<div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">&nbsp;Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.</div>', '<i>Warm regards,</i>', 'Active'),
(101, 101, 'Booking confirmation acknowledgement', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">â€‹â€‹<b style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">Dear Customer,</b></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">Â <span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><br></span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">We are thank you for choosing and I hope this journey will give you delightful experience with us.</span></font></div>', '<i>Warm regards,</i>', 'Active'),
(102, 102, 'Hotel Pre Booking Inventory Cancellation Reminder!', '<div class="gmail_default" style="background-color: transparent; line-height: 21px; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small;"><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Dear Admin,</font></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></font></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">This is gentle reminder of pre-booked hotel cancellation date is coming.</font></div></div> ', 'Warm regards', 'Active'),
(103, 103, 'Excursion Pre Booking Inventory Cancellation Reminder!', '<div class="gmail_default" style="background-color: transparent; line-height: 21px; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif;">Dear Admin,</font></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif;"><br></font></div><div class="gmail_default" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font color="#333333" face="Roboto, sans-serif" size="2" style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif;">This is gentle reminder of pre-booked excursion tickets cancellation date is coming.</font></div></div> ', 'Warm regards', 'Active'),
(104, 104, 'B2B Portal Registration Request!', '<b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Dear Travel Partners,Â </b><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></b><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Herewith I would like to inform you that we''ve launched our B2B travel services online booking portal. And and We assure you to deliver competitive rates as per the market.</div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">We''re passionate to provide #1 help & support and provide 100% to your customers.\n\nRequest you to fill the attached registration form. And will get back to you with your credentials soon.</div></div>', '<i>Looking forward to collaboration with your esteem company.</i><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><i><br></i><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><i>Please note below the Contact details of our support for more information.</i></div></div>', 'Active'),
(105, 105, 'B2B Customer Login', '<span style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Dear Travel Partner,</b></span><br style="color: rgb(34, 34, 34); font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br style="color: rgb(34, 34, 34); font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""><span style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;">Thank you for joinÂ  B2B portal. We''re glad to collaborate business with you.</span><br style="color: rgb(34, 34, 34); font-family: " trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"=""> ', '<i>Warm Regards,</i>', 'Active'),
(106, 106, 'About Credit Limit Increase', '<b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Dear Travel Partner,Â </b><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Thank you for your request.\n\nWe''re sorry to increase the credit limit because of below reason.</div>', '<i>Warm regards,</i>', 'Active'),
(107, 107, 'Credit Limit Increase Acknowledgment', '<b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Dear Travel Partner,</b><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Thank you collaboration and business with us. We''ve reviewed your recent transactions and increase credit limit.</div>', '<i>Warm regards,</i>', 'Active'),
(108, 108, 'Miscellaneous Payment Reminder ', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><b>Dear Customer,</b></span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><br></font></span></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;"><span style="line-height: 21px; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small;">We would like to thank you for booking with us. Hereby request you to release the outstanding payment as per the due date.</span></font></div> ', '<i trebuchet="" ms",="" sans-serif;="" font-size:="" small;="" background-color:="" rgb(255,="" 255,="" 255);"="">Warm Regards,</i> ', 'Active'),
(109, 109, 'Passport Cancellation Confirmation.', '<div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><b style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span trebuchet="" ms",="" sans-serif;="" color:="" rgb(0,="" 0,="" 0);"="" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">Dear&nbsp;</span>C<span trebuchet="" ms",="" sans-serif;"="" style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">ustomer</span><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">,</span></font></b></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">&nbsp;<span style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><br></span></font></div><div class="gmail_default" style="color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: small; background-color: transparent; line-height: 21px;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;"><font style="line-height: 21px; background-color: transparent; color: rgb(255, 255, 255); font-family: Roboto, sans-serif;">We are accepting your cancellation request for genuine reason. We thank you for choosing us and request you to give us another opportunity to offer the best of the tour&nbsp;experience&nbsp;to various exotic locations across the world.</font></font></div> ', '<i>Warm Regards,</i>', 'Active'),
(110, 110, 'Passport Cancellation Refund', 'Dear Customer,<div style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;"><br></div><div style="background-color: transparent; color: rgb(255, 255, 255); line-height: 21px; font-family: Roboto, sans-serif; font-size: small;">Thank you for choosing us. We''ve refund your payment considering your request with following transaction details.<br></div> ', '<i>Warm Regards,</i>', 'Active'),
(111, 111, 'Car Rental Payment Correction', '<div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><b style="line-height: 21px;"><font style="line-height: 21px;">â€‹â€‹<span style="line-height: 21px;">Dear&nbsp;</span>C<span style="line-height: 21px;">ustomer</span><span style="line-height: 21px;">,</span></font></b></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px;">&nbsp;<span style="line-height: 21px;"><br></span></font></div><div class="gmail_default" style="color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: small; background-color: rgb(255, 255, 255); line-height: 21px;"><font style="line-height: 21px;"><span style="line-height: 21px;">Sorry for the inconvenience. Your revised payment details as following.</span></font></div>', '<i>Warm Regards,</i>', 'Active'),
(112, 112, 'B2B Portal Registration Request!', '<div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><b style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">Dear Travel Partner,</b></font></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">Thank you for your application for our B2B portal registration. We really appreciate your interest to explore more services on our online portal.</font></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">We''ve reviewed the primary information and details are not enough as per the norms to approve the registration request.</font></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">So, unfortunately, we have to inform you that this time we wonâ€™t be able to join you.</font></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">If you have any questions or need additional information, please donâ€™t hesitate to contact us by email.</font></div><div style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;"><font color="#333333" size="2" style="background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-size: small;">We wish you every personal and professional success in your future endeavour.</font></div><div style="color: rgb(51, 51, 51); font-size: small; background-color: rgb(255, 255, 255);"><br></div></div> ', '<i>Warm Regards</i>', '');

-- --------------------------------------------------------

--
-- Table structure for table `corporate_advance_master`
--

CREATE TABLE IF NOT EXISTS `corporate_advance_master` (
  `advance_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `particular` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `ledger_id` int(11) NOT NULL,
  PRIMARY KEY (`advance_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `country_list_master`
--

CREATE TABLE IF NOT EXISTS `country_list_master` (
  `country_id` int(11) NOT NULL,
  `country_code` varchar(100) NOT NULL,
  `country_name` varchar(300) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country_list_master`
--

INSERT INTO `country_list_master` (`country_id`, `country_code`, `country_name`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'AS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua And Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia And Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei Darussalam'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CD', 'Congo, The Democratic Republic Of The'),
(51, 'CK', 'Cook Islands'),
(52, 'CR', 'Costa Rica'),
(53, 'CI', 'Cote D''ivoire'),
(54, 'HR', 'Croatia'),
(55, 'CU', 'Cuba'),
(56, 'CY', 'Cyprus'),
(57, 'CZ', 'Czech Republic'),
(58, 'DK', 'Denmark'),
(59, 'DJ', 'Djibouti'),
(60, 'DM', 'Dominica'),
(61, 'DO', 'Dominican Republic'),
(62, 'TP', 'East Timor'),
(63, 'EC', 'Ecuador'),
(64, 'EG', 'Egypt'),
(65, 'SV', 'El Salvador'),
(66, 'GQ', 'Equatorial Guinea'),
(67, 'ER', 'Eritrea'),
(68, 'EE', 'Estonia'),
(69, 'ET', 'Ethiopia'),
(70, 'FK', 'Falkland Islands (malvinas)'),
(71, 'FO', 'Faroe Islands'),
(72, 'FJ', 'Fiji'),
(73, 'FI', 'Finland'),
(74, 'FR', 'France'),
(75, 'GF', 'French Guiana'),
(76, 'PF', 'French Polynesia'),
(77, 'TF', 'French Southern Territories'),
(78, 'GA', 'Gabon'),
(79, 'GM', 'Gambia'),
(80, 'GE', 'Georgia'),
(81, 'DE', 'Germany'),
(82, 'GH', 'Ghana'),
(83, 'GI', 'Gibraltar'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard Island And Mcdonald Islands'),
(95, 'VA', 'Holy See (vatican City State)'),
(96, 'HN', 'Honduras'),
(97, 'HK', 'Hong Kong'),
(98, 'HU', 'Hungary'),
(99, 'IS', 'Iceland'),
(100, 'IN', 'India'),
(101, 'ID', 'Indonesia'),
(102, 'IR', 'Iran, Islamic Republic Of'),
(103, 'IQ', 'Iraq'),
(104, 'IE', 'Ireland'),
(105, 'IL', 'Israel'),
(106, 'IT', 'Italy'),
(107, 'JM', 'Jamaica'),
(108, 'JP', 'Japan'),
(109, 'JO', 'Jordan'),
(110, 'KZ', 'Kazakstan'),
(111, 'KE', 'Kenya'),
(112, 'KI', 'Kiribati'),
(113, 'KP', 'Korea, Democratic People''s Republic Of'),
(114, 'KR', 'Korea, Republic Of'),
(115, 'KV', 'Kosovo'),
(116, 'KW', 'Kuwait'),
(117, 'KG', 'Kyrgyzstan'),
(118, 'LA', 'Lao People''s Democratic Republic'),
(119, 'LV', 'Latvia'),
(120, 'LB', 'Lebanon'),
(121, 'LS', 'Lesotho'),
(122, 'LR', 'Liberia'),
(123, 'LY', 'Libyan Arab Jamahiriya'),
(124, 'LI', 'Liechtenstein'),
(125, 'LT', 'Lithuania'),
(126, 'LU', 'Luxembourg'),
(127, 'MO', 'Macau'),
(128, 'MK', 'Macedonia, The Former Yugoslav Republic Of'),
(129, 'MG', 'Madagascar'),
(130, 'MW', 'Malawi'),
(131, 'MY', 'Malaysia'),
(132, 'MV', 'Maldives'),
(133, 'ML', 'Mali'),
(134, 'MT', 'Malta'),
(135, 'MH', 'Marshall Islands'),
(136, 'MQ', 'Martinique'),
(137, 'MR', 'Mauritania'),
(138, 'MU', 'Mauritius'),
(139, 'YT', 'Mayotte'),
(140, 'MX', 'Mexico'),
(141, 'FM', 'Micronesia, Federated States Of'),
(142, 'MD', 'Moldova, Republic Of'),
(143, 'MC', 'Monaco'),
(144, 'MN', 'Mongolia'),
(145, 'MS', 'Montserrat'),
(146, 'ME', 'Montenegro'),
(147, 'MA', 'Morocco'),
(148, 'MZ', 'Mozambique'),
(149, 'MM', 'Myanmar'),
(150, 'NA', 'Namibia'),
(151, 'NR', 'Nauru'),
(152, 'NP', 'Nepal'),
(153, 'NL', 'Netherlands'),
(154, 'AN', 'Netherlands Antilles'),
(155, 'NC', 'New Caledonia'),
(156, 'NZ', 'New Zealand'),
(157, 'NI', 'Nicaragua'),
(158, 'NE', 'Niger'),
(159, 'NG', 'Nigeria'),
(160, 'NU', 'Niue'),
(161, 'NF', 'Norfolk Island'),
(162, 'MP', 'Northern Mariana Islands'),
(163, 'NO', 'Norway'),
(164, 'OM', 'Oman'),
(165, 'PK', 'Pakistan'),
(166, 'PW', 'Palau'),
(167, 'PS', 'Palestinian Territory, Occupied'),
(168, 'PA', 'Panama'),
(169, 'PG', 'Papua New Guinea'),
(170, 'PY', 'Paraguay'),
(171, 'PE', 'Peru'),
(172, 'PH', 'Philippines'),
(173, 'PN', 'Pitcairn'),
(174, 'PL', 'Poland'),
(175, 'PT', 'Portugal'),
(176, 'PR', 'Puerto Rico'),
(177, 'QA', 'Qatar'),
(178, 'RE', 'Reunion'),
(179, 'RO', 'Romania'),
(180, 'RU', 'Russian Federation'),
(181, 'RW', 'Rwanda'),
(182, 'SH', 'Saint Helena'),
(183, 'KN', 'Saint Kitts And Nevis'),
(184, 'LC', 'Saint Lucia'),
(185, 'PM', 'Saint Pierre And Miquelon'),
(186, 'VC', 'Saint Vincent And The Grenadines'),
(187, 'WS', 'Samoa'),
(188, 'SM', 'San Marino'),
(189, 'ST', 'Sao Tome And Principe'),
(190, 'SA', 'Saudi Arabia'),
(191, 'SN', 'Senegal'),
(192, 'RS', 'Serbia'),
(193, 'SC', 'Seychelles'),
(194, 'SL', 'Sierra Leone'),
(195, 'SG', 'Singapore'),
(196, 'SK', 'Slovakia'),
(197, 'SI', 'Slovenia'),
(198, 'SB', 'Solomon Islands'),
(199, 'SO', 'Somalia'),
(200, 'ZA', 'South Africa'),
(201, 'GS', 'South Georgia And The South Sandwich Islands'),
(202, 'ES', 'Spain'),
(203, 'LK', 'Sri Lanka'),
(204, 'SD', 'Sudan'),
(205, 'SR', 'Suriname'),
(206, 'SJ', 'Svalbard And Jan Mayen'),
(207, 'SZ', 'Swaziland'),
(208, 'SE', 'Sweden'),
(209, 'CH', 'Switzerland'),
(210, 'SY', 'Syrian Arab Republic'),
(211, 'TW', 'Taiwan, Province Of China'),
(212, 'TJ', 'Tajikistan'),
(213, 'TZ', 'Tanzania, United Republic Of'),
(214, 'TH', 'Thailand'),
(215, 'TG', 'Togo'),
(216, 'TK', 'Tokelau'),
(217, 'TO', 'Tonga'),
(218, 'TT', 'Trinidad And Tobago'),
(219, 'TN', 'Tunisia'),
(220, 'TR', 'Turkey'),
(221, 'TM', 'Turkmenistan'),
(222, 'TC', 'Turks And Caicos Islands'),
(223, 'TV', 'Tuvalu'),
(224, 'UG', 'Uganda'),
(225, 'UA', 'Ukraine'),
(226, 'AE', 'United Arab Emirates'),
(227, 'GB', 'United Kingdom'),
(228, 'US', 'United States'),
(229, 'UM', 'United States Minor Outlying Islands'),
(230, 'UY', 'Uruguay'),
(231, 'UZ', 'Uzbekistan'),
(232, 'VU', 'Vanuatu'),
(233, 'VE', 'Venezuela'),
(234, 'VN', 'Viet Nam'),
(235, 'VG', 'Virgin Islands, British'),
(236, 'VI', 'Virgin Islands, U.s.'),
(237, 'WF', 'Wallis And Futuna'),
(238, 'EH', 'Western Sahara'),
(239, 'YE', 'Yemen'),
(240, 'ZM', 'Zambia'),
(241, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `country_state_list`
--

CREATE TABLE IF NOT EXISTS `country_state_list` (
  `id` int(100) NOT NULL,
  `country_name` varchar(300) NOT NULL,
  `state_name` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country_state_list`
--

INSERT INTO `country_state_list` (`id`, `country_name`, `state_name`) VALUES
(1, 'Afganistan', 'Badakhshan'),
(2, 'Afganistan', 'Badghis'),
(3, 'Afganistan', 'Baghlan'),
(4, 'Afganistan', 'Balkh'),
(5, 'Afganistan', 'Bamyan'),
(6, 'Afganistan', 'Daykundi'),
(7, 'Afganistan', 'Farah'),
(8, 'Afganistan', 'Faryab'),
(9, 'Afganistan', 'Ghazni'),
(10, 'Afganistan', 'Ghowr'),
(11, 'Afganistan', 'Helmand'),
(12, 'Afganistan', 'Herat'),
(13, 'Afganistan', 'Jowzjan'),
(14, 'Afganistan', 'Kabul'),
(15, 'Afganistan', 'Kandahar'),
(16, 'Afganistan', 'Kapisa'),
(17, 'Afganistan', 'Khowst'),
(18, 'Afganistan', 'Kunar'),
(19, 'Afganistan', 'Kunduz'),
(20, 'Afganistan', 'Laghman'),
(21, 'Afganistan', 'Logar'),
(22, 'Afganistan', 'Nangarhar'),
(23, 'Afganistan', 'Nimroz'),
(24, 'Afganistan', 'Nuristan'),
(25, 'Afganistan', 'Oruzgan'),
(26, 'Afganistan', 'Paktia'),
(27, 'Afganistan', 'Paktika'),
(28, 'Afganistan', 'Panjshir'),
(29, 'Afganistan', 'Parwan'),
(30, 'Afganistan', 'Samangan'),
(31, 'Afganistan', 'Sar-e Pul'),
(32, 'Afganistan', 'Takhar'),
(33, 'Afganistan', 'Wardak'),
(34, 'Afganistan', 'Zabul'),
(35, 'Armenia', 'Aragatsotn'),
(36, 'Armenia', 'Ararat'),
(37, 'Armenia', 'Armavir'),
(38, 'Armenia', 'Gegharkunik'),
(39, 'Armenia', 'Kotayk'),
(40, 'Armenia', 'Lori'),
(41, 'Armenia', 'Shirak'),
(42, 'Armenia', 'Syunik'),
(43, 'Armenia', 'Tavush'),
(44, 'Armenia', 'Vayots Dzor'),
(45, 'Armenia', 'Yerevan'),
(46, 'Azerbaijan', 'Absheron Rayon'),
(47, 'Azerbaijan', 'Aghdam Rayon'),
(48, 'Azerbaijan', 'Aghdash Rayon'),
(49, 'Azerbaijan', 'Aghjabadi Rayon'),
(50, 'Azerbaijan', 'Aghstafa Rayon'),
(51, 'Azerbaijan', 'Aghsu Rayon'),
(52, 'Azerbaijan', 'Astara'),
(53, 'Azerbaijan', 'Baku City'),
(54, 'Azerbaijan', 'Balakan Rayon'),
(55, 'Azerbaijan', 'Barda Rayon'),
(56, 'Azerbaijan', 'Beylagan Rayon'),
(57, 'Azerbaijan', 'Bilasuvar Rayon'),
(58, 'Azerbaijan', 'Dashkasan Rayon'),
(59, 'Azerbaijan', 'Fizuli Rayon'),
(60, 'Azerbaijan', 'Gadabay Rayon'),
(61, 'Azerbaijan', 'Ganja City'),
(62, 'Azerbaijan', 'Gobustan Rayon'),
(63, 'Azerbaijan', 'Goranboy Rayon'),
(64, 'Azerbaijan', 'Goychay Rayon'),
(65, 'Azerbaijan', 'Goygol Rayon'),
(66, 'Azerbaijan', 'Hajigabul Rayon'),
(67, 'Azerbaijan', 'Imishli Rayon'),
(68, 'Azerbaijan', 'Ismayilli Rayon'),
(69, 'Azerbaijan', 'Jabrayil'),
(70, 'Azerbaijan', 'Jalilabad'),
(71, 'Azerbaijan', 'Kalbajar'),
(72, 'Azerbaijan', 'Khachmaz Rayon'),
(73, 'Azerbaijan', 'Khizi Rayon'),
(74, 'Azerbaijan', 'Khojavend'),
(75, 'Azerbaijan', 'Kurdamir Rayon'),
(76, 'Azerbaijan', 'Lankaran Rayon'),
(77, 'Azerbaijan', 'Lankaran Sahari'),
(78, 'Azerbaijan', 'Laç?n Rayonu'),
(79, 'Azerbaijan', 'Lerik Rayon'),
(80, 'Azerbaijan', 'Masally'),
(81, 'Azerbaijan', 'Mingacevir City'),
(82, 'Azerbaijan', 'Naftalan City'),
(83, 'Azerbaijan', 'Nakhchivan'),
(84, 'Azerbaijan', 'Nakhichevan'),
(85, 'Azerbaijan', 'Neftchala Rayon'),
(86, 'Azerbaijan', 'Oghuz Rayon'),
(87, 'Azerbaijan', 'Qabala Rayon'),
(88, 'Azerbaijan', 'Qakh Rayon'),
(89, 'Azerbaijan', 'Qazakh Rayon'),
(90, 'Azerbaijan', 'Quba Rayon'),
(91, 'Azerbaijan', 'Qubadli Rayon'),
(92, 'Azerbaijan', 'Qusar Rayon'),
(93, 'Azerbaijan', 'Saatly Rayon'),
(94, 'Azerbaijan', 'Sabirabad Rayon'),
(95, 'Azerbaijan', 'Salyan Rayon'),
(96, 'Azerbaijan', 'Samukh Rayon'),
(97, 'Azerbaijan', 'Shabran'),
(98, 'Azerbaijan', 'Shaki City'),
(99, 'Azerbaijan', 'Shaki Rayon'),
(100, 'Azerbaijan', 'Shamakhi Rayon'),
(101, 'Azerbaijan', 'Shamkir Rayon'),
(102, 'Azerbaijan', 'Shirvan'),
(103, 'Azerbaijan', 'Shusha'),
(104, 'Azerbaijan', 'Siazan Rayon'),
(105, 'Azerbaijan', 'Sumqayit City'),
(106, 'Azerbaijan', 'Tartar Rayon'),
(107, 'Azerbaijan', 'Tovuz Rayon'),
(108, 'Azerbaijan', 'Ujar Rayon'),
(109, 'Azerbaijan', 'Xankandi Sahari'),
(110, 'Azerbaijan', 'Xocal? Rayonu'),
(111, 'Azerbaijan', 'Yardymli Rayon'),
(112, 'Azerbaijan', 'Yevlakh Rayon'),
(113, 'Azerbaijan', 'Yevlax City'),
(114, 'Azerbaijan', 'Zangilan Rayon'),
(115, 'Azerbaijan', 'Zaqatala Rayon'),
(116, 'Azerbaijan', 'Zardab Rayon'),
(117, 'Azerbaijan', '?u?a Rayonu'),
(118, 'Bahrain', 'Manama'),
(119, 'Bahrain', 'Muharraq'),
(120, 'Bahrain', 'Northern Governorate'),
(121, 'Bahrain', 'Southern Governorate'),
(122, 'Bangladesh', 'Barisal Division'),
(123, 'Bangladesh', 'Chittagong'),
(124, 'Bangladesh', 'Dhaka Division'),
(125, 'Bangladesh', 'Khulna Division'),
(126, 'Bangladesh', 'Mymensingh Division'),
(127, 'Bangladesh', 'Rangpur Division'),
(128, 'Bangladesh', 'R?jsh?hi Division'),
(129, 'Bangladesh', 'Sylhet Division'),
(130, 'Bhutan', 'Bumthang Dzongkhag'),
(131, 'Bhutan', 'Chukha'),
(132, 'Bhutan', 'Dagana'),
(133, 'Bhutan', 'Gasa'),
(134, 'Bhutan', 'Haa'),
(135, 'Bhutan', 'Lhuntse'),
(136, 'Bhutan', 'Mongar'),
(137, 'Bhutan', 'Paro'),
(138, 'Bhutan', 'Pemagatshel'),
(139, 'Bhutan', 'Punakha Dzongkhag'),
(140, 'Bhutan', 'Samdrup Jongkhar'),
(141, 'Bhutan', 'Samtse Dzongkhag'),
(142, 'Bhutan', 'Sarpang Dzongkhag'),
(143, 'Bhutan', 'Thimphu Dzongkhag'),
(144, 'Bhutan', 'Trashi Yangste'),
(145, 'Bhutan', 'Trashigang Dzongkhag'),
(146, 'Bhutan', 'Trongsa Dzongkhag'),
(147, 'Bhutan', 'Tsirang Dzongkhag'),
(148, 'Bhutan', 'Wangdue Phodrang Dzongkhag'),
(149, 'Bhutan', 'Zhemgang Dzongkhag'),
(150, 'Brunei', 'Belait District'),
(151, 'Brunei', 'Brunei and Muara District'),
(152, 'Brunei', 'Temburong District'),
(153, 'Brunei', 'Tutong District'),
(154, 'Combodia', 'Banteay Meanchey'),
(155, 'Combodia', 'Battambang'),
(156, 'Combodia', 'Kampong Cham'),
(157, 'Combodia', 'Kampong Chhnang Province'),
(158, 'Combodia', 'Kampong Speu'),
(159, 'Combodia', 'Kampong Thom'),
(160, 'Combodia', 'Kampot'),
(161, 'Combodia', 'Kandal'),
(162, 'Combodia', 'Kep'),
(163, 'Combodia', 'Koh Kong'),
(164, 'Combodia', 'Kratie'),
(165, 'Combodia', 'Mondolkiri'),
(166, 'Combodia', 'Pailin'),
(167, 'Combodia', 'Phnom Penh'),
(168, 'Combodia', 'Preah Sihanouk'),
(169, 'Combodia', 'Preah Vihear'),
(170, 'Combodia', 'Prey Veng'),
(171, 'Combodia', 'Pursat'),
(172, 'Combodia', 'Ratanakiri Province'),
(173, 'Combodia', 'Siem Reap'),
(174, 'Combodia', 'Stung Treng'),
(175, 'Combodia', 'Svay Rieng'),
(176, 'Combodia', 'Takeo'),
(177, 'Combodia', 'Tboung Khmum'),
(178, 'Combodia', '?târ Méanchey'),
(179, 'China', 'Anhui'),
(180, 'China', 'Beijing'),
(181, 'China', 'Chongqing'),
(182, 'China', 'Fujian'),
(183, 'China', 'Gansu'),
(184, 'China', 'Guangdong'),
(185, 'China', 'Guangxi'),
(186, 'China', 'Guizhou'),
(187, 'China', 'Hainan'),
(188, 'China', 'Hebei'),
(189, 'China', 'Heilongjiang'),
(190, 'China', 'Henan'),
(191, 'China', 'Hubei'),
(192, 'China', 'Hunan'),
(193, 'China', 'Inner Mongolia'),
(194, 'China', 'Jiangsu'),
(195, 'China', 'Jiangxi'),
(196, 'China', 'Jilin'),
(197, 'China', 'Liaoning'),
(198, 'China', 'Ningsia Hui Autonomous Region'),
(199, 'China', 'Qinghai'),
(200, 'China', 'Shaanxi'),
(201, 'China', 'Shandong'),
(202, 'China', 'Shanghai'),
(203, 'China', 'Shanxi'),
(204, 'China', 'Sichuan'),
(205, 'China', 'Tianjin'),
(206, 'China', 'Tibet'),
(207, 'China', 'Xinjiang'),
(208, 'China', 'Yunnan'),
(209, 'China', 'Zhejiang'),
(210, 'Georgia', 'Abkhazia'),
(211, 'Georgia', 'Ajaria'),
(212, 'Georgia', 'Guria'),
(213, 'Georgia', 'Imereti'),
(214, 'Georgia', 'Kakheti'),
(215, 'Georgia', 'Kvemo Kartli'),
(216, 'Georgia', 'Mtskheta-Mtianeti'),
(217, 'Georgia', 'Racha-Lechkhumi and Kvemo Svaneti'),
(218, 'Georgia', 'Samegrelo and Zemo Svaneti'),
(219, 'Georgia', 'Samtskhe-Javakheti'),
(220, 'Georgia', 'Shida Kartli'),
(221, 'Hongkong', 'Central and Western District'),
(222, 'Hongkong', 'Eastern'),
(223, 'Hongkong', 'Islands District'),
(224, 'Hongkong', 'Kowloon City'),
(225, 'Hongkong', 'Kwai Tsing'),
(226, 'Hongkong', 'Kwun Tong'),
(227, 'Hongkong', 'North'),
(228, 'Hongkong', 'Sai Kung District'),
(229, 'Hongkong', 'Sha Tin'),
(230, 'Hongkong', 'Sham Shui Po'),
(231, 'Hongkong', 'Southern'),
(232, 'Hongkong', 'Tai Po District'),
(233, 'Hongkong', 'Tsuen Wan District'),
(234, 'Hongkong', 'Tuen Mun'),
(235, 'Hongkong', 'Wan Chai'),
(236, 'Hongkong', 'Wong Tai Sin'),
(237, 'Hongkong', 'Yau Tsim Mong'),
(238, 'Hongkong', 'Yuen Long District'),
(239, 'India', 'Andaman and Nicobar'),
(240, 'India', 'Andhra Pradesh'),
(241, 'India', 'Arunachal Pradesh'),
(242, 'India', 'Assam'),
(243, 'India', 'Bihar'),
(244, 'India', 'Chandigarh'),
(245, 'India', 'Chhattisgarh'),
(246, 'India', 'Dadra and Nagar Haveli'),
(247, 'India', 'Daman and Diu'),
(248, 'India', 'Goa'),
(249, 'India', 'Gujarat'),
(250, 'India', 'Haryana'),
(251, 'India', 'Himachal Pradesh'),
(252, 'India', 'Jharkhand'),
(253, 'India', 'Karnataka'),
(254, 'India', 'Kashmir'),
(255, 'India', 'Kerala'),
(256, 'India', 'Laccadives'),
(257, 'India', 'Madhya Pradesh'),
(258, 'India', 'Maharashtra'),
(259, 'India', 'Manipur'),
(260, 'India', 'Meghalaya'),
(261, 'India', 'Mizoram'),
(262, 'India', 'NCT'),
(263, 'India', 'Nagaland'),
(264, 'India', 'Odisha'),
(265, 'India', 'Punjab'),
(266, 'India', 'Rajasthan'),
(267, 'Indonesia', 'Sikkim'),
(268, 'Indonesia', 'Tamil Nadu'),
(269, 'Indonesia', 'Telangana'),
(270, 'Indonesia', 'Tripura'),
(271, 'Indonesia', 'Union Territory of Puducherry'),
(272, 'Indonesia', 'Uttar Pradesh'),
(273, 'Indonesia', 'Uttarakhand'),
(274, 'Indonesia', 'West Bengal'),
(275, 'Indonesia', 'Central Sulawesi'),
(276, 'Indonesia', 'East Java'),
(277, 'Indonesia', 'East Kalimantan'),
(278, 'Indonesia', 'East Nusa Tenggara'),
(279, 'Indonesia', 'Gorontalo'),
(280, 'Indonesia', 'Jakarta'),
(281, 'Indonesia', 'Jambi'),
(282, 'Indonesia', 'Lampung'),
(283, 'Indonesia', 'Maluku'),
(284, 'Indonesia', 'North Kalimantan'),
(285, 'Indonesia', 'North Maluku'),
(286, 'Indonesia', 'North Sulawesi'),
(287, 'Indonesia', 'North Sumatra'),
(288, 'Indonesia', 'Papua'),
(289, 'Indonesia', 'Riau'),
(290, 'Indonesia', 'Riau Islands'),
(291, 'Indonesia', 'South Kalimantan'),
(292, 'Indonesia', 'South Sulawesi'),
(293, 'Indonesia', 'South Sumatra'),
(294, 'Indonesia', 'Southeast Sulawesi'),
(295, 'Indonesia', 'West Java'),
(296, 'Indonesia', 'West Kalimantan'),
(297, 'Indonesia', 'West Nusa Tenggara'),
(298, 'Indonesia', 'West Papua'),
(299, 'Indonesia', 'West Sulawesi'),
(300, 'Indonesia', 'West Sumatra'),
(301, 'Indonesia', 'Yogyakart'),
(302, 'Iran', 'Alborz'),
(303, 'Iran', 'Bushehr'),
(304, 'Iran', 'Chaharmahal and Bakhtiari'),
(305, 'Iran', 'East Azerbaijan'),
(306, 'Iran', 'Fars'),
(307, 'Iran', 'Hormozgan'),
(308, 'Iran', 'Isfahan'),
(309, 'Iran', 'Kerman'),
(310, 'Iran', 'Khuzestan'),
(311, 'Iran', 'Markazi'),
(312, 'Iran', 'M?zandar?n'),
(313, 'Iran', 'Ost?n-e Ardab?l'),
(314, 'Iran', 'Ost?n-e Golest?n'),
(315, 'Iran', 'Ost?n-e G?l?n'),
(316, 'Iran', 'Ost?n-e Hamad?n'),
(317, 'Iran', 'Ost?n-e Kerm?nsh?h'),
(318, 'Iran', 'Ost?n-e Khor?s?n-e Jon?b?'),
(319, 'Iran', 'Ost?n-e Khor?s?n-e Shom?l?'),
(320, 'Iran', 'Ost?n-e Kohg?l?yeh va Bowyer A?mad'),
(321, 'Iran', 'Ost?n-e Kordest?n'),
(322, 'Iran', 'Ost?n-e Lorest?n'),
(323, 'Iran', 'Ost?n-e Qazv?n'),
(324, 'Iran', 'Ost?n-e Tehr?n'),
(325, 'Iran', 'Ost?n-e ?z?arb?yj?n-e Gharb?'),
(326, 'Iran', 'Ost?n-e ?l?m'),
(327, 'Iran', 'Qom'),
(328, 'Iran', 'Razavi Khorasan'),
(329, 'Iran', 'Semn?n'),
(330, 'Iran', 'Sistan and Baluchestan'),
(331, 'Iran', 'Yazd'),
(332, 'Iran', 'Zanjan'),
(333, 'Iraq', 'An Najaf'),
(334, 'Iraq', 'Anbar Governorate'),
(335, 'Iraq', 'Baghdad'),
(336, 'Iraq', 'Basra'),
(337, 'Iraq', 'Dhi Qar'),
(338, 'Iraq', 'Dihok'),
(339, 'Iraq', 'Diy?lá'),
(340, 'Iraq', 'Kirkuk'),
(341, 'Iraq', 'Maysan'),
(342, 'Iraq', 'Muhafazat Wasit'),
(343, 'Iraq', 'Mu??faz?at Arb?l'),
(344, 'Iraq', 'Mu??faz?at B?bil'),
(345, 'Iraq', 'Mu??faz?at Karbal?’'),
(346, 'Iraq', 'Mu??faz?at N?nawá'),
(347, 'Iraq', 'Mu??faz?at al Muthanná'),
(348, 'Iraq', 'Mu??faz?at al Q?dis?yah'),
(349, 'Iraq', 'Mu??faz?at as Sulaym?n?yah'),
(350, 'Iraq', 'Salah ad Din'),
(351, 'Israel', 'Central District'),
(352, 'Israel', 'Haifa'),
(353, 'Israel', 'Jerusalem'),
(354, 'Israel', 'Northern District'),
(355, 'Israel', 'Southern District'),
(356, 'Israel', 'Tel Aviv'),
(357, 'Japan', 'Aichi'),
(358, 'Japan', 'Akita'),
(359, 'Japan', 'Aomori'),
(360, 'Japan', 'Chiba'),
(361, 'Japan', 'Ehime'),
(362, 'Japan', 'Fukui'),
(363, 'Japan', 'Fukuoka'),
(364, 'Japan', 'Fukushima'),
(365, 'Japan', 'Gifu'),
(366, 'Japan', 'Gunma'),
(367, 'Japan', 'Hiroshima'),
(368, 'Japan', 'Hokkaido'),
(369, 'Japan', 'Hy?go'),
(370, 'Japan', 'Ibaraki'),
(371, 'Japan', 'Ishikawa'),
(372, 'Japan', 'Iwate'),
(373, 'Japan', 'Kagawa'),
(374, 'Japan', 'Kagoshima'),
(375, 'Japan', 'Kanagawa'),
(376, 'Japan', 'Kochi'),
(377, 'Japan', 'Kumamoto'),
(378, 'Japan', 'Kyoto'),
(379, 'Japan', 'Mie'),
(380, 'Japan', 'Miyagi'),
(381, 'Japan', 'Miyazaki'),
(382, 'Japan', 'Nagano'),
(383, 'Japan', 'Nagasaki'),
(384, 'Japan', 'Nara'),
(385, 'Japan', 'Niigata'),
(386, 'Japan', 'Oita'),
(387, 'Japan', 'Okayama'),
(388, 'Japan', 'Okinawa'),
(389, 'Japan', 'Saga'),
(390, 'Japan', 'Saitama'),
(391, 'Japan', 'Shiga'),
(392, 'Japan', 'Shimane'),
(393, 'Japan', 'Shizuoka'),
(394, 'Japan', 'Tokushima'),
(395, 'Japan', 'Tokyo'),
(396, 'Japan', 'Tottori'),
(397, 'Japan', 'Toyama'),
(398, 'Japan', 'Wakayama'),
(399, 'Japan', 'Yamaguchi'),
(400, 'Japan', 'Yamanashi'),
(401, 'Japan', 'saka'),
(402, 'Jordan', 'Ajloun'),
(403, 'Jordan', 'Amman'),
(404, 'Jordan', 'Aqaba'),
(405, 'Jordan', 'Balqa'),
(406, 'Jordan', 'Irbid'),
(407, 'Jordan', 'Jerash'),
(408, 'Jordan', 'Karak'),
(409, 'Jordan', 'Mafraq'),
(410, 'Jordan', 'Ma’an'),
(411, 'Jordan', 'Tafielah'),
(412, 'Jordan', 'Zarqa'),
(413, 'Kazakhstan', 'Aktyubinskaya Oblast’'),
(414, 'Kazakhstan', 'Almaty Oblysy'),
(415, 'Kazakhstan', 'Almaty Qalasy'),
(416, 'Kazakhstan', 'Aqmola Oblysy'),
(417, 'Kazakhstan', 'Astana Qalasy'),
(418, 'Kazakhstan', 'Atyra? Oblysy'),
(419, 'Kazakhstan', 'Baikonur'),
(420, 'Kazakhstan', 'East Kazakhstan'),
(421, 'Kazakhstan', 'Mangistauskaya Oblast’'),
(422, 'Kazakhstan', 'North Kazakhstan'),
(423, 'Kazakhstan', 'Pavlodar Oblysy'),
(424, 'Kazakhstan', 'Qaraghandy Oblysy'),
(425, 'Kazakhstan', 'Qostanay Oblysy'),
(426, 'Kazakhstan', 'Qyzylorda Oblysy'),
(427, 'Kazakhstan', 'South Kazakhstan'),
(428, 'Kazakhstan', 'West Kazakhstan'),
(429, 'Kazakhstan', 'Zhambyl Oblysy'),
(430, 'Kuwait', 'Al Asimah'),
(431, 'Kuwait', 'Al A?mad?'),
(432, 'Kuwait', 'Al Farwaniyah'),
(433, 'Kuwait', 'Hawalli'),
(434, 'Kuwait', 'Mub?rak al Kab?r'),
(435, 'Kuwait', 'Mu??faz?at al Jahr?’'),
(436, 'Kyrgyzstan', 'Batken'),
(437, 'Kyrgyzstan', 'Chuyskaya Oblast’'),
(438, 'Kyrgyzstan', 'Gorod Bishkek'),
(439, 'Kyrgyzstan', 'Issyk-Kul'),
(440, 'Kyrgyzstan', 'Jalal-Abad oblast'),
(441, 'Kyrgyzstan', 'Naryn oblast'),
(442, 'Kyrgyzstan', 'Osh City'),
(443, 'Kyrgyzstan', 'Osh Oblasty'),
(444, 'Kyrgyzstan', 'Talas'),
(445, 'Laos', 'Attapu'),
(446, 'Laos', 'Bokeo'),
(447, 'Laos', 'Bolikhamsai'),
(448, 'Laos', 'Champasak'),
(449, 'Laos', 'Houaphan'),
(450, 'Laos', 'Khammouan'),
(451, 'Laos', 'Khouèng Oudômxai'),
(452, 'Laos', 'Khouèng Phôngsali'),
(453, 'Laos', 'Khouèng Savannakhét'),
(454, 'Laos', 'Khouèng Xékong'),
(455, 'Laos', 'Louangnamtha'),
(456, 'Laos', 'Luang Prabang Province'),
(457, 'Laos', 'Salavan'),
(458, 'Laos', 'Vientiane'),
(459, 'Laos', 'Vientiane Prefecture'),
(460, 'Laos', 'Xaignabouli'),
(461, 'Laos', 'Xaisomboun'),
(462, 'Laos', 'Xiangkhouang'),
(463, 'Lebanon', 'Beyrouth'),
(464, 'Lebanon', 'Mohafazat Aakkâr'),
(465, 'Lebanon', 'Mohafazat Baalbek-Hermel'),
(466, 'Lebanon', 'Mohafazat Béqaa'),
(467, 'Lebanon', 'Mohafazat Liban-Nord'),
(468, 'Lebanon', 'Mohafazat Mont-Liban'),
(469, 'Lebanon', 'Mohafazat Nabatîyé'),
(470, 'Lebanon', 'South Governorate'),
(471, 'Malaysia', 'Johor'),
(472, 'Malaysia', 'Kedah'),
(473, 'Malaysia', 'Kelantan'),
(474, 'Malaysia', 'Kuala Lumpur'),
(475, 'Malaysia', 'Labuan'),
(476, 'Malaysia', 'Melaka'),
(477, 'Malaysia', 'Negeri Sembilan'),
(478, 'Malaysia', 'Pahang'),
(479, 'Malaysia', 'Penang'),
(480, 'Malaysia', 'Perak'),
(481, 'Malaysia', 'Perlis'),
(482, 'Malaysia', 'Putrajaya'),
(483, 'Malaysia', 'Sabah'),
(484, 'Malaysia', 'Sarawak'),
(485, 'Malaysia', 'Selangor'),
(486, 'Malaysia', 'Terengganu'),
(487, 'Maldives', 'Baa Atholhu'),
(488, 'Maldives', 'Dhaalu Atholhu'),
(489, 'Maldives', 'Faafu Atholhu'),
(490, 'Maldives', 'Gaafu Alifu Atholhu'),
(491, 'Maldives', 'Gaafu Dhaalu Atholhu'),
(492, 'Maldives', 'Gnyaviyani Atoll'),
(493, 'Maldives', 'Haa Alifu Atholhu'),
(494, 'Maldives', 'Haa Dhaalu Atholhu'),
(495, 'Maldives', 'Kaafu Atoll'),
(496, 'Maldives', 'Laamu Atholhu'),
(497, 'Maldives', 'Lhaviyani Atholhu'),
(498, 'Maldives', 'Meemu Atholhu'),
(499, 'Maldives', 'Noonu Atoll'),
(500, 'Maldives', 'Northern Ari Atoll'),
(501, 'Maldives', 'Raa Atoll'),
(502, 'Maldives', 'Seenu Atholhu'),
(503, 'Maldives', 'Shaviyani Atholhu'),
(504, 'Maldives', 'Southern Ari Atoll'),
(505, 'Maldives', 'Thaa Atholhu'),
(506, 'Maldives', 'Vaavu Atholhu'),
(507, 'Mongolia', 'Arhangay Aymag'),
(508, 'Mongolia', 'Bayan-Ölgiy Aymag'),
(509, 'Mongolia', 'Bayanhongor Aymag'),
(510, 'Mongolia', 'Bulgan'),
(511, 'Mongolia', 'Central'),
(512, 'Mongolia', 'Darhan-Uul Aymag'),
(513, 'Mongolia', 'Dzavhan Aymag'),
(514, 'Mongolia', 'East Aimak'),
(515, 'Mongolia', 'East Gov?'),
(516, 'Mongolia', 'Gov?-Altay Aymag'),
(517, 'Mongolia', 'Gov?-Sumber'),
(518, 'Mongolia', 'Hentiy Aymag'),
(519, 'Mongolia', 'Hovd'),
(520, 'Mongolia', 'Hövsgöl Aymag'),
(521, 'Mongolia', 'Middle Gov?'),
(522, 'Mongolia', 'Orhon Aymag'),
(523, 'Mongolia', 'Selenge Aymag'),
(524, 'Mongolia', 'Sühbaatar Aymag'),
(525, 'Mongolia', 'Ulaanbaatar Hot'),
(526, 'Mongolia', 'Uvs Aymag'),
(527, 'Mongolia', 'Ömnögov?'),
(528, 'Mongolia', 'Övörhangay'),
(529, 'Myanmar', 'Ayeyawady Region'),
(530, 'Myanmar', 'Bago Region'),
(531, 'Myanmar', 'Chin State'),
(532, 'Myanmar', 'Kachin State'),
(533, 'Myanmar', 'Kayah State'),
(534, 'Myanmar', 'Kayin State'),
(535, 'Myanmar', 'Magway Region'),
(536, 'Myanmar', 'Mandalay Region'),
(537, 'Myanmar', 'Mon State'),
(538, 'Myanmar', 'Nay Pyi Taw'),
(539, 'Myanmar', 'Rakhine State'),
(540, 'Myanmar', 'Sagaing Region'),
(541, 'Myanmar', 'Shan State'),
(542, 'Myanmar', 'Taninthayi Region'),
(543, 'Myanmar', 'Yangon Region'),
(544, 'Nepal', 'Central Region'),
(545, 'Nepal', 'Eastern Region'),
(546, 'Nepal', 'Far Western'),
(547, 'Nepal', 'Mid Western'),
(548, 'Nepal', 'P?thek?'),
(549, 'Nepal', 'Western Region'),
(550, 'North Korea', 'Chagang-do'),
(551, 'North Korea', 'Hambuk'),
(552, 'North Korea', 'Hamnam'),
(553, 'North Korea', 'Hwanghae-bukto'),
(554, 'North Korea', 'Hwanghae-namdo'),
(555, 'North Korea', 'Kangw?n-do'),
(556, 'North Korea', 'Pyongyang'),
(557, 'North Korea', 'P’y?ngan-bukto'),
(558, 'North Korea', 'P’y?ngan-namdo'),
(559, 'North Korea', 'Rason'),
(560, 'North Korea', 'Ryanggang'),
(561, 'Oman', 'Ad Dakhiliyah'),
(562, 'Oman', 'Al Batinah North'),
(563, 'Oman', 'Al Batinah South'),
(564, 'Oman', 'Al Buraimi'),
(565, 'Oman', 'Az? Z??hirah'),
(566, 'Oman', 'Dhofar'),
(567, 'Oman', 'Musandam'),
(568, 'Oman', 'Muscat'),
(569, 'Oman', 'Mu??faz?at al Wus?á'),
(570, 'Oman', 'Northeastern Governorate'),
(571, 'Oman', 'Southeastern Governorate'),
(572, 'Pakistan', 'Azad Kashmir'),
(573, 'Pakistan', 'Balochist?n'),
(574, 'Pakistan', 'FATA'),
(575, 'Pakistan', 'Gilgit-Baltistan'),
(576, 'Pakistan', 'Isl?m?b?d Capital Territory'),
(577, 'Pakistan', 'Khyber Pakhtunkhwa'),
(578, 'Pakistan', 'Punjab'),
(579, 'Pakistan', 'Sindh'),
(580, 'Palestine', 'Gaza Strip'),
(581, 'Palestine', 'West Bank'),
(582, 'Philippines', 'ARMM'),
(583, 'Philippines', 'Bicol'),
(584, 'Philippines', 'Cagayan Valley'),
(585, 'Philippines', 'Calabarzon'),
(586, 'Philippines', 'Caraga'),
(587, 'Philippines', 'Central Luzon'),
(588, 'Philippines', 'Central Visayas'),
(589, 'Philippines', 'Cordillera'),
(590, 'Philippines', 'Davao'),
(591, 'Philippines', 'Eastern Visayas'),
(592, 'Philippines', 'Ilocos'),
(593, 'Philippines', 'Mimaropa'),
(594, 'Philippines', 'National Capital Region'),
(595, 'Philippines', 'Negros Island Region'),
(596, 'Philippines', 'Northern Mindanao'),
(597, 'Philippines', 'Soccsksargen'),
(598, 'Philippines', 'Western Visayas'),
(599, 'Philippines', 'Zamboanga Peninsula'),
(600, 'Qatar', 'Al Wakrah'),
(601, 'Qatar', 'Balad?yat Umm ?al?l'),
(602, 'Qatar', 'Balad?yat ad Daw?ah'),
(603, 'Qatar', 'Balad?yat al Khawr wa adh Dhakh?rah'),
(604, 'Qatar', 'Balad?yat ar Rayy?n'),
(605, 'Qatar', 'Balad?yat ash Sham?l'),
(606, 'Qatar', 'Balad?yat az? Z?a‘?yin'),
(607, 'South Arabia', 'Al Bahah'),
(608, 'South Arabia', 'Al Jawf'),
(609, 'South Arabia', 'Al Mad?nah al Munawwarah'),
(610, 'South Arabia', 'Al-Qassim'),
(611, 'South Arabia', 'Ar Riy??'),
(612, 'South Arabia', 'Eastern Province'),
(613, 'South Arabia', 'Hai’l Region'),
(614, 'South Arabia', 'Jizan'),
(615, 'South Arabia', 'Makkah Province'),
(616, 'South Arabia', 'Najran'),
(617, 'South Arabia', 'Northern Borders'),
(618, 'South Arabia', 'Tabuk'),
(619, 'Singapore', 'Central Singapore Community Development Council'),
(620, 'Singapore', 'North East Community Development Region'),
(621, 'Singapore', 'North West Community Development Council'),
(622, 'Singapore', 'South East Community Development Council'),
(623, 'Singapore', 'South West Community Development Council'),
(624, 'South Korea', 'Busan'),
(625, 'South Korea', 'Chungcheongnam-do'),
(626, 'South Korea', 'Daegu'),
(627, 'South Korea', 'Daejeon'),
(628, 'South Korea', 'Gangwon-do'),
(629, 'South Korea', 'Gwangju'),
(630, 'South Korea', 'Gyeonggi-do'),
(631, 'South Korea', 'Gyeongsangbuk-do'),
(632, 'South Korea', 'Gyeongsangnam-do'),
(633, 'South Korea', 'Incheon'),
(634, 'South Korea', 'Jeju-do'),
(635, 'South Korea', 'Jeollabuk-do'),
(636, 'South Korea', 'Jeollanam-do'),
(637, 'South Korea', 'Sejong-si'),
(638, 'South Korea', 'Seoul'),
(639, 'South Korea', 'Ulsan'),
(640, 'Shrilanka', 'Central Province'),
(641, 'Shrilanka', 'Eastern Province'),
(642, 'Shrilanka', 'North Central Province'),
(643, 'Shrilanka', 'North Western Province'),
(644, 'Shrilanka', 'Northern Province'),
(645, 'Shrilanka', 'Province of Sabaragamuwa'),
(646, 'Shrilanka', 'Province of Uva'),
(647, 'Shrilanka', 'Southern Province'),
(648, 'Shrilanka', 'Western Province'),
(649, 'Syria', 'Al-Hasakah'),
(650, 'Syria', 'Aleppo'),
(651, 'Syria', 'Ar-Raqqah'),
(652, 'Syria', 'As-Suwayda'),
(653, 'Syria', 'Daraa'),
(654, 'Syria', 'Deir ez-Zor'),
(655, 'Syria', 'Dimashq'),
(656, 'Syria', 'Hama'),
(657, 'Syria', 'Homs'),
(658, 'Syria', 'Idlib'),
(659, 'Syria', 'Latakia'),
(660, 'Syria', 'Quneitra'),
(661, 'Syria', 'Rif-dimashq'),
(662, 'Syria', 'Tartus'),
(663, 'Taiwan', 'Fukien'),
(664, 'Taiwan', 'Kaohsiung'),
(665, 'Taiwan', 'Taipei'),
(666, 'Taiwan', 'Taiwan'),
(667, 'Tajikistan', 'Dushanbe'),
(668, 'Tajikistan', 'Gorno-Badakhshan'),
(669, 'Tajikistan', 'Republican Subordination'),
(670, 'Tajikistan', 'Viloyati Khatlon'),
(671, 'Tajikistan', 'Viloyati Sughd'),
(672, 'Thailand', 'Bangkok'),
(673, 'Thailand', 'Changwat Amnat Charoen'),
(674, 'Thailand', 'Changwat Ang Thong'),
(675, 'Thailand', 'Changwat Bueng Kan'),
(676, 'Thailand', 'Changwat Buriram'),
(677, 'Thailand', 'Changwat Chachoengsao'),
(678, 'Thailand', 'Changwat Chai Nat'),
(679, 'Thailand', 'Chang'),
(680, 'Thailand', 'wat Chaiyaphum'),
(681, 'Thailand', 'Changwat Chanthaburi'),
(682, 'Thailand', 'Changwat Chiang Rai'),
(683, 'Thailand', 'Changwat Chon Buri'),
(684, 'Thailand', 'Changwat Chumphon'),
(685, 'Thailand', 'Changwat Kalasin'),
(686, 'Thailand', 'Changwat Kamphaeng Phet'),
(687, 'Thailand', 'Changwat Kanchanaburi'),
(688, 'Thailand', 'Changwat Khon Kaen'),
(689, 'Thailand', 'Changwat Krabi'),
(690, 'Thailand', 'Changwat Lampang'),
(691, 'Thailand', 'Changwat Lamphun'),
(692, 'Thailand', 'Changwat Loei'),
(693, 'Thailand', 'Changwat Lop Buri'),
(694, 'Thailand', 'Changwat Mae Hong Son'),
(695, 'Thailand', 'Changwat Maha Sarakham'),
(696, 'Thailand', 'Changwat Mukdahan'),
(697, 'Thailand', 'Changwat Nakhon Nayok'),
(698, 'Thailand', 'Changwat Nakhon Pathom'),
(699, 'Thailand', 'Changwat Nakhon Phanom'),
(700, 'Thailand', 'Changwat Nakhon Ratchasima'),
(701, 'Thailand', 'Changwat Nakhon Sawan'),
(702, 'Thailand', 'Changwat Nakhon Si Thammarat'),
(703, 'Thailand', 'Changwat Nan'),
(704, 'Thailand', 'Changwat Narathiwat'),
(705, 'Thailand', 'Changwat Nong Bua Lamphu'),
(706, 'Thailand', 'Changwat Nong Khai'),
(707, 'Thailand', 'Changwat Nonthaburi'),
(708, 'Thailand', 'Changwat Pathum Thani'),
(709, 'Thailand', 'Changwat Pattani'),
(710, 'Thailand', 'Changwat Phangnga'),
(711, 'Thailand', 'Changwat Phatthalung'),
(712, 'Thailand', 'Changwat Phayao'),
(713, 'Thailand', 'Changwat Phetchabun'),
(714, 'Thailand', 'Changwat Phetchaburi'),
(715, 'Thailand', 'Changwat Phichit'),
(716, 'Thailand', 'Changwat Phitsanulok'),
(717, 'Thailand', 'Changwat Phra Nakhon Si Ayutthaya'),
(718, 'Thailand', 'Changwat Phrae'),
(719, 'Thailand', 'Changwat Prachin Buri'),
(720, 'Thailand', 'Changwat Prachuap Khiri Khan'),
(721, 'Thailand', 'Changwat Ranong'),
(722, 'Thailand', 'Changwat Ratchaburi'),
(723, 'Thailand', 'Changwat Rayong'),
(724, 'Thailand', 'Changwat Roi Et'),
(725, 'Thailand', 'Changwat Sa Kaeo'),
(726, 'Thailand', 'Changwat Sakon Nakhon'),
(727, 'Thailand', 'Changwat Samut Prakan'),
(728, 'Thailand', 'Changwat Samut Songkhram'),
(729, 'Thailand', 'Changwat Sara Buri'),
(730, 'Thailand', 'Changwat Satun'),
(731, 'Thailand', 'Changwat Sing Buri'),
(732, 'Thailand', 'Changwat Sisaket'),
(733, 'Thailand', 'Changwat Songkhla'),
(734, 'Thailand', 'Changwat Sukhothai'),
(735, 'Thailand', 'Changwat Suphan Buri'),
(736, 'Thailand', 'Changwat Surat Thani'),
(737, 'Thailand', 'Changwat Surin'),
(738, 'Thailand', 'Changwat Tak'),
(739, 'Thailand', 'Changwat Trang'),
(740, 'Thailand', 'Changwat Trat'),
(741, 'Thailand', 'Changwat Ubon Ratchathani'),
(742, 'Thailand', 'Changwat Udon Thani'),
(743, 'Thailand', 'Changwat Uthai Thani'),
(744, 'Thailand', 'Changwat Uttaradit'),
(745, 'Thailand', 'Changwat Yala'),
(746, 'Thailand', 'Changwat Yasothon'),
(747, 'Thailand', 'Phuket'),
(748, 'Turkey', 'Adana'),
(749, 'Turkey', 'Ad?yaman'),
(750, 'Turkey', 'Afyonkarahisar'),
(751, 'Turkey', 'Aksaray'),
(752, 'Turkey', 'Amasya'),
(753, 'Turkey', 'Ankara'),
(754, 'Turkey', 'Antalya'),
(755, 'Turkey', 'Ardahan'),
(756, 'Turkey', 'Artvin'),
(757, 'Turkey', 'Ayd?n'),
(758, 'Turkey', 'A?r?'),
(759, 'Turkey', 'Bal?kesir'),
(760, 'Turkey', 'Bart?n'),
(761, 'Turkey', 'Batman'),
(762, 'Turkey', 'Bayburt'),
(763, 'Turkey', 'Bilecik'),
(764, 'Turkey', 'Bingöl'),
(765, 'Turkey', 'Bitlis'),
(766, 'Turkey', 'Bolu'),
(767, 'Turkey', 'Burdur'),
(768, 'Turkey', 'Bursa'),
(769, 'Turkey', 'Canakkale'),
(770, 'Turkey', 'Denizli'),
(771, 'Turkey', 'Diyarbak?r'),
(772, 'Turkey', 'Düzce'),
(773, 'Turkey', 'Edirne'),
(774, 'Turkey', 'Elaz??'),
(775, 'Turkey', 'Erzincan'),
(776, 'Turkey', 'Erzurum'),
(777, 'Turkey', 'Eski?ehir'),
(778, 'Turkey', 'Gaziantep'),
(779, 'Turkey', 'Giresun'),
(780, 'Turkey', 'Gümü?hane'),
(781, 'Turkey', 'Hakkâri'),
(782, 'Turkey', 'Hatay'),
(783, 'Turkey', 'Isparta'),
(784, 'Turkey', 'Istanbul'),
(785, 'Turkey', 'I?d?r'),
(786, 'Turkey', 'Kahramanmara?'),
(787, 'Turkey', 'Karabük'),
(788, 'Turkey', 'Karaman'),
(789, 'Turkey', 'Kars'),
(790, 'Turkey', 'Kastamonu'),
(791, 'Turkey', 'Kayseri'),
(792, 'Turkey', 'Kilis'),
(793, 'Turkey', 'Kocaeli'),
(794, 'Turkey', 'Konya'),
(795, 'Turkey', 'Kütahya'),
(796, 'Turkey', 'K?rklareli'),
(797, 'Turkey', 'K?r?kkale'),
(798, 'Turkey', 'K?r?ehir'),
(799, 'Turkey', 'Malatya'),
(800, 'Turkey', 'Manisa'),
(801, 'Turkey', 'Mardin'),
(802, 'Turkey', 'Mersin'),
(803, 'Turkey', 'Mu?la'),
(804, 'Turkey', 'Mu?'),
(805, 'Turkey', 'Nev?ehir'),
(806, 'Turkey', 'Ni?de'),
(807, 'Turkey', 'Ordu'),
(808, 'Turkey', 'Osmaniye'),
(809, 'Turkey', 'Rize'),
(810, 'Turkey', 'Sakarya'),
(811, 'Turkey', 'Samsun'),
(812, 'Turkey', 'Sinop'),
(813, 'Turkey', 'Sivas'),
(814, 'Turkey', 'Tekirda?'),
(815, 'Turkey', 'Tokat'),
(816, 'Turkey', 'Trabzon'),
(817, 'Turkey', 'Tunceli'),
(818, 'Turkey', 'U?ak'),
(819, 'Turkey', 'Van'),
(820, 'Turkey', 'Yalova'),
(821, 'Turkey', 'Yozgat'),
(822, 'Turkey', 'Zonguldak'),
(823, 'Turkey', 'Çorum'),
(824, 'Turkey', '?zmir'),
(825, 'Turkey', '?anl?urfa'),
(826, 'Turkey', '??rnak'),
(827, 'Turkmenistan', 'Ahal'),
(828, 'Turkmenistan', 'Ashgabat'),
(829, 'Turkmenistan', 'Balkan'),
(830, 'Turkmenistan', 'Da?oguz Welaýaty'),
(831, 'Turkmenistan', 'Lebap'),
(832, 'Turkmenistan', 'Mary'),
(833, 'UAE', 'Abu Dhabi'),
(834, 'UAE', 'Ajman'),
(835, 'UAE', 'Al Fujayrah'),
(836, 'UAE', 'Ash Sh?riqah'),
(837, 'UAE', 'Dubai'),
(838, 'UAE', 'Ra’s al Khaymah'),
(839, 'UAE', 'Umm al Qaywayn'),
(840, 'Uzbekistan', 'Andijan'),
(841, 'Uzbekistan', 'Bukhara'),
(842, 'Uzbekistan', 'Fergana'),
(843, 'Uzbekistan', 'Jizzakh Province'),
(844, 'Uzbekistan', 'Karakalpakstan'),
(845, 'Uzbekistan', 'Namangan'),
(846, 'Uzbekistan', 'Navoiy Province'),
(847, 'Uzbekistan', 'Qashqadaryo'),
(848, 'Uzbekistan', 'Samarqand Viloyati'),
(849, 'Uzbekistan', 'Sirdaryo'),
(850, 'Uzbekistan', 'Surxondaryo Viloyati'),
(851, 'Uzbekistan', 'Toshkent Shahri'),
(852, 'Uzbekistan', 'Toshkent Viloyati'),
(853, 'Uzbekistan', 'Xorazm Viloyati'),
(854, 'Vietnam ', 'An Giang'),
(855, 'Vietnam ', 'Gia Lai'),
(856, 'Vietnam ', 'Hau Giang'),
(857, 'Vietnam ', 'Ho Chi Minh City'),
(858, 'Vietnam ', 'Kon Tum'),
(859, 'Vietnam ', 'Long An'),
(860, 'Vietnam ', 'Thành Ph? C?n Th?'),
(861, 'Vietnam ', 'Thành Ph? Hà N?i'),
(862, 'Vietnam ', 'Thành Ph? H?i Phòng'),
(863, 'Vietnam ', 'Thành Ph? ?à N?ng'),
(864, 'Vietnam ', 'T?nh Bà R?a-V?ng Tàu'),
(865, 'Vietnam ', 'T?nh Bình D??ng'),
(866, 'Vietnam ', 'T?nh Bình Ph??c'),
(867, 'Vietnam ', 'T?nh Bình Thu?n'),
(868, 'Vietnam ', 'T?nh Bình ??nh'),
(869, 'Vietnam ', 'T?nh B?c Liêu'),
(870, 'Vietnam ', 'T?nh B?c Giang'),
(871, 'Vietnam ', 'T?nh B?c K?n'),
(872, 'Vietnam ', 'T?nh B?c Ninh'),
(873, 'Vietnam ', 'T?nh B?n Tre'),
(874, 'Vietnam ', 'T?nh Cà Mau'),
(875, 'Vietnam ', 'T?nh Hà Giang'),
(876, 'Vietnam ', 'T?nh Hà Nam'),
(877, 'Vietnam ', 'T?nh Hà T?nh'),
(878, 'Vietnam ', 'T?nh Hòa Bình'),
(879, 'Vietnam ', 'T?nh H?ng Yên'),
(880, 'Vietnam ', 'T?nh H?i D??ng'),
(881, 'Vietnam ', 'T?nh Ki?n Giang'),
(882, 'Vietnam ', 'T?nh Lào Cai'),
(883, 'Vietnam ', 'T?nh Lâm ??ng'),
(884, 'Vietnam ', 'T?nh L?ng S?n'),
(885, 'Vietnam ', 'T?nh Nam ??nh'),
(886, 'Vietnam ', 'T?nh Ngh? An'),
(887, 'Vietnam ', 'T?nh Ninh Thu?n'),
(888, 'Vietnam ', 'T?nh Phú Th?'),
(889, 'Vietnam ', 'T?nh Phú Yên'),
(890, 'Vietnam ', 'T?nh Qu?ng Bình'),
(891, 'Vietnam ', 'T?nh Qu?ng Nam'),
(892, 'Vietnam ', 'T?nh Qu?ng Ngãi'),
(893, 'Vietnam ', 'T?nh Qu?ng Ninh'),
(894, 'Vietnam ', 'T?nh Qu?ng Tr?'),
(895, 'Vietnam ', 'T?nh Sóc Tr?ng'),
(896, 'Vietnam ', 'T?nh S?n La'),
(897, 'Vietnam ', 'T?nh Thanh Hóa'),
(898, 'Vietnam ', 'T?nh Thái Bình'),
(899, 'Vietnam ', 'T?nh Thái Nguyên'),
(900, 'Vietnam ', 'T?nh Th?a Thiên-Hu?'),
(901, 'Vietnam ', 'T?nh Ti?n Giang'),
(902, 'Vietnam ', 'T?nh Trà Vinh'),
(903, 'Vietnam ', 'T?nh Tuyên Quang'),
(904, 'Vietnam ', 'T?nh Tây Ninh'),
(905, 'Vietnam ', 'T?nh V?nh Long'),
(906, 'Vietnam ', 'T?nh V?nh Phúc'),
(907, 'Vietnam ', 'T?nh Yên Bái'),
(908, 'Vietnam ', 'T?nh Ði?n Biên'),
(909, 'Vietnam ', 'T?nh ??k L?k'),
(910, 'Vietnam ', 'T?nh ??ng Nai'),
(911, 'Vietnam ', 'T?nh ??ng Tháp'),
(912, 'Vietnam ', 'Ð?k Nông'),
(913, 'Yeman', 'Aden'),
(914, 'Yeman', 'Al Hudaydah'),
(915, 'Yeman', 'Al Jawf'),
(916, 'Yeman', 'Al Mahrah'),
(917, 'Yeman', 'Al Ma?w?t'),
(918, 'Yeman', 'Amanat Al Asimah'),
(919, 'Yeman', 'A? ??li‘'),
(920, 'Yeman', 'Dham?r'),
(921, 'Yeman', 'Ibb'),
(922, 'Yeman', 'La?ij'),
(923, 'Yeman', 'Ma’rib'),
(924, 'Yeman', 'Mu??faz?at Abyan'),
(925, 'Yeman', 'Mu??faz?at al Bay??’'),
(926, 'Yeman', 'Mu??faz?at ?a?ramawt'),
(927, 'Yeman', 'Omran'),
(928, 'Yeman', 'Raymah'),
(929, 'Yeman', 'Sanaa'),
(930, 'Yeman', 'Shabwah'),
(931, 'Yeman', 'Soqatra'),
(932, 'Yeman', 'Ta‘izz'),
(933, 'Yeman', '?a‘dah'),
(934, 'Yeman', '?ajjah'),
(935, 'Algeria', 'Adrar'),
(936, 'Algeria', 'Algiers'),
(937, 'Algeria', 'Annaba'),
(938, 'Algeria', 'Aïn Defla'),
(939, 'Algeria', 'Aïn Témouchent'),
(940, 'Algeria', 'Batna'),
(941, 'Algeria', 'Biskra'),
(942, 'Algeria', 'Blida'),
(943, 'Algeria', 'Bordj Bou Arréridj'),
(944, 'Algeria', 'Bouira'),
(945, 'Algeria', 'Boumerdes'),
(946, 'Algeria', 'Béchar'),
(947, 'Algeria', 'Béjaïa'),
(948, 'Algeria', 'Chlef'),
(949, 'Algeria', 'Constantine'),
(950, 'Algeria', 'Djelfa'),
(951, 'Algeria', 'El Bayadh'),
(952, 'Algeria', 'El Oued'),
(953, 'Algeria', 'El Tarf'),
(954, 'Algeria', 'Ghardaia'),
(955, 'Algeria', 'Guelma'),
(956, 'Algeria', 'Illizi'),
(957, 'Algeria', 'Jijel'),
(958, 'Algeria', 'Khenchela'),
(959, 'Algeria', 'Laghouat'),
(960, 'Algeria', 'Mascara'),
(961, 'Algeria', 'Medea'),
(962, 'Algeria', 'Mila'),
(963, 'Algeria', 'Mostaganem'),
(964, 'Algeria', 'Naama'),
(965, 'Algeria', 'Oran'),
(966, 'Algeria', 'Ouargla'),
(967, 'Algeria', 'Oum el Bouaghi'),
(968, 'Algeria', 'Relizane'),
(969, 'Algeria', 'Saida'),
(970, 'Algeria', 'Sidi Bel Abbès'),
(971, 'Algeria', 'Skikda'),
(972, 'Algeria', 'Souk Ahras'),
(973, 'Algeria', 'Sétif'),
(974, 'Algeria', 'Tamanrasset'),
(975, 'Algeria', 'Tiaret'),
(976, 'Algeria', 'Tindouf'),
(977, 'Algeria', 'Tipaza'),
(978, 'Algeria', 'Tissemsilt'),
(979, 'Algeria', 'Tizi Ouzou'),
(980, 'Algeria', 'Tlemcen'),
(981, 'Algeria', 'Tébessa'),
(982, 'Angola', 'Bengo'),
(983, ' ', 'Benguela'),
(984, ' ', 'Bíe'),
(985, ' ', 'Cabinda'),
(986, ' ', 'Cuando Cobango'),
(987, ' ', 'Cuanza Norte'),
(988, ' ', 'Cunene'),
(989, ' ', 'Huambo'),
(990, ' ', 'Huíla'),
(991, ' ', 'Kwanza Sul'),
(992, ' ', 'Luanda'),
(993, ' ', 'Luanda Norte'),
(994, ' ', 'Lunda Sul'),
(995, ' ', 'Malanje'),
(996, ' ', 'Moxico'),
(997, ' ', 'Namibe'),
(998, ' ', 'Uíge'),
(999, ' ', 'Zaire'),
(1000, ' ', 'Alibori'),
(1001, ' ', 'Atakora'),
(1002, ' ', 'Atlantique'),
(1003, ' ', 'Borgou'),
(1004, ' ', 'Collines'),
(1005, ' ', 'Donga'),
(1006, ' ', 'Kouffo'),
(1007, ' ', 'Littoral'),
(1008, ' ', 'Mono'),
(1009, ' ', 'Ouémé'),
(1010, ' ', 'Plateau'),
(1011, ' ', 'Zou'),
(1012, ' ', 'Central'),
(1013, ' ', 'Ghanzi'),
(1014, ' ', 'Kgalagadi'),
(1015, ' ', 'Kgatleng'),
(1016, ' ', 'Kweneng'),
(1017, ' ', 'Ngwaketsi'),
(1018, ' ', 'North-East'),
(1019, ' ', 'North-West'),
(1020, ' ', 'South-East'),
(1021, ' ', 'Boucle du Mouhoun'),
(1022, ' ', 'Cascades Region'),
(1023, ' ', 'Centre'),
(1024, ' ', 'Centre-Est'),
(1025, ' ', 'Centre-Nord'),
(1026, ' ', 'Centre-Ouest'),
(1027, ' ', 'Centre-Sud'),
(1028, ' ', 'Est'),
(1029, ' ', 'Hauts-Bassins'),
(1030, ' ', 'Nord'),
(1031, ' ', 'Plateau-Central'),
(1032, ' ', 'Sahel'),
(1033, ' ', 'Sud-Ouest'),
(1034, ' ', 'Bubanza'),
(1035, ' ', 'Bujumbura Mairie'),
(1036, ' ', 'Bujumbura Rural'),
(1037, ' ', 'Bururi'),
(1038, ' ', 'Cankuzo'),
(1039, ' ', 'Cibitoke'),
(1040, ' ', 'Gitega'),
(1041, ' ', 'Karuzi'),
(1042, ' ', 'Kayanza'),
(1043, ' ', 'Kirundo'),
(1044, ' ', 'Makamba'),
(1045, ' ', 'Muramvya'),
(1046, ' ', 'Muyinga'),
(1047, ' ', 'Mwaro'),
(1048, ' ', 'Ngozi'),
(1049, ' ', 'Rumonge'),
(1050, ' ', 'Rutana'),
(1051, ' ', 'Ruyigi'),
(1052, 'Cameroon', 'Adamaoua'),
(1053, ' ', 'Centre'),
(1054, ' ', 'East'),
(1055, ' ', 'Far North'),
(1056, ' ', 'North'),
(1057, ' ', 'North-West'),
(1058, ' ', 'South'),
(1059, ' ', 'South-West'),
(1060, ' ', 'West'),
(1061, 'Cape Verde', 'Boa Vista'),
(1062, 'Cape Verde', 'Brava'),
(1063, 'Cape Verde', 'Maio'),
(1064, 'Cape Verde', 'Mosteiros'),
(1065, 'Cape Verde', 'Paul'),
(1066, 'Cape Verde', 'Porto Novo'),
(1067, 'Cape Verde', 'Praia'),
(1068, 'Cape Verde', 'Ribeira Brava'),
(1069, 'Cape Verde', 'Ribeira Grande'),
(1070, 'Cape Verde', 'Ribeira Grande de Santiago'),
(1071, 'Cape Verde', 'Sal'),
(1072, 'Cape Verde', 'Santa Catarina'),
(1073, 'Cape Verde', 'Santa Catarina do Fogo'),
(1074, 'Cape Verde', 'Santa Cruz'),
(1075, 'Cape Verde', 'São Domingos'),
(1076, 'Cape Verde', 'São Filipe'),
(1077, 'Cape Verde', 'São Lourenço dos Órgãos'),
(1078, 'Cape Verde', 'São Miguel'),
(1079, 'Cape Verde', 'São Salvador do Mundo'),
(1080, 'Cape Verde', 'São Vicente'),
(1081, 'Cape Verde', 'Tarrafal'),
(1082, 'Cape Verde', 'Tarrafal de São Nicolau'),
(1083, 'Central Africa Republic', 'Bamingui-Bangoran'),
(1084, ' ', 'Bangui'),
(1085, ' ', 'Basse-Kotto'),
(1086, ' ', 'Haut-Mbomou'),
(1087, ' ', 'Haute-Kotto'),
(1088, ' ', 'Kémo'),
(1089, ' ', 'Lobaye'),
(1090, ' ', 'Mambéré-Kadéï'),
(1091, ' ', 'Mbomou'),
(1092, ' ', 'Nana-Grébizi'),
(1093, ' ', 'Nana-Mambéré'),
(1094, ' ', 'Ouaka'),
(1095, ' ', 'Ouham'),
(1096, ' ', 'Ouham-Pendé'),
(1097, ' ', 'Sangha-Mbaéré'),
(1098, ' ', 'Vakaga'),
(1099, 'Chad', 'Barh el Gazel'),
(1100, ' ', 'Batha'),
(1101, ' ', 'Borkou'),
(1102, ' ', 'Chari-Baguirmi'),
(1103, ' ', 'Ennedi-Est'),
(1104, ' ', 'Ennedi-Ouest'),
(1105, ' ', 'Guéra'),
(1106, ' ', 'Hadjer-Lamis'),
(1107, ' ', 'Kanem'),
(1108, ' ', 'Lac'),
(1109, ' ', 'Logone Occidental'),
(1110, ' ', 'Logone Oriental'),
(1111, ' ', 'Mandoul'),
(1112, ' ', 'Mayo-Kebbi Est'),
(1113, ' ', 'Mayo-Kebbi Ouest'),
(1114, ' ', 'Moyen-Chari'),
(1115, ' ', 'N’Djaména'),
(1116, ' ', 'Ouadaï'),
(1117, ' ', 'Salamat'),
(1118, ' ', 'Sila'),
(1119, ' ', 'Tandjilé'),
(1120, ' ', 'Tibesti'),
(1121, ' ', 'Wadi Fira'),
(1122, ' ', 'Grande Comore'),
(1123, ' ', 'Mohéli'),
(1124, ' ', 'Ndzuwani'),
(1125, ' ', 'Bouenza'),
(1126, ' ', 'Brazzaville'),
(1127, ' ', 'Cuvette'),
(1128, ' ', 'Cuvette-Ouest'),
(1129, ' ', 'Kouilou'),
(1130, ' ', 'Likouala'),
(1131, ' ', 'Lékoumou'),
(1132, ' ', 'Niari'),
(1133, ' ', 'Plateaux'),
(1134, ' ', 'Pointe-Noire'),
(1135, ' ', 'Pool'),
(1136, ' ', 'Sangha'),
(1137, ' ', 'Bas Uele'),
(1138, ' ', 'Bas-Congo'),
(1139, ' ', 'Haut Uele'),
(1140, ' ', 'Haut-Lomani'),
(1141, ' ', 'Ituri'),
(1142, ' ', 'Kasai'),
(1143, ' ', 'Kasaï-Central'),
(1144, ' ', 'Kasaï-Oriental'),
(1145, ' ', 'Kinshasa'),
(1146, ' ', 'Kwango'),
(1147, ' ', 'Kwilu'),
(1148, ' ', 'Lomami'),
(1149, ' ', 'Lualaba'),
(1150, ' ', 'Mai Ndombe'),
(1151, ' ', 'Maniema'),
(1152, ' ', 'Mongala'),
(1153, ' ', 'Nord Kivu'),
(1154, ' ', 'Province du Haut-Katanga'),
(1155, ' ', 'Province du Nord-Ubangi'),
(1156, ' ', 'Province du Sud-Ubangi'),
(1157, ' ', 'Sankuru'),
(1158, ' ', 'South Kivu'),
(1159, ' ', 'Tanganika'),
(1160, ' ', 'Tshopo'),
(1161, ' ', 'Tshuapa'),
(1162, ' ', 'Équateur'),
(1163, ' ', 'Ali Sabieh'),
(1164, ' ', 'Arta'),
(1165, ' ', 'Dikhil'),
(1166, ' ', 'Djibouti'),
(1167, ' ', 'Obock'),
(1168, ' ', 'Tadjourah'),
(1169, ' ', 'Alexandria'),
(1170, ' ', 'Aswan'),
(1171, ' ', 'Asyut'),
(1172, ' ', 'Beheira'),
(1173, ' ', 'Beni Suweif'),
(1174, ' ', 'Cairo'),
(1175, ' ', 'Dakahlia'),
(1176, ' ', 'Damietta'),
(1177, ' ', 'Faiyum'),
(1178, ' ', 'Gharbia'),
(1179, ' ', 'Giza'),
(1180, ' ', 'Ismailia'),
(1181, ' ', 'Kafr el-Sheikh'),
(1182, ' ', 'Luxor'),
(1183, ' ', 'Matruh'),
(1184, ' ', 'Minya'),
(1185, ' ', 'Monufia'),
(1186, ' ', 'New Valley'),
(1187, ' ', 'North Sinai'),
(1188, ' ', 'Port Said'),
(1189, ' ', 'Qalyubia'),
(1190, ' ', 'Qena'),
(1191, ' ', 'Red Sea'),
(1192, ' ', 'Sharqia'),
(1193, ' ', 'Sohag'),
(1194, ' ', 'South Sinai'),
(1195, ' ', 'Suez'),
(1196, 'Eritria', 'Anseba'),
(1197, ' ', 'Debub'),
(1198, ' ', 'Gash-Barka'),
(1199, ' ', 'Maekel'),
(1200, ' ', 'Northern Red Sea'),
(1201, ' ', 'Southern Red Sea'),
(1202, ' ', 'Addis Ababa'),
(1203, ' ', 'Amhara'),
(1204, ' ', 'B?nshangul Gumuz'),
(1205, ' ', 'Dire Dawa'),
(1206, ' ', 'Gambela'),
(1207, ' ', 'Harari'),
(1208, ' ', 'Oromiya'),
(1209, ' ', 'SNNPR'),
(1210, ' ', 'Somali'),
(1211, ' ', 'Tigray'),
(1212, ' ', '?far'),
(1213, ' ', 'Estuaire'),
(1214, ' ', 'Haut-Ogooué'),
(1215, ' ', 'Moyen-Ogooué'),
(1216, ' ', 'Ngouni'),
(1217, ' ', 'Nyanga'),
(1218, ' ', 'Ogooué-Ivindo'),
(1219, ' ', 'Ogooué-Lolo'),
(1220, ' ', 'Ogooué-Maritime'),
(1221, ' ', 'Woleu-Ntem'),
(1222, ' ', 'Banjul'),
(1223, ' ', 'Central River'),
(1224, ' ', 'Lower River'),
(1225, ' ', 'North Bank'),
(1226, ' ', 'Upper River'),
(1227, ' ', 'West Coast'),
(1228, ' ', 'Ashanti Region'),
(1229, ' ', 'Brong-Ahafo'),
(1230, ' ', 'Central Region'),
(1231, ' ', 'Eastern Region'),
(1232, ' ', 'Greater Accra Region'),
(1233, ' ', 'Northern Region'),
(1234, ' ', 'Upper East Region'),
(1235, ' ', 'Upper West Region'),
(1236, ' ', 'Volta Region'),
(1237, ' ', 'Western Region'),
(1238, ' ', 'Boke Region'),
(1239, ' ', 'Conakry Region'),
(1240, ' ', 'Faranah'),
(1241, ' ', 'Kankan Region'),
(1242, ' ', 'Kindia'),
(1243, ' ', 'Labé Region'),
(1244, ' ', 'Mamou Region'),
(1245, ' ', 'Nzerekore Region'),
(1246, ' ', 'Bafatá'),
(1247, ' ', 'Biombo'),
(1248, ' ', 'Bissau'),
(1249, ' ', 'Bolama Region'),
(1250, ' ', 'Cacheu Region'),
(1251, ' ', 'Gabú'),
(1252, ' ', 'Oio Region'),
(1253, ' ', 'Quinara'),
(1254, ' ', 'Tombali'),
(1255, ' ', 'Abidjan'),
(1256, ' ', 'Bas-Sassandra'),
(1257, ' ', 'Comoé'),
(1258, ' ', 'Denguélé'),
(1259, ' ', 'Gôh-Djiboua'),
(1260, ' ', 'Lacs'),
(1261, ' ', 'Lagunes'),
(1262, ' ', 'Montagnes'),
(1263, ' ', 'Sassandra-Marahoué'),
(1264, ' ', 'Savanes'),
(1265, ' ', 'Vallée du Bandama'),
(1266, ' ', 'Woroba'),
(1267, ' ', 'Yamoussoukro Autonomous District'),
(1268, ' ', 'Zanzan'),
(1269, ' ', 'Baringo'),
(1270, ' ', 'Bomet'),
(1271, ' ', 'Bungoma'),
(1272, ' ', 'Busia'),
(1273, ' ', 'Elegeyo-Marakwet'),
(1274, ' ', 'Embu'),
(1275, ' ', 'Garissa'),
(1276, ' ', 'Homa Bay'),
(1277, ' ', 'Isiolo'),
(1278, ' ', 'Kajiado'),
(1279, ' ', 'Kakamega'),
(1280, ' ', 'Kericho'),
(1281, ' ', 'Kiambu'),
(1282, ' ', 'Kilifi'),
(1283, ' ', 'Kirinyaga'),
(1284, ' ', 'Kisii'),
(1285, ' ', 'Kisumu'),
(1286, ' ', 'Kitui'),
(1287, ' ', 'Kwale'),
(1288, ' ', 'Laikipia'),
(1289, ' ', 'Lamu'),
(1290, ' ', 'Machakos'),
(1291, ' ', 'Makueni'),
(1292, ' ', 'Mandera'),
(1293, ' ', 'Marsabit'),
(1294, ' ', 'Meru'),
(1295, ' ', 'Migori'),
(1296, ' ', 'Mombasa'),
(1297, ' ', 'Nairobi'),
(1298, ' ', 'Nakuru'),
(1299, ' ', 'Nandi'),
(1300, ' ', 'Narok'),
(1301, ' ', 'Nyamira'),
(1302, ' ', 'Nyandarua'),
(1303, ' ', 'Nyeri'),
(1304, ' ', 'Samburu'),
(1305, ' ', 'Siaya'),
(1306, ' ', 'Taita Taveta'),
(1307, ' ', 'Tana River'),
(1308, ' ', 'Tharaka - Nithi'),
(1309, ' ', 'Trans Nzoia'),
(1310, ' ', 'Turkana'),
(1311, ' ', 'Uasin Gishu'),
(1312, ' ', 'Vihiga'),
(1313, ' ', 'Wajir'),
(1314, ' ', 'West Pokot'),
(1315, ' ', 'Berea'),
(1316, ' ', 'Butha-Buthe'),
(1317, ' ', 'Leribe'),
(1318, ' ', 'Mafeteng District'),
(1319, ' ', 'Maseru'),
(1320, ' ', 'Mohale’s Hoek District'),
(1321, ' ', 'Mokhotlong'),
(1322, ' ', 'Qacha’s Nek'),
(1323, ' ', 'Quthing'),
(1324, ' ', 'Thaba-Tseka'),
(1325, ' ', 'Bomi County'),
(1326, ' ', 'Bong County'),
(1327, ' ', 'Gbarpolu County'),
(1328, ' ', 'Grand Bassa County'),
(1329, ' ', 'Grand Cape Mount County'),
(1330, ' ', 'Grand Gedeh County'),
(1331, ' ', 'Grand Kru County'),
(1332, ' ', 'Lofa County'),
(1333, ' ', 'Margibi County'),
(1334, ' ', 'Maryland County'),
(1335, ' ', 'Montserrado County'),
(1336, ' ', 'Nimba County'),
(1337, ' ', 'River Cess County'),
(1338, ' ', 'River Gee County'),
(1339, ' ', 'Sinoe County'),
(1340, ' ', 'Al Jufrah'),
(1341, ' ', 'Al Kufrah'),
(1342, ' ', 'Al Marj'),
(1343, ' ', 'Al Marqab'),
(1344, ' ', 'Darnah'),
(1345, ' ', 'Jabal al Gharbi'),
(1346, ' ', 'Murzuq'),
(1347, ' ', 'Sha‘b?yat Bangh?z?'),
(1348, ' ', 'Sha‘b?yat Gh?t'),
(1349, ' ', 'Sha‘b?yat Mi?r?tah'),
(1350, ' ', 'Sha‘b?yat N?l?t'),
(1351, ' ', 'Sha‘b?yat Sabh?'),
(1352, ' ', 'Sha‘b?yat W?d? al ?ay?t'),
(1353, ' ', 'Sha‘b?yat W?d? ash Sh??i’'),
(1354, ' ', 'Sha‘b?yat al Bu?n?n'),
(1355, ' ', 'Sha‘b?yat al Jabal al Akh?ar'),
(1356, ' ', 'Sha‘b?yat al Jaf?rah'),
(1357, ' ', 'Sha‘b?yat al W???t'),
(1358, ' ', 'Sha‘b?yat an Nuq?? al Khams'),
(1359, ' ', 'Sha‘b?yat az Z?wiyah'),
(1360, ' ', 'Surt'),
(1361, ' ', 'Tripoli'),
(1362, ' ', 'Alaotra Mangoro Region'),
(1363, ' ', 'Analamanga Region'),
(1364, ' ', 'Analanjirofo Region'),
(1365, ' ', 'Androy Region'),
(1366, ' ', 'Anosy Region'),
(1367, ' ', 'Atsimo-Andrefana Region'),
(1368, ' ', 'Atsimo-Atsinanana'),
(1369, ' ', 'Atsinanana Region'),
(1370, ' ', 'Betsiboka Region'),
(1371, ' ', 'Boeny Region'),
(1372, ' ', 'Bongolava Region'),
(1373, ' ', 'Diana Region'),
(1374, ' ', 'Ihorombe Region'),
(1375, ' ', 'Itasy Region'),
(1376, ' ', 'Melaky Region'),
(1377, ' ', 'Menabe Region'),
(1378, ' ', 'Sava Region'),
(1379, ' ', 'Sofia Region'),
(1380, ' ', 'Upper Matsiatra'),
(1381, ' ', 'Vakinankaratra Region'),
(1382, ' ', 'Vatovavy Fitovinany Region'),
(1383, ' ', 'Central Region'),
(1384, ' ', 'Northern Region'),
(1385, ' ', 'Southern Region'),
(1386, ' ', 'Bamako Region'),
(1387, ' ', 'Gao'),
(1388, ' ', 'Kayes'),
(1389, ' ', 'Koulikoro'),
(1390, ' ', 'Mopti'),
(1391, ' ', 'Sikasso'),
(1392, ' ', 'Ségou'),
(1393, ' ', 'Tombouctou'),
(1394, ' ', 'Adrar'),
(1395, ' ', 'Assaba'),
(1396, ' ', 'Brakna'),
(1397, ' ', 'Dakhlet Nouadhibou'),
(1398, ' ', 'Gorgol'),
(1399, ' ', 'Guidimaka'),
(1400, ' ', 'Hodh El Gharbi'),
(1401, ' ', 'Hodh ech Chargui'),
(1402, ' ', 'Inchiri'),
(1403, ' ', 'Nouakchott Nord'),
(1404, ' ', 'Nouakchott Ouest'),
(1405, ' ', 'Nouakchott Sud'),
(1406, ' ', 'Tagant'),
(1407, ' ', 'Tiris Zemmour'),
(1408, ' ', 'Wilaya du Trarza'),
(1409, 'Mauritius', 'Agalega Islands'),
(1410, ' ', 'Black River District'),
(1411, ' ', 'Cargados Carajos'),
(1412, ' ', 'Flacq District'),
(1413, ' ', 'Grand Port District'),
(1414, ' ', 'Moka District'),
(1415, ' ', 'Pamplemousses District'),
(1416, ' ', 'Plaines Wilhems District'),
(1417, ' ', 'Port Louis District'),
(1418, ' ', 'Rivière du Rempart District'),
(1419, ' ', 'Rodrigues'),
(1420, ' ', 'Savanne District'),
(1421, 'Mayotte', 'Acoua'),
(1422, ' ', 'Bandraboua'),
(1423, ' ', 'Bandrele'),
(1424, ' ', 'Bouéni'),
(1425, ' ', 'Chiconi'),
(1426, ' ', 'Chirongui'),
(1427, ' ', 'Dembeni'),
(1428, ' ', 'Dzaoudzi'),
(1429, ' ', 'Kani-Kéli'),
(1430, ' ', 'Koungou'),
(1431, ' ', 'Mamoudzou'),
(1432, ' ', 'Mtsamboro'),
(1433, ' ', 'Ouangani'),
(1434, ' ', 'Pamandzi'),
(1435, ' ', 'Sada'),
(1436, ' ', 'Tsingoni'),
(1437, 'Morocco', 'Béni Mellal-Khénifra'),
(1438, 'Morocco', 'Casablanca-Settat'),
(1439, 'Morocco', 'Dakhla-Oued Ed-Dahab'),
(1440, 'Morocco', 'Drâa-Tafilalet'),
(1441, ' ', 'Fès-Meknès'),
(1442, ' ', 'Guelmim-Oued Noun'),
(1443, ' ', 'Laâyoune-Sakia El Hamra'),
(1444, ' ', 'Marrakesh-Safi'),
(1445, ' ', 'Oriental'),
(1446, ' ', 'Rabat-Salé-Kénitra'),
(1447, ' ', 'Souss-Massa'),
(1448, ' ', 'Tanger-Tetouan-Al Hoceima'),
(1449, 'Mozambique', 'Cabo Delgado Province'),
(1450, ' ', 'Cidade de Maputo'),
(1451, ' ', 'Gaza Province'),
(1452, ' ', 'Inhambane Province'),
(1453, ' ', 'Manica Province'),
(1454, ' ', 'Maputo'),
(1455, ' ', 'Nampula'),
(1456, ' ', 'Niassa Province'),
(1457, ' ', 'Província de Zambézia'),
(1458, ' ', 'Sofala Province'),
(1459, ' ', 'Tete'),
(1460, 'Namibia', 'Erongo'),
(1461, ' ', 'Hardap'),
(1462, ' ', 'Karas'),
(1463, ' ', 'Kavango East'),
(1464, ' ', 'Kavango West'),
(1465, ' ', 'Khomas'),
(1466, ' ', 'Kunene'),
(1467, ' ', 'Ohangwena'),
(1468, ' ', 'Omaheke'),
(1469, ' ', 'Omusati'),
(1470, ' ', 'Oshana'),
(1471, ' ', 'Oshikoto'),
(1472, ' ', 'Otjozondjupa'),
(1473, ' ', 'Zambezi Region'),
(1474, 'Niger', 'Agadez'),
(1475, 'Niger', 'Diffa'),
(1476, 'Niger', 'Dosso Region'),
(1477, 'Niger', 'Maradi'),
(1478, 'Niger', 'Niamey'),
(1479, 'Niger', 'Tahoua'),
(1480, ' ', 'Tillaberi Region'),
(1481, ' ', 'Zinder'),
(1482, 'Nigeria', 'Abia State'),
(1483, 'Nigeria', 'Adamawa'),
(1484, 'Nigeria', 'Akwa Ibom State'),
(1485, 'Nigeria', 'Anambra'),
(1486, 'Nigeria', 'Bauchi'),
(1487, 'Nigeria', 'Bayelsa State'),
(1488, 'Nigeria', 'Benue State'),
(1489, 'Nigeria', 'Borno State'),
(1490, 'Nigeria', 'Cross River State'),
(1491, ' ', 'Delta'),
(1492, ' ', 'Ebonyi State'),
(1493, ' ', 'Edo'),
(1494, ' ', 'Ekiti State'),
(1495, ' ', 'Enugu State'),
(1496, ' ', 'FCT'),
(1497, ' ', 'Gombe State'),
(1498, ' ', 'Imo State'),
(1499, ' ', 'Jigawa State'),
(1500, ' ', 'Kaduna State'),
(1501, ' ', 'Kano State'),
(1502, ' ', 'Katsina State'),
(1503, ' ', 'Kebbi State'),
(1504, ' ', 'Kogi State'),
(1505, ' ', 'Kwara State'),
(1506, ' ', 'Lagos'),
(1507, ' ', 'Nasarawa State'),
(1508, ' ', 'Niger State'),
(1509, ' ', 'Ogun State'),
(1510, ' ', 'Ondo State'),
(1511, ' ', 'Osun State'),
(1512, ' ', 'Plateau State'),
(1513, ' ', 'Rivers State'),
(1514, ' ', 'Sokoto State'),
(1515, ' ', 'Yobe State'),
(1516, ' ', 'Zamfara State'),
(1517, ' ', 'Eastern Province'),
(1518, ' ', 'Kigali'),
(1519, ' ', 'Northern Province'),
(1520, ' ', 'Southern Province'),
(1521, ' ', 'Western Province'),
(1522, 'Reunion', 'Réunion'),
(1523, 'Saint Helena', 'Ascension'),
(1524, ' ', 'Saint Helena'),
(1525, ' ', 'Tristan da Cunha'),
(1526, 'Senegal', 'Dakar'),
(1527, ' ', 'Diourbel'),
(1528, ' ', 'Fatick'),
(1529, ' ', 'Kaolack'),
(1530, ' ', 'Kolda'),
(1531, ' ', 'Louga'),
(1532, ' ', 'Matam'),
(1533, ' ', 'Région de Kaffrine'),
(1534, ' ', 'Région de Kédougou'),
(1535, ' ', 'Région de Sédhiou'),
(1536, ' ', 'Région de Thiès'),
(1537, ' ', 'Saint-Louis'),
(1538, ' ', 'Tambacounda'),
(1539, ' ', 'Ziguinchor'),
(1540, 'Seychelles', 'Anse Boileau'),
(1541, 'Seychelles', 'Anse Etoile'),
(1542, 'Seychelles', 'Anse Royale'),
(1543, 'Seychelles', 'Anse-aux-Pins'),
(1544, ' ', 'Au Cap'),
(1545, ' ', 'Baie Lazare'),
(1546, ' ', 'Baie Sainte Anne'),
(1547, ' ', 'Beau Vallon'),
(1548, ' ', 'Bel Air'),
(1549, ' ', 'Bel Ombre'),
(1550, ' ', 'Cascade'),
(1551, ' ', 'English River'),
(1552, ' ', 'Glacis'),
(1553, ' ', 'Grand Anse Mahe'),
(1554, ' ', 'Grand Anse Praslin'),
(1555, ' ', 'Inner Islands'),
(1556, ' ', 'Les Mamelles'),
(1557, ' ', 'Mont Buxton'),
(1558, ' ', 'Mont Fleuri'),
(1559, ' ', 'Plaisance'),
(1560, ' ', 'Pointe Larue'),
(1561, ' ', 'Port Glaud'),
(1562, ' ', 'Roche Caiman'),
(1563, ' ', 'Saint Louis'),
(1564, ' ', 'Takamaka'),
(1565, 'Sierra Leone', 'Eastern Province'),
(1566, 'Sierra Leone', 'Northern Province'),
(1567, ' ', 'Southern Province'),
(1568, ' ', 'Western Area'),
(1569, 'Somalia', 'Awdal'),
(1570, 'Somalia', 'Bakool'),
(1571, 'Somalia', 'Banaadir'),
(1572, 'Somalia', 'Bari'),
(1573, 'Somalia', 'Bay'),
(1574, 'Somalia', 'Galguduud'),
(1575, 'Somalia', 'Gedo'),
(1576, ' ', 'Hiiraan'),
(1577, ' ', 'Jubbada Dhexe Region'),
(1578, ' ', 'Jubbada Hoose Region'),
(1579, ' ', 'Lower Shabeelle'),
(1580, ' ', 'Mudug'),
(1581, ' ', 'Nugaal'),
(1582, ' ', 'Sanaag'),
(1583, ' ', 'Shabeele Dhexe'),
(1584, ' ', 'Region'),
(1585, ' ', 'Sool'),
(1586, ' ', 'Togdheer'),
(1587, ' ', 'Woqooyi Galbeed'),
(1588, 'South Africa', 'Eastern Cape'),
(1589, 'South Africa', 'Gauteng'),
(1590, 'South Africa', 'KwaZulu-Natal'),
(1591, 'South Africa', 'Limpopo'),
(1592, 'South Africa', 'Mpumalanga'),
(1593, 'South Africa', 'Northern Cape'),
(1594, 'South Africa', 'Orange Free State'),
(1595, 'South Africa', 'Province of North West'),
(1596, 'South Africa', 'Western Cape'),
(1597, 'South Sudan', 'Central Equatoria'),
(1598, 'South Sudan', 'Eastern Equatoria'),
(1599, 'South Sudan', 'El Buhayrat'),
(1600, 'South Sudan', 'Jonglei'),
(1601, ' ', 'Northern Bahr al Ghazal'),
(1602, ' ', 'Unity State'),
(1603, ' ', 'Upper Nile'),
(1604, ' ', 'Warrap'),
(1605, ' ', 'Western Bahr el Ghazal'),
(1606, ' ', 'Western Equatoria'),
(1607, 'Sudan', 'Al Jaz?rah'),
(1608, 'Sudan', 'Al Qa??rif'),
(1609, 'Sudan', 'Blue Nile State'),
(1610, 'Sudan', 'Central Darfur'),
(1611, 'Sudan', 'Eastern Darfur'),
(1612, 'Sudan', 'Kassala'),
(1613, 'Sudan', 'Khartoum'),
(1614, 'Sudan', 'North Kordofan'),
(1615, ' ', 'Northern Darfur'),
(1616, ' ', 'Northern State'),
(1617, ' ', 'Red Sea State'),
(1618, ' ', 'River Nile'),
(1619, ' ', 'Sinn?r'),
(1620, ' ', 'Southern Darfur'),
(1621, ' ', 'Southern Kordofan'),
(1622, ' ', 'West Kordofan'),
(1623, ' ', 'Western Darfur'),
(1624, ' ', 'White Nile'),
(1625, 'Swaziland', 'Hhohho District'),
(1626, 'Swaziland', 'Lubombo District'),
(1627, 'Swaziland', 'Manzini District'),
(1628, 'Swaziland', 'Shiselweni District'),
(1629, 'Tanzania', 'Arusha'),
(1630, 'Tanzania', 'Dar es Salaam Region'),
(1631, 'Tanzania', 'Dodoma'),
(1632, 'Tanzania', 'Geita'),
(1633, ' ', 'Iringa'),
(1634, ' ', 'Kagera'),
(1635, ' ', 'Katavi'),
(1636, ' ', 'Kigoma'),
(1637, ' ', 'Kilimanjaro'),
(1638, ' ', 'Lindi'),
(1639, ' ', 'Manyara'),
(1640, ' ', 'Mara'),
(1641, ' ', 'Mbeya'),
(1642, ' ', 'Morogoro'),
(1643, ' ', 'Mtwara'),
(1644, ' ', 'Mwanza'),
(1645, ' ', 'Njombe'),
(1646, ' ', 'Pemba North'),
(1647, ' ', 'Pemba South'),
(1648, ' ', 'Pwani'),
(1649, ' ', 'Rukwa'),
(1650, ' ', 'Ruvuma'),
(1651, ' ', 'Shinyanga'),
(1652, ' ', 'Simiyu'),
(1653, ' ', 'Singida'),
(1654, ' ', 'Tabora'),
(1655, ' ', 'Tanga'),
(1656, ' ', 'Zanzibar Central/South'),
(1657, ' ', 'Zanzibar North'),
(1658, ' ', 'Zanzibar Urban/West'),
(1659, 'Togo', 'Centrale'),
(1660, ' ', 'Kara'),
(1661, ' ', 'Maritime'),
(1662, ' ', 'Plateaux'),
(1663, ' ', 'Savanes'),
(1664, 'Tunisia', 'Gafsa'),
(1665, 'Tunisia', 'Gouvernorat de Ben Arous'),
(1666, 'Tunisia', 'Gouvernorat de Bizerte'),
(1667, 'Tunisia', 'Gouvernorat de Béja'),
(1668, 'Tunisia', 'Gouvernorat de Gabès'),
(1669, ' ', 'Gouvernorat de Jendouba'),
(1670, ' ', 'Gouvernorat de Kairouan'),
(1671, ' ', 'Gouvernorat de Kasserine'),
(1672, ' ', 'Gouvernorat de Kef'),
(1673, ' ', 'Gouvernorat de Kébili'),
(1674, ' ', 'Gouvernorat de Mahdia'),
(1675, ' ', 'Gouvernorat de Monastir'),
(1676, ' ', 'Gouvernorat de Nabeul'),
(1677, ' ', 'Gouvernorat de Sfax'),
(1678, ' ', 'Gouvernorat de Sidi Bouzid'),
(1679, ' ', 'Gouvernorat de Siliana'),
(1680, ' ', 'Gouvernorat de Tozeur'),
(1681, ' ', 'Gouvernorat de Tunis');
INSERT INTO `country_state_list` (`id`, `country_name`, `state_name`) VALUES
(1682, ' ', 'Gouvernorat de Zaghouan'),
(1683, ' ', 'Gouvernorat de l’Ariana'),
(1684, ' ', 'Manouba'),
(1685, ' ', 'Tataouine'),
(1686, 'Uganda', 'Central Region'),
(1687, 'Uganda', 'Eastern Region'),
(1688, 'Uganda', 'Northern Region'),
(1689, 'Uganda', 'Western Region'),
(1690, 'Zambia', 'Central Province'),
(1691, ' ', 'Copperbelt'),
(1692, ' ', 'Eastern Province'),
(1693, ' ', 'Luapula Province'),
(1694, ' ', 'Lusaka Province'),
(1695, ' ', 'Muchinga'),
(1696, ' ', 'North-Western Province'),
(1697, ' ', 'Northern Province'),
(1698, ' ', 'Southern Province'),
(1699, ' ', 'Western Province'),
(1700, 'Zimbabwe', 'Bulawayo'),
(1701, 'Zimbabwe', 'Harare'),
(1702, 'Zimbabwe', 'Manicaland'),
(1703, 'Zimbabwe', 'Mashonaland Central'),
(1704, 'Zimbabwe', 'Mashonaland East Province'),
(1705, 'Zimbabwe', 'Mashonaland West'),
(1706, ' ', 'Masvingo Province'),
(1707, ' ', 'Matabeleland North'),
(1708, ' ', 'Matabeleland South Province'),
(1709, ' ', 'Midlands Province'),
(1710, 'Albania', 'Qarku i Beratit'),
(1711, ' ', 'Qarku i Dibrës'),
(1712, ' ', 'Qarku i Durrësit'),
(1713, ' ', 'Qarku i Elbasanit'),
(1714, ' ', 'Qarku i Fierit'),
(1715, ' ', 'Qarku i Gjirokastrës'),
(1716, ' ', 'Qarku i Korçës'),
(1717, ' ', 'Qarku i Kukësit'),
(1718, ' ', 'Qarku i Lezhës'),
(1719, ' ', 'Qarku i Shkodrës'),
(1720, ' ', 'Qarku i Tiranës'),
(1721, ' ', 'Qarku i Vlorës'),
(1722, 'Andorra', 'Andorra la Vella'),
(1723, 'Andorra', 'Canillo'),
(1724, 'Andorra', 'Encamp'),
(1725, 'Andorra', 'Escaldes-Engordany'),
(1726, 'Andorra', 'La Massana'),
(1727, ' ', 'Ordino'),
(1728, ' ', 'Sant Julià de Loria'),
(1729, 'Austria', 'Burgenland'),
(1730, 'Austria', 'Carinthia'),
(1731, 'Austria', 'Lower Austria'),
(1732, 'Austria', 'Salzburg'),
(1733, 'Austria', 'Styria'),
(1734, 'Austria', 'Tyrol'),
(1735, 'Austria', 'Upper Austria'),
(1736, 'Austria', 'Vienna'),
(1737, 'Austria', 'Vorarlberg'),
(1738, 'Belarus', 'Brest'),
(1739, 'Belarus', 'Gomel'),
(1740, 'Belarus', 'Grodnenskaya'),
(1741, 'Belarus', 'Minsk'),
(1742, 'Belarus', 'Minsk City'),
(1743, 'Belarus', 'Mogilev'),
(1744, 'Belarus', 'Vitebsk'),
(1745, 'Belgium', 'Brussels Capital'),
(1746, ' ', 'Flanders'),
(1747, ' ', 'Wallonia'),
(1748, 'Bosnia', 'Br?ko'),
(1749, 'Bosnia', 'Federation of B&H'),
(1750, 'Bosnia', 'Srspka'),
(1751, 'Bulgaria', 'Blagoevgrad'),
(1752, 'Bulgaria', 'Burgas'),
(1753, 'Bulgaria', 'Gabrovo'),
(1754, 'Bulgaria', 'Haskovo'),
(1755, 'Bulgaria', 'Lovech'),
(1756, 'Bulgaria', 'Oblast Dobrich'),
(1757, 'Bulgaria', 'Oblast Kardzhali'),
(1758, 'Bulgaria', 'Oblast Kyustendil'),
(1759, ' ', 'Oblast Montana'),
(1760, ' ', 'Oblast Pleven'),
(1761, ' ', 'Oblast Razgrad'),
(1762, ' ', 'Oblast Ruse'),
(1763, ' ', 'Oblast Shumen'),
(1764, ' ', 'Oblast Silistra'),
(1765, ' ', 'Oblast Sliven'),
(1766, ' ', 'Oblast Smolyan'),
(1767, ' ', 'Oblast Stara Zagora'),
(1768, ' ', 'Oblast Targovishte'),
(1769, ' ', 'Oblast Veliko Tarnovo'),
(1770, ' ', 'Oblast Vidin'),
(1771, ' ', 'Oblast Vratsa'),
(1772, ' ', 'Oblast Yambol'),
(1773, ' ', 'Pazardzhik'),
(1774, ' ', 'Pernik'),
(1775, ' ', 'Plovdiv'),
(1776, ' ', 'Sofia'),
(1777, ' ', 'Sofia-Capital'),
(1778, ' ', 'Varna'),
(1779, 'Croatica', 'Bjelovarsko-Bilogorska Županija'),
(1780, 'Croatica', 'City of Zagreb'),
(1781, 'Croatica', 'Dubrova?ko-Neretvanska Županija'),
(1782, 'Croatica', 'Istarska Županija'),
(1783, 'Croatica', 'Karlova?ka Županija'),
(1784, 'Croatica', 'Koprivni?ko-Križeva?ka Županija'),
(1785, 'Croatica', 'Krapinsko-Zagorska Županija'),
(1786, 'Croatica', 'Li?ko-Senjska Županija'),
(1787, 'Croatica', 'Me?imurska Županija'),
(1788, 'Croatica', 'Osje?ko-Baranjska Županija'),
(1789, 'Croatica', 'Požeško-Slavonska Županija'),
(1790, 'Croatica', 'Primorsko-Goranska Županija'),
(1791, 'Croatica', 'Sisa?ko-Moslava?ka Županija'),
(1792, 'Croatica', 'Slavonski Brod-Posavina'),
(1793, 'Croatica', 'Splitsko-Dalmatinska Županija'),
(1794, 'Croatica', 'Varaždinska Županija'),
(1795, 'Croatica', 'Viroviti?ko-Podravska Županija'),
(1796, 'Croatica', 'Vukovar-Sirmium'),
(1797, 'Croatica', 'Zadarska Županija'),
(1798, 'Croatica', 'Zagreb County'),
(1799, 'Syprus', 'Ammochostos'),
(1800, 'Syprus', 'Keryneia'),
(1801, 'Syprus', 'Larnaka'),
(1802, 'Syprus', 'Lemesos'),
(1803, 'Syprus', 'Pafos'),
(1804, 'Czechia', 'Central Bohemia'),
(1805, 'Czechia', 'Hlavní m?sto Praha'),
(1806, 'Czechia', 'Jiho?eský kraj'),
(1807, 'Czechia', 'Karlovarský kraj'),
(1808, 'Czechia', 'Kraj Vyso?ina'),
(1809, 'Czechia', 'Královéhradecký kraj'),
(1810, 'Czechia', 'Liberecký kraj'),
(1811, 'Czechia', 'Moravskoslezský kraj'),
(1812, 'Czechia', 'Olomoucký kraj'),
(1813, ' ', 'Pardubický kraj'),
(1814, ' ', 'Plze?ský kraj'),
(1815, ' ', 'South Moravian'),
(1816, ' ', 'Zlín'),
(1817, ' ', 'Ústecký kraj'),
(1818, 'Denmark', 'Capital Region'),
(1819, 'Denmark', 'Central Jutland'),
(1820, 'Denmark', 'North Denmark'),
(1821, 'Denmark', 'South Denmark'),
(1822, 'Denmark', 'Zealand'),
(1823, 'Estonia', 'Harjumaa'),
(1824, ' ', 'Hiiumaa'),
(1825, ' ', 'Ida-Virumaa'),
(1826, ' ', 'Järvamaa'),
(1827, ' ', 'Jõgevamaa'),
(1828, ' ', 'Lääne'),
(1829, ' ', 'Lääne-Virumaa'),
(1830, ' ', 'Pärnumaa'),
(1831, ' ', 'Põlvamaa'),
(1832, ' ', 'Raplamaa'),
(1833, ' ', 'Saare'),
(1834, ' ', 'Tartu'),
(1835, ' ', 'Valgamaa'),
(1836, ' ', 'Viljandimaa'),
(1837, ' ', 'Võrumaa'),
(1838, 'Faroe Islands', 'Eysturoy'),
(1839, 'Faroe Islands', 'Norðoyar'),
(1840, 'Faroe Islands', 'Sandoy'),
(1841, 'Faroe Islands', 'Streymoy'),
(1842, 'Faroe Islands', 'Suðuroy'),
(1843, 'Faroe Islands', 'Vágar'),
(1844, 'Finland', 'Central Finland'),
(1845, 'Finland', 'Central Ostrobothnia'),
(1846, 'Finland', 'Häme'),
(1847, 'Finland', 'Kainuu'),
(1848, 'Finland', 'Kymenlaakso Region'),
(1849, 'Finland', 'Newland'),
(1850, 'Finland', 'North Karelia Region'),
(1851, 'Finland', 'North Savo Region'),
(1852, 'Finland', 'Northern Ostrobothnia'),
(1853, 'Finland', 'Ostrobothnia Region'),
(1854, ' ', 'Paijat-Hame Region'),
(1855, ' ', 'Satakunta'),
(1856, ' ', 'South Karelia'),
(1857, ' ', 'South Ostrobothnia Region'),
(1858, ' ', 'Southern Savonia'),
(1859, ' ', 'Southwest Finland'),
(1860, ' ', 'Tampere'),
(1861, 'France', 'Auvergne-Rhône-Alpes'),
(1862, 'France', 'Bourgogne-Franche-Comté'),
(1863, 'France', 'Brittany'),
(1864, 'France', 'Centre'),
(1865, 'France', 'Corsica'),
(1866, 'France', 'Grand-Est'),
(1867, 'France', 'Hauts-de-France'),
(1868, 'France', 'Normandy'),
(1869, 'France', 'Nouvelle-Aquitaine'),
(1870, 'France', 'Occitanie'),
(1871, 'France', 'Pays de la Loire'),
(1872, 'France', 'Île-de-France'),
(1873, 'Germany', 'Baden-Württemberg'),
(1874, 'Germany', 'Bavaria'),
(1875, 'Germany', 'Brandenburg'),
(1876, 'Germany', 'Bremen'),
(1877, 'Germany', 'Hamburg'),
(1878, 'Germany', 'Hesse'),
(1879, 'Germany', 'Land Berlin'),
(1880, 'Germany', 'Lower Saxony'),
(1881, 'Germany', 'Mecklenburg-Vorpommern'),
(1882, 'Germany', 'North Rhine-Westphalia'),
(1883, 'Germany', 'Rheinland-Pfalz'),
(1884, 'Germany', 'Saarland'),
(1885, 'Germany', 'Saxony'),
(1886, ' ', 'Saxony-Anhalt'),
(1887, ' ', 'Schleswig-Holstein'),
(1888, ' ', 'Thuringia'),
(1889, 'Greece', 'Attica'),
(1890, 'Greece', 'Central Greece'),
(1891, 'Greece', 'Central Macedonia'),
(1892, 'Greece', 'Crete'),
(1893, 'Greece', 'East Macedonia and Thrace'),
(1894, 'Greece', 'Epirus'),
(1895, 'Greece', 'Ionian Islands'),
(1896, 'Greece', 'Mount Athos'),
(1897, 'Greece', 'North Aegean'),
(1898, 'Greece', 'Peloponnese'),
(1899, 'Greece', 'South Aegean'),
(1900, 'Greece', 'Thessaly'),
(1901, 'Greece', 'West Greece'),
(1902, 'Greece', 'West Macedonia'),
(1903, 'Hungary', 'Baranya'),
(1904, ' ', 'Bekes'),
(1905, ' ', 'Borsod-Abaúj-Zemplén'),
(1906, ' ', 'Budapest'),
(1907, ' ', 'Bács-Kiskun'),
(1908, ' ', 'Csongrád megye'),
(1909, ' ', 'Fejér'),
(1910, ' ', 'Gy?r-Moson-Sopron'),
(1911, ' ', 'Hajdú-Bihar'),
(1912, ' ', 'Heves megye'),
(1913, ' ', 'Jász-Nagykun-Szolnok'),
(1914, ' ', 'Komárom-Esztergom'),
(1915, ' ', 'Nógrád megye'),
(1916, ' ', 'Pest megye'),
(1917, ' ', 'Somogy megye'),
(1918, ' ', 'Szabolcs-Szatmár-Bereg'),
(1919, ' ', 'Tolna megye'),
(1920, ' ', 'Vas'),
(1921, ' ', 'Veszprém megye'),
(1922, ' ', 'Zala'),
(1923, 'Iceland', 'Capital Region'),
(1924, 'Iceland', 'East'),
(1925, 'Iceland', 'Northeast'),
(1926, 'Iceland', 'Northwest'),
(1927, 'Iceland', 'South'),
(1928, 'Iceland', 'Southern Peninsula'),
(1929, 'Iceland', 'West'),
(1930, 'Iceland', 'Westfjords'),
(1931, ' ', 'Connaught'),
(1932, ' ', 'Leinster'),
(1933, ' ', 'Munster'),
(1934, ' ', 'Ulster'),
(1935, 'Italy', 'Abruzzo'),
(1936, 'Italy', 'Aosta Valley'),
(1937, 'Italy', 'Apulia'),
(1938, 'Italy', 'Basilicate'),
(1939, 'Italy', 'Calabria'),
(1940, 'Italy', 'Campania'),
(1941, 'Italy', 'Emilia-Romagna'),
(1942, 'Italy', 'Friuli Venezia Giulia'),
(1943, 'Italy', 'Latium'),
(1944, 'Italy', 'Liguria'),
(1945, 'Italy', 'Lombardy'),
(1946, 'Italy', 'Molise'),
(1947, 'Italy', 'Piedmont'),
(1948, 'Italy', 'Sardinia'),
(1949, 'Italy', 'Sicily'),
(1950, 'Italy', 'The Marches'),
(1951, 'Italy', 'Trentino-Alto Adige'),
(1952, 'Italy', 'Tuscany'),
(1953, 'Italy', 'Umbria'),
(1954, 'Italy', 'Veneto'),
(1955, 'Kosovo', 'Ferizaj'),
(1956, 'Kosovo', 'Gjakova'),
(1957, 'Kosovo', 'Gjilan'),
(1958, 'Kosovo', 'Mitrovica'),
(1959, 'Kosovo', 'Pec'),
(1960, 'Kosovo', 'Pristina'),
(1961, 'Kosovo', 'Prizren'),
(1962, 'Latvia', 'Aglona'),
(1963, 'Latvia', 'Aizkraukles Rajons'),
(1964, 'Latvia', 'Aizpute'),
(1965, 'Latvia', 'Akn?ste'),
(1966, 'Latvia', 'Aloja'),
(1967, 'Latvia', 'Alsunga'),
(1968, 'Latvia', 'Al?ksnes Novads'),
(1969, 'Latvia', 'Amatas'),
(1970, 'Latvia', 'Apes'),
(1971, 'Latvia', 'Auces'),
(1972, 'Latvia', 'Bab?te'),
(1973, 'Latvia', 'Baldone'),
(1974, 'Latvia', 'Baltinava'),
(1975, 'Latvia', 'Balvu Novads'),
(1976, 'Latvia', 'Bauskas Novads'),
(1977, 'Latvia', 'Bever?na'),
(1978, 'Latvia', 'Broc?ni'),
(1979, 'Latvia', 'Burtnieki'),
(1980, 'Latvia', 'Carnikava'),
(1981, 'Latvia', 'Cesvaine'),
(1982, 'Latvia', 'Cibla'),
(1983, 'Latvia', 'C?su Novads'),
(1984, 'Latvia', 'Dagda'),
(1985, 'Latvia', 'Daugavpils'),
(1986, 'Latvia', 'Daugavpils municipality'),
(1987, 'Latvia', 'Dobeles Rajons'),
(1988, 'Latvia', 'Dundaga'),
(1989, 'Latvia', 'Durbe'),
(1990, 'Latvia', 'Engure'),
(1991, 'Latvia', 'Garkalne'),
(1992, 'Latvia', 'Grobi?a'),
(1993, 'Latvia', 'Gulbenes Rajons'),
(1994, 'Latvia', 'Ikš?ile'),
(1995, 'Latvia', 'Il?kste'),
(1996, 'Latvia', 'In?ukalns'),
(1997, 'Latvia', 'Jaunjelgava'),
(1998, 'Latvia', 'Jaunpiebalga'),
(1999, 'Latvia', 'Jaunpils'),
(2000, 'Latvia', 'Jelgava'),
(2001, 'Latvia', 'Jelgavas Rajons'),
(2002, 'Latvia', 'J?kabpils'),
(2003, 'Latvia', 'J?kabpils Municipality'),
(2004, 'Latvia', 'J?rmala'),
(2005, 'Latvia', 'Kandava'),
(2006, 'Latvia', 'Karsava'),
(2007, 'Latvia', 'Koc?ni'),
(2008, 'Latvia', 'Koknese'),
(2009, 'Latvia', 'Krimulda'),
(2010, 'Latvia', 'Krustpils'),
(2011, 'Latvia', 'Kr?slavas Rajons'),
(2012, 'Latvia', 'Kuld?gas Rajons'),
(2013, 'Latvia', 'Lecava'),
(2014, 'Latvia', 'Lielv?rde'),
(2015, 'Latvia', 'Liep?ja'),
(2016, 'Latvia', 'Limbažu Rajons'),
(2017, 'Latvia', 'Lub?na'),
(2018, 'Latvia', 'Ludzas Rajons'),
(2019, 'Latvia', 'L?gatne'),
(2020, 'Latvia', 'L?v?ni'),
(2021, 'Latvia', 'Madona Municipality'),
(2022, 'Latvia', 'Mazsalaca'),
(2023, 'Latvia', 'M?lpils'),
(2024, 'Latvia', 'M?rupe'),
(2025, 'Latvia', 'M?rsraga Novads'),
(2026, 'Latvia', 'Naukš?ni'),
(2027, 'Latvia', 'Nereta'),
(2028, 'Latvia', 'N?ca         Ogre'),
(2029, 'Latvia', 'Olaine'),
(2030, 'Latvia', 'Ozolnieku Novads'),
(2031, 'Latvia', 'Prei?i Municipality'),
(2032, 'Latvia', 'Priekule'),
(2033, 'Latvia', 'Prieku?i Municipality'),
(2034, 'Latvia', 'P?rgaujas Novads'),
(2035, 'Latvia', 'P?vilostas Novads'),
(2036, 'Latvia', 'P?avi?u Novads'),
(2037, 'Latvia', 'Raunas Novads'),
(2038, 'Latvia', 'Riebi?u Novads'),
(2039, 'Latvia', 'Rojas Novads'),
(2040, 'Latvia', 'Ropažu Novads'),
(2041, 'Latvia', 'Rucavas Novads'),
(2042, 'Latvia', 'Rug?ju Novads'),
(2043, 'Latvia', 'Rund?les Novads'),
(2044, 'Latvia', 'R?zekne'),
(2045, 'Latvia', 'R?zeknes Novads'),
(2046, 'Latvia', 'R?ga'),
(2047, 'Latvia', 'R?jienas Novads'),
(2048, 'Latvia', 'Salacgr?vas Novads'),
(2049, 'Latvia', 'Salas Novads'),
(2050, 'Latvia', 'Salaspils Novads'),
(2051, 'Latvia', 'Saldus Municipality'),
(2052, 'Latvia', 'Saulkrastu Novads'),
(2053, 'Latvia', 'Siguldas Novads'),
(2054, 'Latvia', 'Skrundas Novads'),
(2055, 'Latvia', 'Skr?veru Novads'),
(2056, 'Latvia', 'Smiltenes Novads'),
(2057, 'Latvia', 'Stopi?u Novads'),
(2058, 'Latvia', 'Stren?u Novads'),
(2059, 'Latvia', 'S?jas Novads'),
(2060, 'Latvia', 'Talsi Municipality'),
(2061, 'Latvia', 'Tukuma Rajons'),
(2062, 'Latvia', 'T?rvetes Novads'),
(2063, 'Latvia', 'Vai?odes Novads'),
(2064, 'Latvia', 'Valka Municipality'),
(2065, 'Latvia', 'Valmiera District'),
(2066, 'Latvia', 'Varak??nu Novads'),
(2067, 'Latvia', 'Vecpiebalgas Novads'),
(2068, 'Latvia', 'Vecumnieku Novads'),
(2069, 'Latvia', 'Ventspils'),
(2070, 'Latvia', 'Ventspils Municipality'),
(2071, 'Latvia', 'Vies?tes Novads'),
(2072, 'Latvia', 'Vi?akas Novads'),
(2073, 'Latvia', 'Vi??nu Novads'),
(2074, 'Latvia', 'V?rkavas Novads'),
(2075, 'Latvia', 'Zilupes Novads'),
(2076, 'Latvia', '?daži'),
(2077, 'Latvia', '?rg?i'),
(2078, 'Latvia', '?egums'),
(2079, 'Latvia', '?ekava'),
(2080, 'Liechtenstein', 'Balzers'),
(2081, 'Liechtenstein', 'Eschen'),
(2082, 'Liechtenstein', 'Gemeinde Gamprin'),
(2083, '         Mauren        ', 'Planken'),
(2084, '         Mauren        ', 'Ruggell'),
(2085, '         Mauren        ', 'Schaan'),
(2086, '         Mauren        ', 'Schellenberg'),
(2087, '         Mauren        ', 'Triesen'),
(2088, '         Mauren        ', 'Triesenberg'),
(2089, '         Mauren        ', 'Vaduz'),
(2090, 'Lithuania', 'Alytus'),
(2091, 'Lithuania', 'Kaunas'),
(2092, 'Lithuania', 'Klaip?da County'),
(2093, 'Lithuania', 'Marijampol? County'),
(2094, 'Lithuania', 'Panev?žys'),
(2095, 'Lithuania', 'Siauliai'),
(2096, 'Lithuania', 'Taurag? County'),
(2097, 'Lithuania', 'Telsiai'),
(2098, 'Lithuania', 'Utena'),
(2099, 'Lithuania', 'Vilnius'),
(2100, 'Luxemburg', 'Capellen'),
(2101, 'Luxemburg', 'Clervaux'),
(2102, 'Luxemburg', 'Diekirch'),
(2103, 'Luxemburg', 'Echternach'),
(2104, 'Luxemburg', 'Esch-sur-Alzette'),
(2105, 'Luxemburg', 'Grevenmacher'),
(2106, 'Luxemburg', 'Luxembourg'),
(2107, 'Luxemburg', 'Mersch'),
(2108, 'Luxemburg', 'Redange'),
(2109, 'Luxemburg', 'Remich'),
(2110, 'Luxemburg', 'Vianden'),
(2111, 'Luxemburg', 'Wiltz'),
(2112, 'Macedonia', 'Aerodrom'),
(2113, 'Macedonia', 'Berovo'),
(2114, 'Macedonia', 'Bitola'),
(2115, 'Macedonia', 'Bogdanci'),
(2116, 'Macedonia', 'Bogovinje'),
(2117, 'Macedonia', 'Bosilovo'),
(2118, 'Macedonia', 'Brvenica'),
(2119, 'Macedonia', 'Butel'),
(2120, 'Macedonia', 'Debar'),
(2121, 'Macedonia', 'Debarca'),
(2122, 'Macedonia', 'Demir Hisar'),
(2123, 'Macedonia', 'Demir Kapija'),
(2124, 'Macedonia', 'Dolneni'),
(2125, 'Macedonia', 'Drugovo'),
(2126, 'Macedonia', 'Gazi Baba'),
(2127, 'Macedonia', 'Gevgelija'),
(2128, 'Macedonia', 'Gostivar'),
(2129, 'Macedonia', 'Grad Skopje'),
(2130, 'Macedonia', 'Gradsko'),
(2131, 'Macedonia', 'Ilin'),
(2132, 'Macedonia', 'den'),
(2133, 'Macedonia', 'Jegunovce'),
(2134, 'Macedonia', 'Karbinci'),
(2135, 'Macedonia', 'Kavadarci'),
(2136, 'Macedonia', 'Kisela Voda'),
(2137, 'Macedonia', 'Kratovo'),
(2138, 'Macedonia', 'Kriva Palanka'),
(2139, 'Macedonia', 'Kumanovo'),
(2140, 'Macedonia', 'Lozovo'),
(2141, 'Macedonia', 'Makedonska Kamenica'),
(2142, 'Macedonia', 'Makedonski Brod'),
(2143, 'Macedonia', 'Mavrovo and Rostuša'),
(2144, 'Macedonia', 'Mogila'),
(2145, 'Macedonia', 'Negotino'),
(2146, 'Macedonia', 'Novaci'),
(2147, 'Macedonia', 'Novo Selo'),
(2148, 'Macedonia', 'Ohrid'),
(2149, 'Macedonia', 'Opstina Gjorce Petrov'),
(2150, 'Macedonia', 'Opstina Lipkovo'),
(2151, 'Macedonia', 'Opstina Rankovce'),
(2152, 'Macedonia', 'Opština Ara?inovo'),
(2153, 'Macedonia', 'Opština Centar'),
(2154, 'Macedonia', 'Opština Centar Župa'),
(2155, 'Macedonia', 'Opština Del?evo'),
(2156, 'Macedonia', 'Opština Dojran'),
(2157, 'Macedonia', 'Opština Karpoš'),
(2158, 'Macedonia', 'Opština Ki?evo'),
(2159, 'Macedonia', 'Opština Kon?e'),
(2160, 'Macedonia', 'Opština Ko?ani'),
(2161, 'Macedonia', 'Opština Krivogaštani'),
(2162, 'Macedonia', 'Opština Kruševo'),
(2163, 'Macedonia', 'Opština Peh?evo'),
(2164, 'Macedonia', 'Opština Probištip'),
(2165, 'Macedonia', 'Opština Radoviš'),
(2166, 'Macedonia', 'Opština Sopište'),
(2167, 'Macedonia', 'Opština Staro Nagori?ane'),
(2168, 'Macedonia', 'Opština Studeni?ani'),
(2169, 'Macedonia', 'Opština Vev?ani'),
(2170, 'Macedonia', 'Opština Vraneštica'),
(2171, 'Macedonia', 'Opština Vrap?ište'),
(2172, 'Macedonia', 'Opština ?u?er-Sandevo'),
(2173, 'Macedonia', 'Opština Štip'),
(2174, 'Macedonia', 'Opština Želino'),
(2175, 'Macedonia', 'Oslomej'),
(2176, 'Macedonia', 'Petrovec'),
(2177, 'Macedonia', 'Plasnica'),
(2178, 'Macedonia', 'Prilep'),
(2179, 'Macedonia', 'Resen'),
(2180, 'Macedonia', 'Rosoman'),
(2181, 'Macedonia', 'Saraj'),
(2182, 'Macedonia', 'Struga'),
(2183, 'Macedonia', 'Strumica'),
(2184, 'Macedonia', 'Sveti Nikole'),
(2185, 'Macedonia', 'Tearce'),
(2186, 'Macedonia', 'Tetovo'),
(2187, 'Macedonia', 'Valandovo'),
(2188, 'Macedonia', 'Vasilevo'),
(2189, 'Macedonia', 'Veles'),
(2190, 'Macedonia', 'Vinica'),
(2191, 'Macedonia', 'Zajas'),
(2192, 'Macedonia', 'Zelenikovo'),
(2193, 'Macedonia', 'Zrnovci ?air'),
(2194, 'Macedonia', '?aška Municipality'),
(2195, 'Macedonia', '?ešinovo-Obleševo'),
(2196, 'Macedonia', 'Šuto Orizari'),
(2197, 'Malta', 'Attard'),
(2198, 'Malta', 'Balzan'),
(2199, 'Malta', 'Birkirkara'),
(2200, 'Malta', 'Bir?ebbu?a'),
(2201, 'Malta', 'Bormla'),
(2202, 'Malta', 'Dingli'),
(2203, 'Malta', 'G?ajnsielem'),
(2204, 'Malta', 'Il-Belt Valletta'),
(2205, 'Malta', 'Il-Birgu'),
(2206, 'Malta', 'Il-Fgura'),
(2207, 'Malta', 'Il-Fontana'),
(2208, 'Malta', 'Il-Furjana'),
(2209, 'Malta', 'Il-Gudja'),
(2210, 'Malta', 'Il-G?ira'),
(2211, 'Malta', 'Il-Kalkara'),
(2212, 'Malta', 'Il-Marsa'),
(2213, 'Malta', 'Il-Mellie?a'),
(2214, 'Malta', 'Il-Mosta'),
(2215, 'Malta', 'Il-Munxar'),
(2216, '         Il-Qala         ', 'Il-Qrendi'),
(2217, '         Il-Qala         ', 'Il-?amrun'),
(2218, '         Il-Qala         ', 'In-Nadur'),
(2219, '         Il-Qala         ', 'In-Naxxar'),
(2220, '         Il-Qala         ', 'Ir-Rabat'),
(2221, '         Il-Qala         ', 'Is-Si??iewi'),
(2222, '         Il-Qala         ', 'Is-Swieqi'),
(2223, '         Il-Qala         ', 'Ix-Xag?ra'),
(2224, '         Il-Qala         ', 'Ix-Xewkija'),
(2225, '         Il-Qala         ', 'Ix-Xg?ajra'),
(2226, '         Il-Qala         ', 'I?-?ebbu?'),
(2227, '         Il-Qala         ', 'I?-?ejtun'),
(2228, '         Il-Qala         ', 'I?-?urrieq'),
(2229, '         Il-Qala         ', 'Kirkop'),
(2230, '         Il-Qala         ', 'L-G?arb'),
(2231, '         Il-Qala         ', 'L-G?asri'),
(2232, '         Il-Qala         ', 'L-Iklin'),
(2233, '         Il-Qala         ', 'L-Imdina'),
(2234, '         Il-Qala         ', 'L-Imqabba'),
(2235, '         Il-Qala         ', 'L-Imsida'),
(2236, '         Il-Qala         ', 'L-Imtarfa'),
(2237, '         Il-Qala         ', 'L-Im?arr'),
(2238, '         Il-Qala         ', 'L-Isla'),
(2239, '         Il-Qala         ', 'Lija'),
(2240, '         Il-Qala         ', 'Luqa'),
(2241, '         Il-Qala         ', 'Marsaskala'),
(2242, '         Il-Qala         ', 'Marsaxlokk'),
(2243, '         Il-Qala         ', 'Paola'),
(2244, '         Il-Qala         ', 'Pembroke'),
(2245, '         Il-Qala         ', 'Qormi'),
(2246, '         Il-Qala         ', 'Safi'),
(2247, '         Il-Qala         ', 'Saint John'),
(2248, '         Il-Qala         ', 'Saint Julian'),
(2249, '         Il-Qala         ', 'Saint Lawrence'),
(2250, '         Il-Qala         ', 'Saint Lucia'),
(2251, '         Il-Qala         ', 'Saint Paul’s Bay'),
(2252, '         Il-Qala         ', 'Saint Venera'),
(2253, '         Il-Qala         ', 'Sannat'),
(2254, '         Il-Qala         ', 'Tal-Pietà'),
(2255, '         Il-Qala         ', 'Tarxien'),
(2256, '         Il-Qala         ', 'Tas-Sliema'),
(2257, '         Il-Qala         ', 'Ta’ Ker?em'),
(2258, '         Il-Qala         ', 'Ta’ Xbiex'),
(2259, '         Il-Qala         ', 'Victoria'),
(2260, '         Il-Qala         ', '?al G?arg?ur'),
(2261, '         Il-Qala         ', '?al G?axaq'),
(2262, '         Il-Qala         ', '?a?-?abbar'),
(2263, '         Il-Qala         ', '?a?-?ebbu?'),
(2264, 'Moldova', 'Anenii Noi'),
(2265, 'Moldova', 'Basarabeasca'),
(2266, 'Moldova', 'Bender Municipality'),
(2267, 'Moldova', 'Briceni'),
(2268, 'Moldova', 'Cahul'),
(2269, 'Moldova', 'Cantemir'),
(2270, 'Moldova', 'Chi?in?u Municipality'),
(2271, 'Moldova', 'Cimi?lia'),
(2272, 'Moldova', 'Criuleni'),
(2273, 'Moldova', 'Dondu?eni'),
(2274, 'Moldova', 'Drochia'),
(2275, 'Moldova', 'Flore?ti'),
(2276, 'Moldova', 'F?le?ti'),
(2277, 'Moldova', 'Glodeni'),
(2278, 'Moldova', 'G?g?uzia'),
(2279, 'Moldova', 'Hînce?ti'),
(2280, 'Moldova', 'Laloveni'),
(2281, 'Moldova', 'Leova'),
(2282, 'Moldova', 'Municipiul B?l?i'),
(2283, 'Moldova', 'Nisporeni'),
(2284, 'Moldova', 'Orhei'),
(2285, 'Moldova', 'Raionul C?l?ra?i'),
(2286, 'Moldova', 'Raionul C?u?eni'),
(2287, 'Moldova', 'Raionul Dub?sari'),
(2288, 'Moldova', 'Raionul Edine?'),
(2289, 'Moldova', 'Raionul Ocni?a'),
(2290, 'Moldova', 'Raionul Soroca'),
(2291, 'Moldova', 'Raionul ?tefan Vod?'),
(2292, 'Moldova', 'Rezina'),
(2293, 'Moldova', 'Rî?cani'),
(2294, 'Moldova', 'Str??eni'),
(2295, 'Moldova', 'Sîngerei'),
(2296, 'Moldova', 'Taraclia'),
(2297, 'Moldova', 'Telene?ti'),
(2298, 'Moldova', 'Ungheni'),
(2299, 'Moldova', 'Unitatea Teritorial? din Stînga Nistrului'),
(2300, 'Moldova', '?old?ne?ti'),
(2301, 'Montenegro', 'Andrijevica'),
(2302, 'Montenegro', 'Bar'),
(2303, 'Montenegro', 'Berane'),
(2304, 'Montenegro', 'Bijelo Polje'),
(2305, 'Montenegro', 'Budva'),
(2306, 'Montenegro', 'Cetinje'),
(2307, 'Montenegro', 'Danilovgrad'),
(2308, 'Montenegro', 'Herceg Novi'),
(2309, 'Montenegro', 'Kotor'),
(2310, 'Montenegro', 'Mojkovac'),
(2311, 'Montenegro', 'Opština Kolašin'),
(2312, 'Montenegro', 'Opština Nikši?'),
(2313, 'Montenegro', 'Opština Plav'),
(2314, 'Montenegro', 'Opština Plužine'),
(2315, 'Montenegro', 'Opština Rožaje'),
(2316, 'Montenegro', 'Opština Šavnik'),
(2317, 'Montenegro', 'Opština Žabljak'),
(2318, 'Montenegro', 'Pljevlja'),
(2319, 'Montenegro', 'Podgorica'),
(2320, 'Montenegro', 'Tivat'),
(2321, 'Montenegro', 'Ulcinj'),
(2322, 'Netherland', 'Friesland'),
(2323, 'Netherland', 'Groningen'),
(2324, 'Netherland', 'Limburg'),
(2325, 'Netherland', 'North Brabant'),
(2326, 'Netherland', 'North Holland'),
(2327, 'Netherland', 'Provincie Drenthe'),
(2328, 'Netherland', 'Provincie Flevoland'),
(2329, 'Netherland', 'Provincie Gelderland'),
(2330, 'Netherland', 'Provincie Overijssel'),
(2331, 'Netherland', 'Provincie Utrecht'),
(2332, 'Netherland', 'Provincie Zeeland'),
(2333, 'Netherland', 'South Holland'),
(2334, 'Norway', 'Akershus'),
(2335, 'Norway', 'Aust-Agder'),
(2336, 'Norway', 'Buskerud'),
(2337, 'Norway', 'Finnmark'),
(2338, 'Norway', 'Hedmark'),
(2339, 'Norway', 'Hordaland Fylke'),
(2340, 'Norway', 'Møre og Romsdal fylke'),
(2341, 'Norway', 'Nord-Trøndelag Fylke'),
(2342, 'Norway', 'Nordland Fylke'),
(2343, 'Norway', 'Oppland'),
(2344, 'Norway', 'Oslo County'),
(2345, 'Norway', 'Rogaland Fylke'),
(2346, 'Norway', 'Sogn og Fjordane Fylke'),
(2347, 'Norway', 'Sør-Trøndelag Fylke'),
(2348, 'Norway', 'Telemark'),
(2349, 'Norway', 'Troms Fylke'),
(2350, 'Norway', 'Vest-Agder Fylke'),
(2351, 'Norway', 'Vestfold'),
(2352, 'Norway', 'Østfold'),
(2353, 'Poland', 'Greater Poland'),
(2354, 'Poland', 'Kujawsko-Pomorskie'),
(2355, 'Poland', 'Lesser Poland Voivodeship'),
(2356, 'Poland', 'Lower Silesia'),
(2357, ' ', 'Lublin'),
(2358, ' ', 'Lubusz'),
(2359, ' ', 'Mazovia'),
(2360, ' ', 'Opole Voivodeship'),
(2361, ' ', 'Podlasie'),
(2362, ' ', 'Pomerania'),
(2363, ' ', 'Silesia'),
(2364, ' ', 'Subcarpathian Voivodeship'),
(2365, ' ', 'Warmia-Masuria'),
(2366, ' ', 'West Pomerania'),
(2367, ' ', '?ód? Voivodeship'),
(2368, ' ', '?wi?tokrzyskie'),
(2369, 'Portugal', 'Autonomous Region of Madeira'),
(2370, 'Portugal', 'Aveiro'),
(2371, 'Portugal', 'Azores'),
(2372, 'Portugal', 'Beja'),
(2373, 'Portugal', 'Braga'),
(2374, 'Portugal', 'Bragança'),
(2375, 'Portugal', 'astelo Branco'),
(2376, ' ', 'Coimbra'),
(2377, ' ', 'Faro'),
(2378, ' ', 'Guarda'),
(2379, ' ', 'Leiria'),
(2380, ' ', 'Lisbon'),
(2381, ' ', 'Portalegre'),
(2382, ' ', 'Porto'),
(2383, ' ', 'Santarém'),
(2384, ' ', 'Setúbal'),
(2385, ' ', 'Viana do Castelo'),
(2386, ' ', 'Vila Real'),
(2387, ' ', 'Viseu'),
(2388, ' ', 'Évora'),
(2389, 'Romania', 'Arad'),
(2390, 'Romania', 'Bihor'),
(2391, 'Romania', 'Bucure?ti'),
(2392, 'Romania', 'Constan?a'),
(2393, 'Romania', 'Covasna'),
(2394, 'Romania', 'Dolj'),
(2395, 'Romania', 'Giurgiu'),
(2396, 'Romania', 'Gorj'),
(2397, 'Romania', 'Harghita'),
(2398, 'Romania', 'Hunedoara'),
(2399, ' ', 'Ilfov'),
(2400, ' ', 'Jude?ul Alba'),
(2401, ' ', 'Jude?ul Arge?'),
(2402, ' ', 'Jude?ul Bac?u'),
(2403, ' ', 'Jude?u'),
(2404, ' ', 'l Bistri?a-N?s?ud'),
(2405, ' ', 'Jude?ul Boto?ani'),
(2406, ' ', 'Jude?ul Bra?ov'),
(2407, ' ', 'Jude?ul Br?ila'),
(2408, ' ', 'Jude?ul Buz?u'),
(2409, ' ', 'Jude?ul Cara?-Severin'),
(2410, ' ', 'Jude?ul Cluj'),
(2411, ' ', 'Jude?ul C?l?ra?i'),
(2412, ' ', 'Jude?ul Dâmbovi?a'),
(2413, ' ', 'Jude?ul Gala?i'),
(2414, ' ', 'Jude?ul Ialomi?a'),
(2415, ' ', 'Jude?ul Ia?i'),
(2416, ' ', 'Jude?ul Mehedin?i'),
(2417, ' ', 'Jude?ul Mure?'),
(2418, ' ', 'Jude?ul Neam?'),
(2419, ' ', 'Jude?ul Sibiu'),
(2420, ' ', 'Jude?ul S?laj'),
(2421, ' ', 'Jude?ul Timi?'),
(2422, ' ', 'Jude?ul Vâlcea'),
(2423, ' ', 'Maramure?'),
(2424, ' ', 'Olt'),
(2425, ' ', 'Prahova'),
(2426, ' ', 'Satu Mare'),
(2427, ' ', 'Suceava'),
(2428, ' ', 'Teleorman'),
(2429, ' ', 'Tulcea'),
(2430, ' ', 'Vaslui'),
(2431, ' ', 'Vrancea'),
(2432, 'Russia', 'Altai'),
(2433, 'Russia', 'Altai Krai'),
(2434, 'Russia', 'Amurskaya Oblast’'),
(2435, 'Russia', 'Arkhangelskaya'),
(2436, 'Russia', 'Astrakhanskaya Oblast’'),
(2437, 'Russia', 'Bashkortostan'),
(2438, 'Russia', 'Belgorodskaya Oblast’'),
(2439, 'Russia', 'Bryanskaya Oblast’'),
(2440, 'Russia', 'Chechnya'),
(2441, 'Russia', 'Chelyabinsk'),
(2442, 'Russia', 'Chukot'),
(2443, 'Russia', 'Chukotka'),
(2444, 'Russia', 'Chuvashia'),
(2445, ' ', 'Dagestan'),
(2446, ' ', 'Irkutskaya Oblast’'),
(2447, ' ', 'Ivanovskaya Oblast’'),
(2448, ' ', 'Jewish Autonomous Oblast'),
(2449, ' ', 'Kabardino-Balkarskaya Respublika'),
(2450, ' ', 'Kaliningradskaya Oblast’'),
(2451, ' ', 'Kalmykiya'),
(2452, ' ', 'Kaluzhskaya Oblast’'),
(2453, ' ', 'Kamtchatski Kray'),
(2454, ' ', 'Karachayevo-Cherkesiya'),
(2455, ' ', 'Karelia'),
(2456, ' ', 'Kemerovskaya Oblast’'),
(2457, ' ', 'Khabarovsk'),
(2458, ' ', 'Khanty-Mansia'),
(2459, ' ', 'Kirovskaya Oblast’'),
(2460, ' ', 'Komi'),
(2461, ' ', 'Kostromskaya Oblast’'),
(2462, ' ', 'Krasnodarskiy Kray'),
(2463, ' ', 'Krasnoyarskiy Kray'),
(2464, ' ', 'Kurganskaya Oblast’'),
(2465, ' ', 'Kurskaya Oblast’'),
(2466, ' ', 'Lipetskaya Oblast’'),
(2467, ' ', 'Magadanskaya Oblast’'),
(2468, ' ', 'Moscow'),
(2469, ' ', 'Moscow Oblast'),
(2470, ' ', 'Murmansk'),
(2471, ' ', 'Nenets'),
(2472, ' ', 'Nizhegorodskaya Oblast’'),
(2473, ' ', 'North Ossetia'),
(2474, ' ', 'Novgorodskaya Oblast’'),
(2475, ' ', 'Novosibirskaya Oblast’'),
(2476, ' ', 'Omskaya Oblast’'),
(2477, ' ', 'Orenburgskaya Oblast’'),
(2478, ' ', 'Orlovskaya Oblast’'),
(2479, ' ', 'Penzenskaya Oblast’'),
(2480, ' ', 'Perm Krai'),
(2481, ' ', 'Primorskiy Kray'),
(2482, ' ', 'Pskovskaya Oblast’'),
(2483, ' ', 'Republic of Tyva'),
(2484, ' ', 'Respublika Adygeya'),
(2485, ' ', 'Respublika Buryatiya'),
(2486, ' ', 'Respublika Ingushetiya'),
(2487, ' ', 'Respublika Khakasiya'),
(2488, ' ', 'Respublika Mariy-El'),
(2489, ' ', 'Respublika Mordoviya'),
(2490, ' ', 'Rostov'),
(2491, ' ', 'Ryazanskaya Oblast’'),
(2492, ' ', 'Sakhalinskaya Oblast’'),
(2493, ' ', 'Samarskaya Oblast’'),
(2494, ' ', 'Saratovskaya Oblast’'),
(2495, ' ', 'Smolenskaya Oblast’'),
(2496, ' ', 'St.-Petersburg'),
(2497, ' ', 'Stavropol’skiy Kray'),
(2498, ' ', 'Sverdlovskaya Oblast’'),
(2499, ' ', 'Tambovskaya Oblast’'),
(2500, ' ', 'Tatarstan'),
(2501, ' ', 'Tomskaya Oblast’'),
(2502, ' ', 'Transbaikal Territory'),
(2503, ' ', 'Tul’skaya Oblast’'),
(2504, ' ', 'Tverskaya Oblast’'),
(2505, ' ', 'Tyumenskaya Oblast’'),
(2506, ' ', 'Udmurtskaya Respublika'),
(2507, ' ', 'Ulyanovsk'),
(2508, ' ', 'Vladimirskaya Oblast’'),
(2509, ' ', 'Volgogradskaya Oblast’'),
(2510, ' ', 'Vologodskaya Oblast’'),
(2511, ' ', 'Voronezhskaya Oblast’'),
(2512, ' ', 'Yamalo-Nenets'),
(2513, ' ', 'Yaroslavskaya Oblast’'),
(2514, ' ', 'Castello di Acquaviva'),
(2515, ' ', 'Castello di Borgo Maggiore'),
(2516, ' ', 'Castello di Domagnano'),
(2517, ' ', 'Castello di Faetano'),
(2518, ' ', 'Castello di Fiorentino'),
(2519, ' ', 'Castello di Montegiardino'),
(2520, ' ', 'Castello di San Marino Città'),
(2521, ' ', 'Chiesanuova'),
(2522, ' ', 'Serravalle'),
(2523, 'Sabria', 'Castello di Acquaviva'),
(2524, ' ', 'Castello di Borgo Maggiore'),
(2525, ' ', 'Castello di Domagnano'),
(2526, ' ', 'Castello di Faetano'),
(2527, ' ', 'Castello di Fiorentino'),
(2528, ' ', 'Castello di Montegiardino'),
(2529, ' ', 'Castello di San Marino Città'),
(2530, ' ', 'Chiesanuova'),
(2531, ' ', 'Serravalle'),
(2532, ' ', 'Beltinci'),
(2533, ' ', 'Benedikt'),
(2534, ' ', 'Bistrica ob Sotli'),
(2535, ' ', 'Bloke'),
(2536, ' ', 'Bohinj'),
(2537, ' ', 'Borovnica'),
(2538, ' ', 'Brda'),
(2539, ' ', 'Brezovica'),
(2540, ' ', 'Cankova'),
(2541, ' ', 'Celje'),
(2542, ' ', 'Cerklje na Gorenjskem'),
(2543, ' ', 'Cerknica'),
(2544, ' ', 'Cerkno'),
(2545, ' ', 'Cerkvenjak'),
(2546, ' ', 'Cirkulane'),
(2547, ' ', 'Comune di Ancarano'),
(2548, ' ', 'Destrnik'),
(2549, ' ', 'Dobje'),
(2550, ' ', 'Dobrepolje'),
(2551, ' ', 'Dobrna'),
(2552, ' ', 'Dobrova-Polhov Gradec'),
(2553, ' ', 'Dobrovnik'),
(2554, ' ', 'Dol pri Ljubljani'),
(2555, ' ', 'Dolenjske Toplice'),
(2556, ' ', 'Dornava'),
(2557, ' ', 'Dravograd'),
(2558, ' ', 'Duplek'),
(2559, ' ', 'Gorenja Vas-Poljane'),
(2560, ' ', 'Gorje'),
(2561, ' ', 'Gornja Radgona'),
(2562, ' ', 'Gornji Grad'),
(2563, ' ', 'Gornji Petrovci'),
(2564, ' ', 'Grad'),
(2565, ' ', 'Grosuplje'),
(2566, ' ', 'Hajdina'),
(2567, ' ', 'Hodos'),
(2568, ' ', 'Horjul'),
(2569, ' ', 'Hrastnik'),
(2570, ' ', 'Hrpelje-Kozina'),
(2571, ' ', 'Idrija'),
(2572, ' ', 'Ig'),
(2573, '          Ilirska Bistrica      ', 'Izola'),
(2574, '          Ilirska Bistrica      ', 'Jesenice'),
(2575, '          Ilirska Bistrica      ', 'Jezersko'),
(2576, '          Ilirska Bistrica      ', 'Kamnik'),
(2577, '          Ilirska Bistrica      ', 'Kanal'),
(2578, '          Ilirska Bistrica      ', 'Kobilje'),
(2579, '          Ilirska Bistrica      ', 'Komen'),
(2580, '          Ilirska Bistrica      ', 'Komenda'),
(2581, '          Ilirska Bistrica      ', 'Koper'),
(2582, '          Ilirska Bistrica      ', 'Kostanjevica na Krki'),
(2583, '          Ilirska Bistrica      ', 'Kostel'),
(2584, '          Ilirska Bistrica      ', 'Kozje'),
(2585, '          Ilirska Bistrica      ', 'Kranj'),
(2586, '          Ilirska Bistrica      ', 'Kranjska Gora'),
(2587, '          Ilirska Bistrica      ', 'Kungota'),
(2588, '          Ilirska Bistrica      ', 'Kuzma'),
(2589, '          Ilirska Bistrica      ', 'Lenart'),
(2590, '          Ilirska Bistrica      ', 'Lendava'),
(2591, '          Ilirska Bistrica      ', 'Litija'),
(2592, '          Ilirska Bistrica      ', 'Ljubno'),
(2593, '          Ilirska Bistrica      ', 'Ljutomer'),
(2594, '          Ilirska Bistrica      ', 'Logatec'),
(2595, '          Ilirska Bistrica      ', 'Log–Dragomer'),
(2596, '          Ilirska Bistrica      ', 'Lovrenc na Pohorju'),
(2597, '          Ilirska Bistrica      ', 'Lukovica'),
(2598, '          Ilirska Bistrica      ', 'Makole'),
(2599, '          Ilirska Bistrica      ', 'Maribor'),
(2600, '          Ilirska Bistrica      ', 'Markovci'),
(2601, '          Ilirska Bistrica      ', 'Medvode'),
(2602, '          Ilirska Bistrica      ', 'Mestna Ob?ina Novo mesto'),
(2603, '          Ilirska Bistrica      ', 'Metlika'),
(2604, '          Ilirska Bistrica      ', 'Miren-Kostanjevica'),
(2605, '          Ilirska Bistrica      ', 'Mirna'),
(2606, '          Ilirska Bistrica      ', 'Mislinja'),
(2607, '          Ilirska Bistrica      ', 'Mokronog-Trebelno'),
(2608, '          Ilirska Bistrica      ', 'Moravske Toplice'),
(2609, '          Ilirska Bistrica      ', 'Mozirje'),
(2610, '          Ilirska Bistrica      ', 'Murska Sobota'),
(2611, '          Ilirska Bistrica      ', 'Muta          Naklo'),
(2612, '          Ilirska Bistrica      ', 'Nazarje'),
(2613, '          Ilirska Bistrica      ', 'Nova Gorica'),
(2614, '          Ilirska Bistrica      ', 'Ob?ina Apa?e'),
(2615, '          Ilirska Bistrica      ', 'Ob?ina Bled'),
(2616, '          Ilirska Bistrica      ', 'Ob?ina Bovec'),
(2617, '          Ilirska Bistrica      ', 'Ob?ina Braslov?e'),
(2618, '          Ilirska Bistrica      ', 'Ob?ina Diva?a'),
(2619, '          Ilirska Bistrica      ', 'Ob?ina Domžale'),
(2620, '          Ilirska Bistrica      ', 'Ob?ina Gorišnica'),
(2621, '          Ilirska Bistrica      ', 'Ob?ina Ho?e-Slivnica'),
(2622, '          Ilirska Bistrica      ', 'Ob?ina Ivan?na Gorica'),
(2623, '          Ilirska Bistrica      ', 'Ob?ina Juršinci'),
(2624, '          Ilirska Bistrica      ', 'Ob?ina Kidri?evo'),
(2625, '          Ilirska Bistrica      ', 'Ob?ina Kobarid'),
(2626, '          Ilirska Bistrica      ', 'Ob?ina Križevci'),
(2627, '          Ilirska Bistrica      ', 'Ob?ina Krško'),
(2628, '          Ilirska Bistrica      ', 'Ob?ina Laško'),
(2629, '          Ilirska Bistrica      ', 'Ob?ina Loška Dolina'),
(2630, '          Ilirska Bistrica      ', 'Ob?ina Loški Potok'),
(2631, '          Ilirska Bistrica      ', 'Ob?ina Lu?e'),
(2632, '          Ilirska Bistrica      ', 'Ob?ina Majšperk'),
(2633, '          Ilirska Bistrica      ', 'Ob?ina Mengeš'),
(2634, '          Ilirska Bistrica      ', 'Ob?ina Mežica'),
(2635, '          Ilirska Bistrica      ', 'Ob?ina Miklavž na Dravskem Polju'),
(2636, '          Ilirska Bistrica      ', 'Ob?ina Mirna Pe?'),
(2637, '          Ilirska Bistrica      ', 'Ob?ina Morav?e'),
(2638, '          Ilirska Bistrica      ', 'Ob?ina Ormož'),
(2639, '          Ilirska Bistrica      ', 'Ob?ina Pod?etrtek'),
(2640, '          Ilirska Bistrica      ', 'Ob?ina Polj?ane'),
(2641, '          Ilirska Bistrica      ', 'Ob?ina Rade?e'),
(2642, '          Ilirska Bistrica      ', 'Ob?ina Ravne na Koroškem'),
(2643, '          Ilirska Bistrica      ', 'Ob?ina Razkrižje'),
(2644, '          Ilirska Bistrica      ', 'Ob?ina Ra?e-Fram'),
(2645, '          Ilirska Bistrica      ', 'Ob?ina Ren?e-Vogrsko'),
(2646, '          Ilirska Bistrica      ', 'Ob?ina Re?ica ob'),
(2647, '          Ilirska Bistrica      ', 'Savinji'),
(2648, '          Ilirska Bistrica      ', 'Ob?ina Rogaška Slatina'),
(2649, '          Ilirska Bistrica      ', 'Ob?ina Rogašovci'),
(2650, '          Ilirska Bistrica      ', 'Ob?ina Ruše'),
(2651, '          Ilirska Bistrica      ', 'Ob?ina Semi?'),
(2652, '          Ilirska Bistrica      ', 'Ob?ina Sodražica'),
(2653, '          Ilirska Bistrica      ', 'Ob?ina Sol?ava'),
(2654, '          Ilirska Bistrica      ', 'Ob?ina Središ?e ob Dravi'),
(2655, '          Ilirska Bistrica      ', 'Ob?ina Starše'),
(2656, '          Ilirska Bistrica      ', 'Ob?ina Straža'),
(2657, '          Ilirska Bistrica      ', 'Ob?ina Sveti Andraž v Slovenskih Goricah'),
(2658, '          Ilirska Bistrica      ', 'Ob?ina Sveti Jurij ob Š?avnici'),
(2659, '          Ilirska Bistrica      ', 'Ob?ina Sveti Tomaž'),
(2660, '          Ilirska Bistrica      ', 'Ob?ina Tišina'),
(2661, '          Ilirska Bistrica      ', 'Ob?ina Turniš?e'),
(2662, '          Ilirska Bistrica      ', 'Ob?ina Velike Laš?e'),
(2663, '          Ilirska Bistrica      ', 'Ob?ina Veržej'),
(2664, '          Ilirska Bistrica      ', 'Ob?ina Zavr?'),
(2665, '          Ilirska Bistrica      ', 'Ob?ina Zre?e'),
(2666, '          Ilirska Bistrica      ', 'Ob?ina ?renšovci'),
(2667, '          Ilirska Bistrica      ', 'Ob?ina ?rna na Koroškem'),
(2668, '          Ilirska Bistrica      ', 'Ob?ina Šalovci'),
(2669, '          Ilirska Bistrica      ', 'Ob?ina Šentilj'),
(2670, '          Ilirska Bistrica      ', 'Ob?ina Šentjernej'),
(2671, '          Ilirska Bistrica      ', 'Ob?ina Šentrupert'),
(2672, '          Ilirska Bistrica      ', 'Ob?ina Šen?ur'),
(2673, '          Ilirska Bistrica      ', 'Ob?ina Škocjan'),
(2674, '          Ilirska Bistrica      ', 'Ob?ina Škofljica'),
(2675, '          Ilirska Bistrica      ', 'Ob?ina Šmarje pri Jelšah'),
(2676, '          Ilirska Bistrica      ', 'Ob?ina Šmarješke Toplice'),
(2677, '          Ilirska Bistrica      ', 'Ob?ina Šmartno ob Paki'),
(2678, '          Ilirska Bistrica      ', 'Ob?ina Šmartno pri Litiji'),
(2679, '          Ilirska Bistrica      ', 'Ob?ina Šoštanj'),
(2680, '          Ilirska Bistrica      ', 'Ob?ina Štore'),
(2681, '          Ilirska Bistrica      ', 'Ob?ina Žalec'),
(2682, '          Ilirska Bistrica      ', 'Ob?ina Železniki'),
(2683, '          Ilirska Bistrica      ', 'Ob?ina Žetale'),
(2684, '          Ilirska Bistrica      ', 'Ob?ina Žiri'),
(2685, '          Ilirska Bistrica      ', 'Ob?ina Žirovnica'),
(2686, '          Ilirska Bistrica      ', 'Odranci'),
(2687, '          Ilirska Bistrica      ', 'Oplotnica'),
(2688, '          Ilirska Bistrica      ', 'Osilnica'),
(2689, '          Ilirska Bistrica      ', 'Pesnica'),
(2690, '          Ilirska Bistrica      ', 'Preddvor'),
(2691, '          Ilirska Bistrica      ', 'Prevalje'),
(2692, '          Ilirska Bistrica      ', 'Ptuj'),
(2693, '          Ilirska Bistrica      ', 'Puconci'),
(2694, '          Ilirska Bistrica      ', 'Radenci          Radlje ob Dravi          Radovljica'),
(2695, '          Ilirska Bistrica      ', 'Ribnica'),
(2696, '          Andalusia        ', 'Aragon'),
(2697, '          Andalusia        ', 'Asturias'),
(2698, '          Andalusia        ', 'Balearic Islands'),
(2699, '          Andalusia        ', 'Basque Country'),
(2700, '          Andalusia        ', 'Canary Islands'),
(2701, '          Andalusia        ', 'Cantabria'),
(2702, '          Andalusia        ', 'Castille and León'),
(2703, '          Andalusia        ', 'Castille-La Mancha'),
(2704, '          Andalusia        ', 'Catalonia'),
(2705, '          Andalusia        ', 'Ceuta'),
(2706, '          Andalusia        ', 'Extremadura'),
(2707, '          Andalusia        ', 'Galicia'),
(2708, '          Andalusia        ', 'La Rioja'),
(2709, '          Andalusia        ', 'Madrid'),
(2710, '          Andalusia        ', 'Melilla'),
(2711, '          Andalusia        ', 'Murcia'),
(2712, '          Andalusia        ', 'Navarre'),
(2713, '          Andalusia        ', 'Valencia'),
(2714, 'Sweden', 'Blekinge'),
(2715, 'Sweden', 'Dalarna'),
(2716, ' ', 'Gotland'),
(2717, ' ', 'Gävleborg'),
(2718, ' ', 'Halland'),
(2719, ' ', 'Jämtland'),
(2720, ' ', 'Jönköping'),
(2721, ' ', 'Kalmar'),
(2722, ' ', 'Kronoberg'),
(2723, ' ', 'Norrbotten'),
(2724, ' ', 'Skåne'),
(2725, ' ', 'Stockholm'),
(2726, ' ', 'Södermanland'),
(2727, ' ', 'Uppsala'),
(2728, ' ', 'Värmland'),
(2729, ' ', 'Västerbotten'),
(2730, ' ', 'Västernorrland'),
(2731, ' ', 'Västmanland'),
(2732, ' ', 'Västra Götaland'),
(2733, ' ', 'Örebro'),
(2734, ' ', 'Östergötland'),
(2735, 'Anguilla', 'Blowing Point'),
(2736, 'Anguilla', 'East End'),
(2737, 'Anguilla', 'George Hill'),
(2738, 'Anguilla', 'Island Harbour'),
(2739, 'Anguilla', 'North Hill'),
(2740, 'Anguilla', 'North Side'),
(2741, 'Anguilla', 'Sandy Ground'),
(2742, 'Anguilla', 'Sandy Hill'),
(2743, 'Anguilla', 'South Hill'),
(2744, 'Anguilla', 'Stoney Ground'),
(2745, 'Anguilla', 'The Farrington'),
(2746, 'Anguilla', 'The Quarter'),
(2747, 'Anguilla', 'The Valley'),
(2748, 'Anguilla', 'West End'),
(2749, 'Antigua', 'Barbuda'),
(2750, 'Antigua', 'Parish of Saint George'),
(2751, 'Antigua', 'Parish of Saint John'),
(2752, 'Antigua', 'Parish of Saint Mary'),
(2753, 'Antigua', 'Parish of Saint Paul'),
(2754, 'Antigua', 'Parish of Saint Peter'),
(2755, 'Antigua', 'Parish of Saint Philip'),
(2756, 'Antigua', 'Redonda'),
(2757, 'Mahamas', 'Acklins Island District'),
(2758, 'Mahamas', 'Berry Islands District'),
(2759, 'Mahamas', 'Bimini'),
(2760, 'Mahamas', 'Black Point District'),
(2761, 'Mahamas', 'Cat Island'),
(2762, 'Mahamas', 'Central Abaco District'),
(2763, 'Mahamas', 'Central Andros District'),
(2764, 'Mahamas', 'Central Eleuthera District'),
(2765, 'Mahamas', 'City of Freeport District'),
(2766, 'Mahamas', 'Crooked Island and Long Cay District'),
(2767, 'Mahamas', 'East Grand Bahama District'),
(2768, 'Mahamas', 'Exuma District'),
(2769, 'Mahamas', 'Grand Cay District'),
(2770, 'Mahamas', 'Harbour Island'),
(2771, 'Mahamas', 'Hope Town District'),
(2772, 'Mahamas', 'Inagua'),
(2773, 'Mahamas', 'Long Island'),
(2774, 'Mahamas', 'Mangrove Cay'),
(2775, 'Mahamas', 'Mayaguana District'),
(2776, 'Mahamas', 'Moore’s Island District'),
(2777, 'Mahamas', 'New Providence District'),
(2778, 'Mahamas', 'North Abaco District'),
(2779, 'Mahamas', 'North Andros District'),
(2780, 'Mahamas', 'North Eleuthera'),
(2781, 'Mahamas', 'Ragged Island District'),
(2782, 'Mahamas', 'Rum Cay'),
(2783, 'Mahamas', 'San Salvador District'),
(2784, 'Mahamas', 'South Abaco District'),
(2785, 'Mahamas', 'South Andros'),
(2786, 'Mahamas', 'South Eleuthera'),
(2787, 'Mahamas', 'Spanish Wells District'),
(2788, 'Mahamas', 'West Grand Bahama District'),
(2789, 'Barbados', 'Christ Church'),
(2790, 'Barbados', 'Saint Andrew'),
(2791, 'Barbados', 'Saint George'),
(2792, 'Barbados', 'Saint James'),
(2793, 'Barbados', 'Saint John'),
(2794, 'Barbados', 'Saint Joseph'),
(2795, 'Barbados', 'Saint Lucy'),
(2796, 'Barbados', 'Saint Michael'),
(2797, 'Barbados', 'Saint Peter'),
(2798, 'Barbados', 'Saint Philip'),
(2799, 'Barbados', 'Saint Thomas'),
(2800, 'Belize', 'Belize District'),
(2801, 'Belize', 'Cayo District'),
(2802, 'Belize', 'Orange Walk District'),
(2803, 'Belize', 'Stann Creek District'),
(2804, 'Belize', 'Toledo District'),
(2805, 'Bermuda', 'Devonshire Parish'),
(2806, 'Bermuda', 'Hamilton'),
(2807, 'Bermuda', 'Hamilton city'),
(2808, 'Bermuda', 'Paget'),
(2809, 'Bermuda', 'Pembroke Parish'),
(2810, 'Bermuda', 'Saint George'),
(2811, 'Bermuda', 'Saint George’s Parish'),
(2812, 'Bermuda', 'Sandys Parish'),
(2813, 'Bermuda', 'Smith’s Parish'),
(2814, 'Bermuda', 'Southampton Parish'),
(2815, 'Bermuda', 'Warwick Parish'),
(2816, 'Bonaire', 'Bonaire'),
(2817, 'Bonaire', 'Saba'),
(2818, 'Bonaire', 'Sint Eustatius'),
(2819, 'Canada', 'Alberta'),
(2820, 'Canada', 'British Columbia'),
(2821, 'Canada', 'Manitoba'),
(2822, 'Canada', 'New Brunswick'),
(2823, 'Canada', 'Newfoundland and Labrador'),
(2824, 'Canada', 'Northwest Territories'),
(2825, 'Canada', 'Nova Scotia'),
(2826, 'Canada', 'Nunavut'),
(2827, 'Canada', 'Ontario'),
(2828, 'Canada', 'Prince Edward Island'),
(2829, 'Canada', 'Quebecg'),
(2830, 'Canada', 'Saskatchewan'),
(2831, 'Canada', 'Yukon'),
(2832, 'Cayman Islands', 'Bodden Town'),
(2833, 'Cayman Islands', 'East End'),
(2834, 'Cayman Islands', 'George Town'),
(2835, 'Cayman Islands', 'North Side'),
(2836, 'Cayman Islands', 'Sister Island'),
(2837, 'Cayman Islands', 'West Bay'),
(2838, 'Costa Rica', 'Provincia de Alajuela'),
(2839, 'Costa Rica', 'Provincia de Cartago'),
(2840, 'Costa Rica', 'Provincia de Guanacaste'),
(2841, 'Costa Rica', 'Provincia de Heredia'),
(2842, 'Costa Rica', 'Provincia de Limón'),
(2843, 'Costa Rica', 'Provincia de Puntarenas'),
(2844, 'Costa Rica', 'Provincia de San José'),
(2845, 'Cuba', 'Artemisa'),
(2846, 'Cuba', 'La Habana'),
(2847, 'Cuba', 'Las Tunas'),
(2848, 'Cuba', 'Mayabeque'),
(2849, 'Cuba', 'Municipio Especial Isla de la Juventud'),
(2850, 'Cuba', 'Provincia Granma'),
(2851, 'Cuba', 'Provincia de Camagüey'),
(2852, 'Cuba', 'Provincia de Ciego de Ávila'),
(2853, 'Cuba', 'Provincia de Cienfuegos'),
(2854, 'Cuba', 'Provincia de Guantánamo'),
(2855, 'Cuba', 'Provincia de Holguín'),
(2856, 'Cuba', 'Provincia de Matanzas'),
(2857, 'Cuba', 'Provincia de Pinar del Río'),
(2858, 'Cuba', 'Provincia de Sancti Spíritus'),
(2859, 'Cuba', 'Provincia de Santiago de Cuba'),
(2860, 'Cuba', 'Provincia de Villa Clara'),
(2861, 'Dominica', 'Saint Andrew'),
(2862, 'Dominica', 'Saint David'),
(2863, 'Dominica', 'Saint George'),
(2864, 'Dominica', 'Saint John'),
(2865, 'Dominica', 'Saint Joseph'),
(2866, 'Dominica', 'Saint Luke'),
(2867, 'Dominica', 'Saint Mark'),
(2868, 'Dominica', 'Saint Patrick'),
(2869, 'Dominica', 'Saint Paul'),
(2870, 'Dominica', 'Saint Peter'),
(2871, 'El Salvador', 'Departamento de Ahuachapán'),
(2872, 'El Salvador', 'Departamento de Cabañas'),
(2873, 'El Salvador', 'Departamento de Chalatenango'),
(2874, 'El Salvador', 'Departamento de Cuscatlán'),
(2875, 'El Salvador', 'Departamento de La Libertad'),
(2876, 'El Salvador', 'Departamento de La Paz'),
(2877, 'El Salvador', 'Departamento de La Unión'),
(2878, 'El Salvador', 'Departamento de Morazán'),
(2879, 'El Salvador', 'Departamento de San Miguel'),
(2880, 'El Salvador', 'Departamento de San Salvador'),
(2881, 'El Salvador', 'Departamento de San Vicente'),
(2882, 'El Salvador', 'Departamento de Santa Ana'),
(2883, 'El Salvador', 'Departamento de Usulután'),
(2884, 'Greenland', 'Kujalleq'),
(2885, 'Greenland', 'Qaasuitsup'),
(2886, 'Greenland', 'Qeqqata'),
(2887, 'Greenland', 'Sermersooq'),
(2888, ' ', 'Carriacou and Petite Martinique'),
(2889, ' ', 'Saint Andrew'),
(2890, ' ', 'Saint David'),
(2891, ' ', 'Saint George'),
(2892, ' ', 'Saint John'),
(2893, ' ', 'Saint Mark'),
(2894, ' ', 'Saint Patrick'),
(2895, 'Gautemala', 'Departamento de Alta Verapaz'),
(2896, 'Gautemala', 'Departamento de Baja Verapaz'),
(2897, 'Gautemala', 'Departamento de Chimaltenango'),
(2898, 'Gautemala', 'Departamento de Chiquimula'),
(2899, 'Gautemala', 'Departamento de El Progreso'),
(2900, 'Gautemala', 'Departamento de Escuintla'),
(2901, 'Gautemala', 'Departamento de Guatemala'),
(2902, 'Gautemala', 'Departamento de Huehuetenango'),
(2903, 'Gautemala', 'Departamento de Izabal'),
(2904, 'Gautemala', 'Departamento de Jalapa'),
(2905, 'Gautemala', 'Departamento de Jutiapa'),
(2906, 'Gautemala', 'Departamento de Quetzaltenango'),
(2907, 'Gautemala', 'Departamento de Retalhuleu'),
(2908, 'Gautemala', 'Departamento de Sacatepéquez'),
(2909, 'Gautemala', 'Departamento de San Marcos'),
(2910, 'Gautemala', 'Departamento de Santa Rosa'),
(2911, 'Gautemala', 'Departamento de Sololá'),
(2912, 'Gautemala', 'Departamento de Totonicapán'),
(2913, 'Gautemala', 'Departamento de Zacapa'),
(2914, 'Gautemala', 'Departamento del Petén'),
(2915, 'Gautemala', 'Departamento del Quiché'),
(2916, 'Gautemala', 'Suchitepequez Department'),
(2917, ' ', 'Centre'),
(2918, ' ', 'Département de Nippes'),
(2919, ' ', 'Département du Nord-Est'),
(2920, ' ', 'Grandans'),
(2921, ' ', 'Nord'),
(2922, ' ', 'Nord-Ouest'),
(2923, ' ', 'Sud'),
(2924, ' ', 'Sud-Est'),
(2925, 'Honduras', 'Bay Islands'),
(2926, 'Honduras', 'Departamento de Atlántida'),
(2927, 'Honduras', 'Departamento de Choluteca'),
(2928, 'Honduras', 'Departamento de Colón'),
(2929, 'Honduras', 'Departamento de Comayagua'),
(2930, 'Honduras', 'Departamento de Copán'),
(2931, 'Honduras', 'Departamento de Cortés'),
(2932, 'Honduras', 'Departamento de El Paraíso'),
(2933, 'Honduras', 'Departamento de Francisco Morazán'),
(2934, 'Honduras', 'Departamento de Gracias a Dios'),
(2935, 'Honduras', 'Departamento de Intibucá'),
(2936, 'Honduras', 'Departamento de La Paz'),
(2937, 'Honduras', 'Departamento de Lempira'),
(2938, 'Honduras', 'Dep'),
(2939, 'Honduras', 'artamento de Ocotepeque'),
(2940, 'Honduras', 'Departamento de Olancho'),
(2941, 'Honduras', 'Departamento de Santa Bárbara'),
(2942, 'Honduras', 'Departamento de Valle'),
(2943, 'Honduras', 'Departamento de Yoro'),
(2944, 'Jamaica', 'Clarendon'),
(2945, 'Jamaica', 'Hanover'),
(2946, 'Jamaica', 'Kingston'),
(2947, 'Jamaica', 'Manchester'),
(2948, 'Jamaica', 'Parish of Saint Ann'),
(2949, 'Jamaica', 'Portland'),
(2950, 'Jamaica', 'Saint Andrew'),
(2951, 'Jamaica', 'Saint Catherine'),
(2952, 'Jamaica', 'Saint James'),
(2953, 'Jamaica', 'Saint Mary'),
(2954, 'Jamaica', 'Saint Thomas'),
(2955, 'Jamaica', 'St. Elizabeth'),
(2956, 'Jamaica', 'Trelawny'),
(2957, 'Jamaica', 'Westmoreland'),
(2958, 'Martinique', 'Martinique'),
(2959, 'Mexico', 'Aguascalientes'),
(2960, 'Mexico', 'Baja California Sur'),
(2961, 'Mexico', 'Campeche'),
(2962, 'Mexico', 'Chiapas'),
(2963, 'Mexico', 'Chihuahua'),
(2964, 'Mexico', 'Coahuila'),
(2965, 'Mexico', 'Colima'),
(2966, 'Mexico', 'Durango'),
(2967, 'Mexico', 'Estado de Baja California'),
(2968, 'Mexico', 'Estado de México'),
(2969, 'Mexico', 'Guanajuato'),
(2970, 'Mexico', 'Guerrero'),
(2971, 'Mexico', 'Hidalgo'),
(2972, 'Mexico', 'Jalisco'),
(2973, 'Mexico', 'Mexico City'),
(2974, 'Mexico', 'Michoacán'),
(2975, 'Mexico', 'Morelos'),
(2976, 'Mexico', 'Nayarit'),
(2977, 'Mexico', 'Nuevo León'),
(2978, 'Mexico', 'Oaxaca'),
(2979, 'Mexico', 'Puebla'),
(2980, 'Mexico', 'Querétaro'),
(2981, 'Mexico', 'Quintana Roo'),
(2982, 'Mexico', 'San Luis Potosí'),
(2983, 'Mexico', 'Sinaloa'),
(2984, 'Mexico', 'Sonora'),
(2985, 'Mexico', 'Tabasco'),
(2986, 'Mexico', 'Tamaulipas'),
(2987, 'Mexico', 'Tlaxcala'),
(2988, 'Mexico', 'Veracruz'),
(2989, 'Mexico', 'Yucatán'),
(2990, 'Mexico', 'Zacatecas'),
(2991, 'Montserrat', 'Parish of Saint Anthony'),
(2992, 'Montserrat', 'Parish of Saint Georges'),
(2993, 'Montserrat', 'Parish of Saint Peter'),
(2994, 'Nicaragua', 'Costa Caribe Sur'),
(2995, 'Nicaragua', 'Departamento de Boaco'),
(2996, 'Nicaragua', 'Departamento de Carazo'),
(2997, 'Nicaragua', 'Departamento de Chinandega'),
(2998, 'Nicaragua', 'Departamento de Chontales'),
(2999, 'Nicaragua', 'Departamento de Estelí'),
(3000, 'Nicaragua', 'Departamento de Granada'),
(3001, 'Nicaragua', 'Departamento de Jinotega'),
(3002, 'Nicaragua', 'Departamento de León'),
(3003, 'Nicaragua', 'Departamento de Madriz'),
(3004, 'Nicaragua', 'Departamento de Managua'),
(3005, 'Nicaragua', 'Departamento de Masaya'),
(3006, 'Nicaragua', 'Departamento de Matagalpa'),
(3007, 'Nicaragua', 'Departamento de Nueva Segovia'),
(3008, 'Nicaragua', 'Departamento de Rivas'),
(3009, 'Nicaragua', 'Departamento de Río San Juan'),
(3010, 'Nicaragua', 'North Atlantic Autonomous Region (RAAN)'),
(3011, 'Panama', 'Emberá-Wounaan'),
(3012, 'Panama', 'Guna Yala'),
(3013, 'Panama', 'Ngöbe-Buglé'),
(3014, 'Panama', 'Panamá Oeste'),
(3015, 'Panama', 'Provincia de Bocas del Toro'),
(3016, 'Panama', 'Provincia de Chiriquí'),
(3017, 'Panama', 'Provincia de Coclé'),
(3018, 'Panama', 'Provincia de Colón'),
(3019, 'Panama', 'Provincia de Herrera'),
(3020, 'Panama', 'Provincia de Los Santos'),
(3021, 'Panama', 'Provincia de Panamá'),
(3022, 'Panama', 'Provincia de Veraguas'),
(3023, 'Panama', 'Provincia del Darién'),
(3024, 'Puerto Rico', 'Adjuntas'),
(3025, 'Puerto Rico', 'Aguada'),
(3026, 'Puerto Rico', 'Aguadilla'),
(3027, 'Puerto Rico', 'Aguas Buenas'),
(3028, 'Puerto Rico', 'Aibonito'),
(3029, 'Puerto Rico', 'Arecibo'),
(3030, 'Puerto Rico', 'Arroyo'),
(3031, 'Puerto Rico', 'Añasco'),
(3032, 'Puerto Rico', 'Barceloneta'),
(3033, 'Puerto Rico', 'Barranquitas'),
(3034, 'Puerto Rico', 'Bayamón Municipio'),
(3035, 'Puerto Rico', 'Cabo Rojo Municipio'),
(3036, ' ', 'Christ Church Nichola Town'),
(3037, ' ', 'Middle Island'),
(3038, ' ', 'Saint Anne Sandy Point'),
(3039, ' ', 'Saint George Basseterre'),
(3040, ' ', 'Saint George Gingerland'),
(3041, ' ', 'Saint James Windward'),
(3042, ' ', 'Saint John Capesterre'),
(3043, ' ', 'Saint John Figtree'),
(3044, ' ', 'Saint Mary Cayon'),
(3045, ' ', 'Saint Paul Capesterre'),
(3046, ' ', 'Saint Paul Charlestown'),
(3047, ' ', 'Saint Peter Basseterre'),
(3048, ' ', 'Saint Thomas Lowland'),
(3049, ' ', 'Trinity Palmetto Point'),
(3050, 'Saint Lucia', 'Anse-la-Raye'),
(3051, ' ', 'Canaries'),
(3052, ' ', 'Castries'),
(3053, ' ', 'Choiseul'),
(3054, ' ', 'Dennery'),
(3055, ' ', 'Gros-Islet'),
(3056, ' ', 'Laborie'),
(3057, ' ', 'Micoud'),
(3058, ' ', 'Soufrière'),
(3059, ' ', 'Vieux-Fort'),
(3060, 'Saint Pierre', 'Commune de Saint-Pierre');
INSERT INTO `country_state_list` (`id`, `country_name`, `state_name`) VALUES
(3061, 'Saint Pierre', 'Miquelon-Langlade'),
(3062, 'Saint Vincent', 'Grenadines'),
(3063, ' ', 'Parish of Charlotte'),
(3064, ' ', 'Parish of Saint Andrew'),
(3065, ' ', 'Parish of Saint David'),
(3066, ' ', 'Parish of Saint George'),
(3067, ' ', 'Parish of Saint Patrick'),
(3068, 'Trinidad and Tobago', 'Borough of Arima'),
(3069, 'Trinidad and Tobago', 'Chaguanas'),
(3070, 'Trinidad and Tobago', 'City of Port of Spain'),
(3071, 'Trinidad and Tobago', 'City of San Fernando'),
(3072, 'Trinidad and Tobago', 'Couva-Tabaquite-Talparo'),
(3073, 'Trinidad and Tobago', 'Diego Martin'),
(3074, 'Trinidad and Tobago', 'Mayaro'),
(3075, 'Trinidad and Tobago', 'Penal/Debe'),
(3076, 'Trinidad and Tobago', 'Point Fortin'),
(3077, 'Trinidad and Tobago', 'Princes Town'),
(3078, ' ', 'San Juan/Laventille'),
(3079, ' ', 'Sangre Grande'),
(3080, ' ', 'Siparia'),
(3081, ' ', 'Tobago'),
(3082, ' ', 'Tunapuna/Piarco'),
(3083, 'US Virgin Island', 'Saint Croix Island'),
(3084, 'US Virgin Island', 'Saint John Island'),
(3085, 'US Virgin Island', 'Saint Thomas Island'),
(3086, 'United States', 'Alabama'),
(3087, ' ', 'Alaska'),
(3088, ' ', 'Arizona'),
(3089, ' ', 'Arkansas'),
(3090, ' ', 'California'),
(3091, ' ', 'Colorado'),
(3092, ' ', 'Connecticut'),
(3093, ' ', 'Delaware'),
(3094, ' ', 'Florida'),
(3095, ' ', 'Georgia'),
(3096, ' ', 'Hawaii'),
(3097, ' ', 'Idaho'),
(3098, ' ', 'Illinois'),
(3099, ' ', 'Indiana'),
(3100, ' ', 'Iowa'),
(3101, ' ', 'Kansas'),
(3102, ' ', 'Kentucky'),
(3103, ' ', 'Louisiana'),
(3104, ' ', 'Maine'),
(3105, ' ', 'Maryland'),
(3106, ' ', 'Massachusetts'),
(3107, ' ', 'Michigan'),
(3108, ' ', 'Minnesota'),
(3109, ' ', 'Mississippi'),
(3110, ' ', 'Missouri'),
(3111, ' ', 'Montana'),
(3112, ' ', 'Nebraska'),
(3113, ' ', 'Nevada'),
(3114, ' ', 'New Hampshire'),
(3115, ' ', 'New Jersey'),
(3116, ' ', 'New Mexico'),
(3117, ' ', 'New York'),
(3118, ' ', 'North Carolina'),
(3119, ' ', 'North Dakota'),
(3120, ' ', 'Ohio'),
(3121, ' ', 'Oklahoma'),
(3122, ' ', 'Oregon'),
(3123, ' ', 'Pennsylvania'),
(3124, ' ', 'Rhode Island'),
(3125, ' ', 'South Carolina'),
(3126, ' ', 'South Dakota'),
(3127, ' ', 'Tennessee'),
(3128, ' ', 'Texas'),
(3129, ' ', 'Utah'),
(3130, ' ', 'Vermont'),
(3131, ' ', 'Virginia'),
(3132, ' ', 'Washington'),
(3133, ' ', 'Washington, D.C.'),
(3134, ' ', 'West Virginia'),
(3135, ' ', 'Wisconsin'),
(3136, ' ', 'Wyoming'),
(3137, 'Australia', 'ACT'),
(3138, 'Australia', 'New South Wales'),
(3139, 'Australia', 'Northern Territory'),
(3140, 'Australia', 'Queensland'),
(3141, 'Australia', 'South Australia'),
(3142, 'Australia', 'Tasmania'),
(3143, 'Australia', 'Victoria'),
(3144, 'Australia', 'Western Australia'),
(3145, 'East Timor', 'Aileu'),
(3146, ' ', 'Ainaro'),
(3147, ' ', 'Baucau'),
(3148, ' ', 'Bobonaro'),
(3149, ' ', 'Cova Lima'),
(3150, ' ', 'Díli'),
(3151, ' ', 'Ermera'),
(3152, ' ', 'Lautém'),
(3153, ' ', 'Liquiçá'),
(3154, ' ', 'Manatuto'),
(3155, ' ', 'Manufahi'),
(3156, ' ', 'Oecusse'),
(3157, ' ', 'Viqueque'),
(3158, 'Fiji', 'Central'),
(3159, 'Fiji', 'Eastern'),
(3160, 'Fiji', 'Northern'),
(3161, 'Fiji', 'Rotuma'),
(3162, ' ', 'Western'),
(3163, 'Franch Polynesia', 'Leeward Islands'),
(3164, 'Franch Polynesia', 'Îles Australes'),
(3165, 'Franch Polynesia', 'Îles Marquises'),
(3166, 'Franch Polynesia', 'Îles Tuamotu-Gambier'),
(3167, 'Franch Polynesia', 'Îles du Vent'),
(3168, 'Guam', 'Agana Heights'),
(3169, 'Guam', 'Agat'),
(3170, 'Guam', 'Asan'),
(3171, 'Guam', 'Barrigada'),
(3172, 'Guam', 'Chalan Pago-Ordot'),
(3173, 'Guam', 'Dededo'),
(3174, 'Guam', 'Hagatna'),
(3175, 'Guam', 'Inarajan'),
(3176, 'Guam', 'Mangilao'),
(3177, 'Guam', 'Merizo Municipality'),
(3178, 'Guam', 'Mongmong-Toto-Maite Municipality'),
(3179, 'Guam', 'Piti Municipality'),
(3180, 'Guam', 'Santa Rita Municipality'),
(3181, 'Guam', 'Sinajana Municipality'),
(3182, 'Guam', 'Talofofo Municipality'),
(3183, 'Guam', 'Tamuning'),
(3184, 'Guam', 'Umatac'),
(3185, 'Guam', 'Yigo'),
(3186, 'Guam', 'Yona'),
(3187, 'Jervis Bay', 'Agana Heights'),
(3188, 'Jervis Bay', 'Agat'),
(3189, 'Jervis Bay', 'Asan'),
(3190, 'Jervis Bay', 'Barrigada'),
(3191, 'Jervis Bay', 'Chalan Pago-Ordot'),
(3192, 'Jervis Bay', 'Dededo'),
(3193, 'Jervis Bay', 'Hagatna'),
(3194, 'Jervis Bay', 'Inarajan'),
(3195, 'Jervis Bay', 'Mangilao'),
(3196, 'Jervis Bay', 'Merizo Municipality'),
(3197, 'Jervis Bay', 'Mongmong-Toto-Maite Municipality'),
(3198, 'Jervis Bay', 'Piti Municipality'),
(3199, 'Jervis Bay', 'Santa Rita Municipality'),
(3200, 'Jervis Bay', 'Sinajana Municipality'),
(3201, 'Jervis Bay', 'Talofofo Municipality'),
(3202, 'Jervis Bay', 'Tamuning'),
(3203, 'Jervis Bay', 'Umatac'),
(3204, 'Jervis Bay', 'Yigo'),
(3205, 'Jervis Bay', 'Yona'),
(3206, 'Kiribati', 'Gilbert Islands'),
(3207, 'Kiribati', 'Line Islands'),
(3208, 'Kiribati', 'Phoenix Islands'),
(3209, ' ', 'Ailinginae Atoll'),
(3210, ' ', 'Ailinglaplap Atoll'),
(3211, ' ', 'Ailuk Atoll'),
(3212, ' ', 'Arno Atoll'),
(3213, ' ', 'Aur Atoll'),
(3214, ' ', 'Bikar Atoll'),
(3215, ' ', 'Bikini Atoll'),
(3216, ' ', 'Bokak Atoll'),
(3217, ' ', 'Ebon Atoll'),
(3218, ' ', 'Enewetak Atoll'),
(3219, ' ', 'Erikub Atoll'),
(3220, ' ', 'Jabat Island'),
(3221, ' ', 'Jaluit Atoll'),
(3222, ' ', 'Jemo Island'),
(3223, ' ', 'Kili Island'),
(3224, ' ', 'Kwajalein Atoll'),
(3225, ' ', 'Lae Atoll'),
(3226, ' ', 'Lib Island'),
(3227, ' ', 'Likiep Atoll'),
(3228, ' ', 'Majuro Atoll'),
(3229, ' ', 'Maloelap Atoll'),
(3230, ' ', 'Mejit Island'),
(3231, ' ', 'Mili Atoll'),
(3232, ' ', 'Namdrik Atoll'),
(3233, ' ', 'Namu Atoll'),
(3234, ' ', 'Rongelap Atoll'),
(3235, ' ', 'Rongrik Atoll'),
(3236, ' ', 'Taka Atoll'),
(3237, ' ', 'Ujae Atoll'),
(3238, ' ', 'Ujelang Atoll'),
(3239, ' ', 'Utrik Atoll'),
(3240, ' ', 'Wotho Atoll'),
(3241, ' ', 'Wotje Atoll'),
(3242, 'Misconesia', 'State of Chuuk'),
(3243, 'Misconesia', 'State of Kosrae'),
(3244, 'Misconesia', 'State of Pohnpei'),
(3245, 'Misconesia', 'State of Yap'),
(3246, 'Misconesia', 'Nauru'),
(3247, 'Misconesia', 'Aiwo'),
(3248, 'Misconesia', 'Anabar'),
(3249, 'Misconesia', 'Anetan'),
(3250, 'Misconesia', 'Anibare'),
(3251, 'Misconesia', 'Baiti'),
(3252, 'Misconesia', 'Boe'),
(3253, 'Misconesia', 'Buada'),
(3254, 'Misconesia', 'Denigomodu'),
(3255, 'Misconesia', 'Ewa'),
(3256, 'Misconesia', 'Ijuw'),
(3257, 'Misconesia', 'Meneng'),
(3258, 'Misconesia', 'Nibok'),
(3259, 'Misconesia', 'Uaboe'),
(3260, 'Misconesia', 'Yaren'),
(3261, ' ', 'Loyalty Islands'),
(3262, ' ', 'North Province'),
(3263, ' ', 'South Province'),
(3264, 'New Zealand', 'Auckland'),
(3265, 'New Zealand', 'Bay of Plenty'),
(3266, 'New Zealand', 'Canterbury'),
(3267, 'New Zealand', 'Chatham Islands'),
(3268, 'New Zealand', 'Gisborne'),
(3269, 'New Zealand', 'Manawatu-Wanganui'),
(3270, 'New Zealand', 'Marlborough'),
(3271, 'New Zealand', 'Nelson'),
(3272, 'New Zealand', 'Northland'),
(3273, 'New Zealand', 'Otago'),
(3274, 'New Zealand', 'Southland'),
(3275, 'New Zealand', 'Taranaki'),
(3276, 'New Zealand', 'Tasman'),
(3277, 'New Zealand', 'Waikato'),
(3278, 'New Zealand', 'Wellington'),
(3279, 'New Zealand', 'West Coast'),
(3280, 'Northern Mariana Islands', 'Hatohobei'),
(3281, 'Northern Mariana Islands', 'State of Aimeliik'),
(3282, 'Northern Mariana Islands', 'State of Airai'),
(3283, 'Northern Mariana Islands', 'State of Angaur'),
(3284, 'Northern Mariana Islands', 'State of Kayangel'),
(3285, 'Northern Mariana Islands', 'State of Koror'),
(3286, 'Northern Mariana Islands', 'State of Melekeok'),
(3287, 'Northern Mariana Islands', 'State of Ngaraard'),
(3288, 'Northern Mariana Islands', 'State of Ngarchelong'),
(3289, 'Northern Mariana Islands', 'State of Ngardmau'),
(3290, 'Northern Mariana Islands', 'State of Ngatpang'),
(3291, 'Northern Mariana Islands', 'State of Ngchesar'),
(3292, 'Northern Mariana Islands', 'State of Ngeremlengui'),
(3293, 'Northern Mariana Islands', 'State of Ngiwal'),
(3294, 'Northern Mariana Islands', 'State of Peleliu'),
(3295, 'Northern Mariana Islands', 'State of Sonsorol'),
(3296, 'Papua New Guinea', 'Bougainville'),
(3297, 'Papua New Guinea', 'Central Province'),
(3298, 'Papua New Guinea', 'Chimbu Province'),
(3299, 'Papua New Guinea', 'East New Britain Province'),
(3300, '          East Sepik Province      ', 'Eastern Highlands Province'),
(3301, '          East Sepik Province      ', 'Enga Province'),
(3302, '          East Sepik Province      ', 'Gulf Province'),
(3303, '          East Sepik Province      ', 'Hela'),
(3304, '          East Sepik Province      ', 'Jiwaka'),
(3305, '          East Sepik Province      ', 'Madang Province'),
(3306, '          East Sepik Province      ', 'Manus Province'),
(3307, '          East Sepik Province      ', 'Milne Bay Province'),
(3308, '          East Sepik Province      ', 'Morobe Province'),
(3309, '          East Sepik Province      ', 'National Capital'),
(3310, '          East Sepik Province      ', 'New Ireland'),
(3311, '          East Sepik Province      ', 'Northern Province'),
(3312, '          East Sepik Province      ', 'Southern Highlands Province'),
(3313, '          East Sepik Province      ', 'West New Britain Province'),
(3314, '          East Sepik Province      ', 'West Sepik Province'),
(3315, '          East Sepik Province      ', 'Western Highlands Province'),
(3316, '          East Sepik Province      ', 'Western Province'),
(3317, 'Samoa', 'Aiga-i-le-Tai'),
(3318, 'Samoa', 'Atua'),
(3319, 'Samoa', 'Fa‘asaleleaga'),
(3320, 'Samoa', 'Gagaifomauga'),
(3321, 'Samoa', 'Gaga‘emauga'),
(3322, 'Samoa', 'Palauli'),
(3323, 'Samoa', 'Satupa‘itea'),
(3324, 'Samoa', 'Tuamasaga'),
(3325, 'Samoa', 'Vaisigano'),
(3326, 'Samoa', 'Va‘a-o-Fonoti'),
(3327, 'Solomon Islands', 'Central Province'),
(3328, 'Solomon Islands', 'Choiseul'),
(3329, 'Solomon Islands', 'Guadalcanal Province'),
(3330, 'Solomon Islands', 'Honiara'),
(3331, 'Solomon Islands', 'Isabel Province'),
(3332, 'Solomon Islands', 'Makira-Ulawa Province'),
(3333, 'Solomon Islands', 'Malaita Province'),
(3334, 'Solomon Islands', 'Rennell and Bellona'),
(3335, 'Solomon Islands', 'Temotu Province'),
(3336, 'Solomon Islands', 'Western Province'),
(3337, 'Tokelau', 'Atafu'),
(3338, 'Tokelau', 'Fakaofo'),
(3339, 'Tokelau', 'Nukunonu'),
(3340, 'Tonga', 'Ha‘apai'),
(3341, 'Tonga', 'Niuas'),
(3342, 'Tonga', 'Tongatapu'),
(3343, 'Tonga', 'Vava‘u'),
(3344, 'Tonga', '?Eua'),
(3345, 'Tuvalu', 'Funafuti'),
(3346, 'Tuvalu', 'Nanumanga'),
(3347, 'Tuvalu', 'Nanumea'),
(3348, 'Tuvalu', 'Niutao'),
(3349, 'Tuvalu', 'Nui'),
(3350, 'Tuvalu', 'Nukufetau'),
(3351, 'Tuvalu', 'Nukulaelae'),
(3352, 'Tuvalu', 'Vaitupu'),
(3353, 'Vanuatu', 'Malampa Province'),
(3354, 'Vanuatu', 'Penama Province'),
(3355, 'Vanuatu', 'Sanma Province'),
(3356, 'Vanuatu', 'Shefa Province'),
(3357, 'Vanuatu', 'Tafea Province'),
(3358, 'Vanuatu', 'Torba Province'),
(3359, 'Wallis and Futuna', 'Alo'),
(3360, 'Wallis and Futuna', 'Sigave'),
(3361, 'Wallis and Futuna', 'Uvéa'),
(3362, 'Argentina', 'Buenos Aires'),
(3363, 'Argentina', 'Buenos Aires F.D.'),
(3364, 'Argentina', 'Catamarca'),
(3365, 'Argentina', 'Chaco'),
(3366, 'Argentina', 'Chubut'),
(3367, 'Argentina', 'Cordoba'),
(3368, 'Argentina', 'Corrientes'),
(3369, 'Argentina', 'Entre Rios'),
(3370, 'Argentina', 'Formosa'),
(3371, 'Argentina', 'Jujuy'),
(3372, 'Argentina', 'La Pampa'),
(3373, 'Argentina', 'La Rioja'),
(3374, 'Argentina', 'Mendoza'),
(3375, 'Argentina', 'Misiones'),
(3376, 'Argentina', 'Neuquen'),
(3377, 'Argentina', 'Rio Negro'),
(3378, 'Argentina', 'Salta'),
(3379, 'Argentina', 'San Juan'),
(3380, 'Argentina', 'San Luis'),
(3381, 'Argentina', 'Santa Cruz'),
(3382, 'Argentina', 'Santa Fe'),
(3383, 'Argentina', 'Santiago del Estero'),
(3384, 'Argentina', 'Tierra del Fuego'),
(3385, 'Argentina', 'Tucuman'),
(3386, 'Bolivia', 'Departamento de Chuquisaca'),
(3387, 'Bolivia', 'Departamento de Cochabamba'),
(3388, 'Bolivia', 'Departamento de La Paz'),
(3389, 'Bolivia', 'Departamento de Pando'),
(3390, 'Bolivia', 'Departamento de Potosí'),
(3391, 'Bolivia', 'Departamento de Santa Cruz'),
(3392, 'Bolivia', 'Departamento de Tarija'),
(3393, 'Bolivia', 'El Beni'),
(3394, 'Bolivia', 'Oruro'),
(3395, 'Brazil', 'Acre'),
(3396, 'Brazil', 'Alagoas'),
(3397, 'Brazil', 'Amapá'),
(3398, 'Brazil', 'Amazonas'),
(3399, 'Brazil', 'Bahia'),
(3400, 'Brazil', 'Ceará'),
(3401, 'Brazil', 'Espírito Santo'),
(3402, 'Brazil', 'Federal District'),
(3403, 'Brazil', 'Goiás'),
(3404, 'Brazil', 'Maranhão'),
(3405, 'Brazil', 'Mato Grosso'),
(3406, 'Brazil', 'Mato Grosso do Sul'),
(3407, 'Brazil', 'Minas Gerais'),
(3408, 'Brazil', 'Paraná'),
(3409, 'Brazil', 'Paraíba'),
(3410, 'Brazil', 'Pará'),
(3411, 'Brazil', 'Pernambuco'),
(3412, 'Brazil', 'Piauí'),
(3413, 'Brazil', 'Rio Grande do Norte'),
(3414, 'Brazil', 'Rio Grande do Sul'),
(3415, 'Brazil', 'Rio de Janeiro'),
(3416, 'Brazil', 'Rondônia'),
(3417, 'Brazil', 'Roraima'),
(3418, 'Brazil', 'Santa Catarina'),
(3419, 'Brazil', 'Sergipe'),
(3420, 'Brazil', 'São Paulo'),
(3421, 'Brazil', 'Tocantins'),
(3422, 'Chile', 'Antofagasta'),
(3423, 'Chile', 'Atacama'),
(3424, 'Chile', 'Aysén'),
(3425, 'Chile', 'Coquimbo'),
(3426, 'Chile', 'Los Lagos'),
(3427, 'Chile', 'Maule'),
(3428, 'Chile', 'Región de Arica y Parinacota'),
(3429, 'Chile', 'Región de Los Ríos'),
(3430, 'Chile', 'Región de Magallanes y de la Antártica Chilena'),
(3431, 'Chile', 'Región de Valparaíso'),
(3432, 'Chile', 'Región de la Araucanía'),
(3433, 'Chile', 'Región del Biobío'),
(3434, 'Chile', 'Región del Libertador General Bernardo O’Higgins'),
(3435, 'Chile', 'Santiago Metropolitan'),
(3436, 'Chile', 'Tarapacá'),
(3437, 'Colombia', 'Amazonas'),
(3438, 'Colombia', 'Antioquia'),
(3439, 'Colombia', 'Atlántico'),
(3440, 'Colombia', 'Bogota D.C.'),
(3441, 'Colombia', 'Cundinamarca'),
(3442, 'Colombia', 'Departamento de Arauca'),
(3443, 'Colombia', 'Departamento de Bolívar'),
(3444, 'Colombia', 'Departamento de Boyacá'),
(3445, 'Colombia', 'Departamento de Caldas'),
(3446, 'Colombia', 'Departamento de Casanare'),
(3447, 'Colombia', 'Departamento de Córdoba'),
(3448, 'Colombia', 'Departamento de La Guajira'),
(3449, 'Colombia', 'Departamento de Nariño'),
(3450, 'Colombia', 'Departamento de Norte de Santander'),
(3451, 'Colombia', 'Departamento de Risaralda'),
(3452, 'Colombia', 'Departamento de Santander'),
(3453, 'Colombia', 'Departamento de Sucre'),
(3454, 'Colombia', 'Departamento de Tolima'),
(3455, 'Colombia', 'Departamento del Caquetá'),
(3456, 'Colombia', 'Departamento del Cauca'),
(3457, 'Colombia', 'Departamento del Cesar'),
(3458, 'Colombia', 'Departamento del Chocó'),
(3459, 'Colombia', 'Departamento del Guainía'),
(3460, 'Colombia', 'Departamento del Guaviare'),
(3461, 'Colombia', 'Departamento del Huila'),
(3462, 'Colombia', 'Departamento del Magdalena'),
(3463, 'Colombia', 'Departamento del Meta'),
(3464, 'Colombia', 'Departamento del Putumayo'),
(3465, 'Colombia', 'Departamento del Valle del Cauca'),
(3466, 'Colombia', 'Departamento del Vaupés'),
(3467, 'Colombia', 'Departamento del Vichada'),
(3468, 'Colombia', 'Quindío Department'),
(3469, 'Colombia', 'San Andres y Providencia'),
(3470, 'Ecuador', 'Provincia de Bolívar'),
(3471, 'Ecuador', 'Provincia de Cotopaxi'),
(3472, 'Ecuador', 'Provincia de El Oro'),
(3473, 'Ecuador', 'Provincia de Esmeraldas'),
(3474, 'Ecuador', 'Provincia de Francisco de Orellana'),
(3475, 'Ecuador', 'Provincia de Galápagos'),
(3476, 'Ecuador', 'Provincia de Imbabura'),
(3477, 'Ecuador', 'Provincia de Loja'),
(3478, 'Ecuador', 'Provincia de Los Ríos'),
(3479, 'Ecuador', 'Provincia de Manabí'),
(3480, 'Ecuador', 'Provincia de Morona-Santiago'),
(3481, 'Ecuador', 'Provincia de Napo'),
(3482, 'Ecuador', 'Provincia de Pichincha'),
(3483, 'Ecuador', 'Provincia de Santa Elena'),
(3484, 'Ecuador', 'Provincia de Santo Domingo de los Tsáchilas'),
(3485, 'Ecuador', 'Provincia de Sucumbíos'),
(3486, 'Ecuador', 'Provincia de Zamora-Chinchipe'),
(3487, 'Ecuador', 'Provincia del Azuay'),
(3488, 'Ecuador', 'Provincia del Carchi'),
(3489, 'Ecuador', 'Provincia del Cañar'),
(3490, 'Ecuador', 'Provincia del Chimborazo'),
(3491, 'Ecuador', 'Provincia del Guayas'),
(3492, 'Ecuador', 'Provincia del Pastaza'),
(3493, 'Ecuador', 'Provincia del Tungurahua'),
(3494, 'Guyana', 'Barima-Waini Region'),
(3495, 'Guyana', 'Cuyuni-Mazaruni Region'),
(3496, 'Guyana', 'Demerara-Mahaica Region'),
(3497, 'Guyana', 'East Berbice-Corentyne Region'),
(3498, 'Guyana', 'Essequibo Islands-West Demerara Region'),
(3499, 'Guyana', 'Mahaica-Berbice Region'),
(3500, 'Guyana', 'Pomeroon-Supenaam Region'),
(3501, 'Guyana', 'Potaro-Siparuni Region'),
(3502, 'Guyana', 'Upper Demerara-Berbice Region'),
(3503, 'Guyana', 'Upper Takutu-Upper Essequibo Region'),
(3504, 'Paraguay', 'Asunción'),
(3505, 'Paraguay', 'Departamento Central'),
(3506, 'Paraguay', 'Departamento de Alto Paraguay'),
(3507, 'Paraguay', 'Departamento de Boquerón'),
(3508, 'Paraguay', 'Departamento de Caaguazú'),
(3509, 'Paraguay', 'Departamento de Caazapá'),
(3510, 'Paraguay', 'Departamento de Canindeyú'),
(3511, 'Paraguay', 'Departamento de Concepción'),
(3512, 'Paraguay', 'Departamento de Itapúa'),
(3513, 'Paraguay', 'Departamento de Misiones'),
(3514, 'Paraguay', 'Departamento de Paraguarí'),
(3515, 'Paraguay', 'Departamento de Presidente Hayes'),
(3516, 'Paraguay', 'Departamento de San Pedro'),
(3517, 'Paraguay', 'Departamento de la Cordillera'),
(3518, 'Paraguay', 'Departamento de Ñeembucú'),
(3519, 'Paraguay', 'Departamento del Alto Paraná'),
(3520, 'Paraguay', 'Departamento del Amambay'),
(3521, 'Paraguay', 'Departamento del Guairá'),
(3522, 'Peru', 'Amazonas'),
(3523, 'Peru', 'Ancash'),
(3524, 'Peru', 'Apurimac'),
(3525, 'Peru', 'Arequipa'),
(3526, 'Peru', 'Ayacucho'),
(3527, 'Peru', 'Cajamarca'),
(3528, 'Peru', 'Callao'),
(3529, 'Peru', 'Cusco'),
(3530, 'Peru', 'Departamento de Moquegua'),
(3531, 'Peru', 'Huancavelica'),
(3532, 'Peru', 'Ica'),
(3533, 'Peru', 'Junin'),
(3534, 'Peru', 'La Libertad'),
(3535, 'Peru', 'Lambayeque'),
(3536, 'Peru', 'Lima'),
(3537, 'Peru', 'Lima region'),
(3538, 'Peru', 'Loreto'),
(3539, 'Peru', 'Madre de Dios'),
(3540, 'Peru', 'Pasco'),
(3541, 'Peru', 'Piura'),
(3542, 'Peru', 'Puno'),
(3543, 'Peru', 'Región de Huánuco'),
(3544, 'Peru', 'Región de San Martín'),
(3545, 'Peru', 'Tacna'),
(3546, 'Peru', 'Tumbes'),
(3547, 'Peru', 'Ucayali'),
(3548, 'Suriname', 'Distrikt Brokopondo'),
(3549, 'Suriname', 'Distrikt Commewijne'),
(3550, 'Suriname', 'Distrikt Coronie'),
(3551, 'Suriname', 'Distrikt Marowijne'),
(3552, 'Suriname', 'Distrikt Nickerie'),
(3553, 'Suriname', 'Distrikt Para'),
(3554, 'Suriname', 'Distrikt Paramaribo'),
(3555, 'Suriname', 'Distrikt Saramacca'),
(3556, 'Suriname', 'Distrikt Sipaliwini'),
(3557, 'Suriname', 'Distrikt Wanica'),
(3558, 'Uruguay', 'Artigas'),
(3559, 'Uruguay', 'Canelones'),
(3560, 'Uruguay', 'Cerro Largo'),
(3561, 'Uruguay', 'Colonia'),
(3562, 'Uruguay', 'Departamento de Durazno'),
(3563, 'Uruguay', 'Departamento de Flores'),
(3564, 'Uruguay', 'Departamento de Montevideo'),
(3565, 'Uruguay', 'Departamento de Paysandú'),
(3566, 'Uruguay', 'Departamento de Rivera'),
(3567, 'Uruguay', 'Departamento de Rocha'),
(3568, 'Uruguay', 'Departamento de Río Negro'),
(3569, 'Uruguay', 'Departamento de Salto'),
(3570, 'Uruguay', 'Departamento de San José'),
(3571, 'Uruguay', 'Departamento de Tacuarembó'),
(3572, 'Uruguay', 'Departamento de Treinta y Tres'),
(3573, 'Uruguay', 'Florida'),
(3574, 'Uruguay', 'Lavalleja'),
(3575, 'Uruguay', 'Maldonado'),
(3576, 'Uruguay', 'Soriano'),
(3577, 'Venezuela', 'Amazonas'),
(3578, 'Venezuela', 'Anzoátegui'),
(3579, 'Venezuela', 'Apure'),
(3580, 'Venezuela', 'Aragua'),
(3581, 'Venezuela', 'Barinas'),
(3582, 'Venezuela', 'Bolívar'),
(3583, 'Venezuela', 'Capital'),
(3584, 'Venezuela', 'Carabobo'),
(3585, 'Venezuela', 'Cojedes'),
(3586, 'Venezuela', 'Delta Amacuro'),
(3587, 'Venezuela', 'Dependencias'),
(3588, 'Venezuela', 'Federales'),
(3589, 'Venezuela', 'Falcón'),
(3590, 'Venezuela', 'Guárico'),
(3591, 'Venezuela', 'Lara'),
(3592, 'Venezuela', 'Miranda'),
(3593, 'Venezuela', 'Monagas'),
(3594, 'Venezuela', 'Mérida'),
(3595, 'Venezuela', 'Nueva Esparta'),
(3596, 'Venezuela', 'Portuguesa'),
(3597, 'Venezuela', 'Sucre'),
(3598, 'Venezuela', 'Trujillo'),
(3599, 'Venezuela', 'Táchira'),
(3600, 'Venezuela', 'Vargas'),
(3601, 'Venezuela', 'Yaracuy'),
(3602, 'Venezuela', 'Zulia');

-- --------------------------------------------------------

--
-- Table structure for table `credit_note_master`
--

CREATE TABLE IF NOT EXISTS `credit_note_master` (
  `id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `module_name` varchar(300) NOT NULL,
  `module_entry_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cruise_master`
--

CREATE TABLE IF NOT EXISTS `cruise_master` (
  `cruise_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `mobile_no` varchar(320) NOT NULL,
  `landline_no` varchar(100) NOT NULL,
  `email_id` varchar(150) NOT NULL,
  `contact_person_name` varchar(300) NOT NULL,
  `immergency_contact_no` varchar(300) NOT NULL,
  `cruise_address` text NOT NULL,
  `country` varchar(150) NOT NULL,
  `website` varchar(300) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`cruise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `currency_name_master`
--

CREATE TABLE IF NOT EXISTS `currency_name_master` (
  `id` int(50) NOT NULL,
  `currency_code` varchar(200) NOT NULL,
  `currency_name` varchar(200) NOT NULL,
  `country_name` varchar(200) NOT NULL,
  `default_currency` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currency_name_master`
--

INSERT INTO `currency_name_master` (`id`, `currency_code`, `currency_name`, `country_name`, `default_currency`) VALUES
(1, 'AED', 'United Arab Emirates dirham', 'United Arab Emirates', 0),
(2, 'AFN', 'Afghani', 'Afghanistan', 0),
(3, 'ALL', 'Lek', 'Albania', 0),
(4, 'AMD', 'Armenian Dram', 'Armenia', 0),
(5, 'ANG', 'Netherlands Antillian Guilder', 'Netherlands Antilles', 0),
(6, 'AOA', 'Kwanza', 'Angola', 0),
(7, 'ARS', 'Argentine Peso', 'Argentina', 0),
(8, 'AUD', 'Australian Dollar', 'Australia, Australian Antarctic Territory, Christmas Island, Cocos (Keeling) Islands, Heard and McDonald Islands, Kiribati, Nauru, Norfolk Island, Tuvalu', 0),
(9, 'AWG', 'Aruban Guilder', 'Aruba', 0),
(10, 'AZN', 'Azerbaijanian Manat', 'Azerbaijan', 0),
(11, 'BAM', 'Convertible Marks', 'Bosnia and Herzegovina', 0),
(12, 'BBD', 'Barbados Dollar', 'Barbados', 0),
(13, 'BDT', 'Bangladeshi Taka', 'Bangladesh', 0),
(14, 'BGN', 'Bulgarian Lev', 'Bulgaria', 0),
(15, 'BHD', 'Bahraini Dinar', 'Bahrain', 0),
(16, 'BIF', 'Burundian Franc', 'Burundi', 0),
(17, 'BMD', 'Bermudian Dollar (customarily known as Bermuda Dollar)', 'Bermuda', 0),
(18, 'BND', 'Brunei Dollar', 'Brunei', 0),
(19, 'BOB', 'Boliviano', 'Bolivia', 0),
(20, 'BOV', 'Bolivian Mvdol (Funds code)', 'Bolivia', 0),
(21, 'BRL', 'Brazilian Real', 'Brazil', 0),
(22, 'BSD', 'Bahamian Dollar', 'Bahamas', 0),
(23, 'BTN', 'Ngultrum', 'Bhutan', 0),
(24, 'BWP', 'Pula', 'Botswana', 0),
(25, 'BYR', 'Belarussian Ruble', 'Belarus', 0),
(26, 'BZD', 'Belize Dollar', 'Belize', 0),
(27, 'CAD', 'Canadian Dollar', 'Canada', 0),
(28, 'CDF', 'Franc Congolais', 'Democratic Republic of Congo', 0),
(29, 'CHE', 'WIR Euro (complementary currency)', 'Switzerland', 0),
(30, 'CHF', 'Swiss Franc', 'Switzerland, Liechtenstein', 0),
(31, 'CHW', 'WIR Franc (complementary currency)', 'Switzerland', 0),
(32, 'CLF', 'Unidades de formento (Funds code)', 'Chile', 0),
(33, 'CLP', 'Chilean Peso', 'Chile', 0),
(34, 'CNY', 'Yuan Renminbi', 'Mainland China', 0),
(35, 'COP', 'Colombian Peso', 'Colombia', 0),
(36, 'COU', 'Unidad de Valor Real', 'Colombia', 0),
(37, 'CRC', 'Costa Rican Colon', 'Costa Rica', 0),
(38, 'CUP', 'Cuban Peso', 'Cuba', 0),
(39, 'CVE', 'Cape Verde Escudo', 'Cape Verde', 0),
(40, 'CYP', 'Cyprus Pound', 'Cyprus', 0),
(41, 'CZK', 'Czech Koruna', 'Czech Republic', 0),
(42, 'DJF', 'Djibouti Franc', 'Djibouti', 0),
(43, 'DKK', 'Danish Krone', 'Denmark, Faroe Islands, Greenland', 0),
(44, 'DOP', 'Dominican Peso', 'Dominican Republic', 0),
(45, 'DZD', 'Algerian Dinar', 'Algeria', 0),
(46, 'EEK', 'Kroon', 'Estonia', 0),
(47, 'EGP', 'Egyptian Pound', 'Egypt', 0),
(48, 'ERN', 'Nakfa', 'Eritrea', 0),
(49, 'ETB', 'Ethiopian Birr', 'Ethiopia', 0),
(50, 'EUR', 'Euro', 'European Union, see eurozone', 0),
(51, 'FJD', 'Fiji Dollar', 'Fiji', 0),
(52, 'FKP', 'Falkland Islands Pound', 'Falkland Islands', 0),
(53, 'GBP', 'Pound Sterling', 'United Kingdom', 0),
(54, 'GEL', 'Lari', 'Georgia', 0),
(55, 'GHS', 'Cedi', 'Ghana', 0),
(56, 'GIP', 'Gibraltar pound', 'Gibraltar', 0),
(57, 'GMD', 'Dalasi', 'Gambia', 0),
(58, 'GNF', 'Guinea Franc', 'Guinea', 0),
(59, 'GTQ', 'Quetzal', 'Guatemala', 0),
(60, 'GYD', 'Guyana Dollar', 'Guyana', 0),
(61, 'HKD', 'Hong Kong Dollar', 'Hong Kong Special Administrative Region', 0),
(62, 'HNL', 'Lempira', 'Honduras', 0),
(63, 'HRK', 'Croatian Kuna', 'Croatia', 0),
(64, 'HTG', 'Haiti Gourde', 'Haiti', 0),
(65, 'HUF', 'Forint', 'Hungary', 0),
(66, 'IDR', 'Rupiah', 'Indonesia', 0),
(67, 'ILS', 'New Israeli Shekel', 'Israel', 0),
(68, 'INR', 'Indian Rupee', 'Bhutan, India', 1),
(69, 'IQD', 'Iraqi Dinar', 'Iraq', 0),
(70, 'IRR', 'Iranian Rial', 'Iran', 0),
(71, 'ISK', 'Iceland Krona', 'Iceland', 0),
(72, 'JMD', 'Jamaican Dollar', 'Jamaica', 0),
(73, 'JOD', 'Jordanian Dinar', 'Jordan', 0),
(74, 'JPY', 'Japanese yen', 'Japan', 0),
(75, 'KES', 'Kenyan Shilling', 'Kenya', 0),
(76, 'KGS', 'Som', 'Kyrgyzstan', 0),
(77, 'KHR', 'Riel', 'Cambodia', 0),
(78, 'KMF', 'Comoro Franc', 'Comoros', 0),
(79, 'KPW', 'North Korean Won', 'North Korea', 0),
(80, 'KRW', 'South Korean Won', 'South Korea', 0),
(81, 'KWD', 'Kuwaiti Dinar', 'Kuwait', 0),
(82, 'KYD', 'Cayman Islands Dollar', 'Cayman Islands', 0),
(83, 'KZT', 'Tenge', 'Kazakhstan', 0),
(84, 'LAK', 'Kip', 'Laos', 0),
(85, 'LBP', 'Lebanese Pound', 'Lebanon', 0),
(86, 'LKR', 'Sri Lanka Rupee', 'Sri Lanka', 0),
(87, 'LRD', 'Liberian Dollar', 'Liberia', 0),
(88, 'LSL', 'Loti', 'Lesotho', 0),
(89, 'LTL', 'Lithuanian Litas', 'Lithuania', 0),
(90, 'LVL', 'Latvian Lats', 'Latvia', 0),
(91, 'LYD', 'Libyan Dinar', 'Libya', 0),
(92, 'MAD', 'Moroccan Dirham', 'Morocco, Western Sahara', 0),
(93, 'MDL', 'Moldovan Leu', 'Moldova', 0),
(94, 'MGA', 'Malagasy Ariary', 'Madagascar', 0),
(95, 'MKD', 'Denar', 'Former Yugoslav Republic of Macedonia', 0),
(96, 'MMK', 'Kyat', 'Myanmar', 0),
(97, 'MNT', 'Tugrik', 'Mongolia', 0),
(98, 'MOP', 'Pataca', 'Macau Special Administrative Region', 0),
(99, 'MRO', 'Ouguiya', 'Mauritania', 0),
(100, 'MTL', 'Maltese Lira', 'Malta', 0),
(101, 'MUR', 'Mauritius Rupee', 'Mauritius', 0),
(102, 'MVR', 'Rufiyaa', 'Maldives', 0),
(103, 'MWK', 'Kwacha', 'Malawi', 0),
(104, 'MXN', 'Mexican Peso', 'Mexico', 0),
(105, 'MXV', 'Mexican Unidad de Inversion (UDI) (Funds code)', 'Mexico', 0),
(106, 'MYR', 'Malaysian Ringgit', 'Malaysia', 0),
(107, 'MZN', 'Metical', 'Mozambique', 0),
(108, 'NAD', 'Namibian Dollar', 'Namibia', 0),
(109, 'NGN', 'Naira', 'Nigeria', 0),
(110, 'NIO', 'Cordoba Oro', 'Nicaragua', 0),
(111, 'NOK', 'Norwegian Krone', 'Norway', 0),
(112, 'NPR', 'Nepalese Rupee', 'Nepal', 0),
(113, 'NZD', 'New Zealand Dollar', 'Cook Islands, New Zealand, Niue, Pitcairn, Tokelau', 0),
(114, 'OMR', 'Rial Omani', 'Oman', 0),
(115, 'PAB', 'Balboa', 'Panama', 0),
(116, 'PEN', 'Nuevo Sol', 'Peru', 0),
(117, 'PGK', 'Kina', 'Papua New Guinea', 0),
(118, 'PHP', 'Philippine Peso', 'Philippines', 0),
(119, 'PKR', 'Pakistan Rupee', 'Pakistan', 0),
(120, 'PLN', 'Zloty', 'Poland', 0),
(121, 'PYG', 'Guarani', 'Paraguay', 0),
(122, 'QAR', 'Qatari Rial', 'Qatar', 0),
(123, 'RON', 'Romanian New Leu', 'Romania', 0),
(124, 'RSD', 'Serbian Dinar', 'Serbia', 0),
(125, 'RUB', 'Russian Ruble', 'Russia, Abkhazia, South Ossetia', 0),
(126, 'RWF', 'Rwanda Franc', 'Rwanda', 0),
(127, 'SAR', 'Saudi Riyal', 'Saudi Arabia', 0),
(128, 'SBD', 'Solomon Islands Dollar', 'Solomon Islands', 0),
(129, 'SCR', 'Seychelles Rupee', 'Seychelles', 0),
(130, 'SDG', 'Sudanese Pound', 'Sudan', 0),
(131, 'SEK', 'Swedish Krona', 'Sweden', 0),
(132, 'SGD', 'Singapore Dollar', 'Singapore', 0),
(133, 'SHP', 'Saint Helena Pound', 'Saint Helena', 0),
(134, 'SKK', 'Slovak Koruna', 'Slovakia', 0),
(135, 'SLL', 'Leone', 'Sierra Leone', 0),
(136, 'SOS', 'Somali Shilling', 'Somalia', 0),
(137, 'SRD', 'Surinam Dollar', 'Suriname', 0),
(138, 'STD', 'Dobra', 'S?o Tom? and Pr?ncipe', 0),
(139, 'SYP', 'Syrian Pound', 'Syria', 0),
(140, 'SZL', 'Lilangeni', 'Swaziland', 0),
(141, 'THB', 'Baht', 'Thailand', 0),
(142, 'TJS', 'Somoni', 'Tajikistan', 0),
(143, 'TMM', 'Manat', 'Turkmenistan', 0),
(144, 'TND', 'Tunisian Dinar', 'Tunisia', 0),
(145, 'TOP', 'Pa''anga', 'Tonga', 0),
(146, 'TRY', 'New Turkish Lira', 'Turkey', 0),
(147, 'TTD', 'Trinidad and Tobago Dollar', 'Trinidad and Tobago', 0),
(148, 'TWD', 'New Taiwan Dollar', 'Taiwan and other islands that are under the effective control of the Republic of China (ROC)', 0),
(149, 'TZS', 'Tanzanian Shilling', 'Tanzania', 0),
(150, 'UAH', 'Hryvnia', 'Ukraine', 0),
(151, 'UGX', 'Uganda Shilling', 'Uganda', 0),
(152, 'USD', 'US Dollar', 'American Samoa, British Indian Ocean Territory, Ecuador, El Salvador, Guam, Haiti, Marshall Islands, Micronesia, Northern Mariana Islands, Palau, Panama, Puerto Rico, East Timor, Turks and Caicos Isla', 0),
(153, 'USN', '', 'United States', 0),
(154, 'USS', '', 'United States', 0),
(155, 'UYU', 'Peso Uruguayo', 'Uruguay', 0),
(156, 'UZS', 'Uzbekistan Som', 'Uzbekistan', 0),
(157, 'VEB', 'Venezuelan bol?var', 'Venezuela', 0),
(158, 'VND', 'Vietnamese ??ng', 'Vietnam', 0),
(159, 'VUV', 'Vatu', 'Vanuatu', 0),
(160, 'WST', 'Samoan Tala', 'Samoa', 0),
(161, 'XAF', 'CFA Franc BEAC', 'Cameroon, Central African Republic, Congo, Chad, Equatorial Guinea, Gabon', 0),
(162, 'XAG', 'Silver (one Troy ounce)', '', 0),
(163, 'XAU', 'Gold (one Troy ounce)', '', 0),
(164, 'XBA', 'European Composite Unit (EURCO) (Bonds market unit)', '', 0),
(165, 'XBB', 'European Monetary Unit (E.M.U.-6) (Bonds market unit)', '', 0),
(166, 'XBC', 'European Unit of Account 9 (E.U.A.-9) (Bonds market unit)', '', 0),
(167, 'XBD', 'European Unit of Account 17 (E.U.A.-17) (Bonds market unit)', '', 0),
(168, 'XCD', 'East Caribbean Dollar', 'Anguilla, Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines', 0),
(169, 'XDR', 'Special Drawing Rights', 'International Monetary Fund', 0),
(170, 'XFO', 'Gold franc (special settlement currency)', 'Bank for International Settlements', 0),
(171, 'XFU', 'UIC franc (special settlement currency)', 'International Union of Railways', 0),
(172, 'XOF', 'CFA Franc BCEAO', 'Benin, Burkina Faso, C?te d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo', 0),
(173, 'XPD', 'Palladium (one Troy ounce)', '', 0),
(174, 'XPF', 'CFP franc', 'French Polynesia, New Caledonia, Wallis and Futuna', 0),
(175, 'XPT', 'Platinum (one Troy ounce)', '', 0),
(176, 'XTS', 'Code reserved for testing purposes', '', 0),
(177, 'XXX', 'No currency', '', 0),
(178, 'YER', 'Yemeni Rial', 'Yemen', 0),
(179, 'ZAR', 'South African Rand', 'South Africa', 0),
(180, 'ZMK', 'Kwacha', 'Zambia', 0),
(181, 'ZWD', 'Zimbabwe Dollar', 'Zimbabwe', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_enquiry_master`
--

CREATE TABLE IF NOT EXISTS `customer_enquiry_master` (
  `enquiry_id` int(100) NOT NULL,
  `customer_id` int(100) NOT NULL,
  `service_name` varchar(300) NOT NULL,
  `enquiry_specification` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`enquiry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_feedback_master`
--

CREATE TABLE IF NOT EXISTS `customer_feedback_master` (
  `feedback_id` int(50) NOT NULL,
  `booking_type` varchar(200) NOT NULL,
  `booking_id` int(200) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `sales_team` varchar(200) NOT NULL,
  `travel_agencies` varchar(200) NOT NULL,
  `vehicles_requested` varchar(200) NOT NULL,
  `pickup_time` varchar(200) NOT NULL,
  `vehicles_condition` varchar(200) NOT NULL,
  `driver_info` varchar(200) NOT NULL,
  `ticket_info` varchar(200) NOT NULL,
  `hotel_request` varchar(200) NOT NULL,
  `hotel_clean` varchar(200) NOT NULL,
  `hotel_quality` varchar(200) NOT NULL,
  `siteseen` varchar(200) NOT NULL,
  `siteseen_time` varchar(200) NOT NULL,
  `tour_guide` varchar(200) NOT NULL,
  `booking_experience` varchar(200) NOT NULL,
  `travel_again` varchar(200) NOT NULL,
  `hotel_recommend` varchar(200) NOT NULL,
  `quality_service` varchar(200) NOT NULL,
  `trip_overall` varchar(200) NOT NULL,
  `add_comment` varchar(200) NOT NULL,
  `sales_team_comment` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE IF NOT EXISTS `customer_master` (
  `customer_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `type` varchar(250) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `age` varchar(100) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `landline_no` varchar(150) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `alt_email` varchar(150) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `address2` varchar(300) NOT NULL,
  `city` varchar(300) NOT NULL,
  `gl_id` int(50) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `state_id` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custom_package_hotels`
--

CREATE TABLE IF NOT EXISTS `custom_package_hotels` (
  `entry_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `hotel_name` varchar(100) NOT NULL,
  `hotel_type` varchar(100) NOT NULL,
  `total_days` int(11) NOT NULL,
  `image_url` varchar(200) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custom_package_images`
--

CREATE TABLE IF NOT EXISTS `custom_package_images` (
  `image_entry_id` int(11) NOT NULL,
  `image_url` varchar(200) NOT NULL,
  `package_id` int(11) NOT NULL,
  PRIMARY KEY (`image_entry_id`),
  KEY `image_entry_id` (`image_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custom_package_master`
--

CREATE TABLE IF NOT EXISTS `custom_package_master` (
  `package_id` int(11) NOT NULL,
  `dest_id` int(11) NOT NULL,
  `package_code` varchar(100) NOT NULL,
  `package_name` varchar(150) NOT NULL,
  `total_days` int(150) NOT NULL,
  `total_nights` int(100) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_cost` decimal(50,2) NOT NULL,
  `infant_cost` decimal(50,2) NOT NULL,
  `child_with` decimal(50,2) NOT NULL,
  `child_without` decimal(50,2) NOT NULL,
  `extra_bed` decimal(50,2) NOT NULL,
  `tour_cost` decimal(50,2) NOT NULL,
  `markup_cost` decimal(50,2) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_tour_cost` decimal(50,2) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `clone` varchar(20) NOT NULL,
  `tour_type` varchar(20) NOT NULL,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custom_package_program`
--

CREATE TABLE IF NOT EXISTS `custom_package_program` (
  `entry_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `attraction` varchar(150) NOT NULL,
  `day_wise_program` varchar(2000) NOT NULL,
  `stay` varchar(80) NOT NULL,
  `meal_plan` varchar(10) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `custom_package_transport`
--

CREATE TABLE IF NOT EXISTS `custom_package_transport` (
  `entry_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `vehicle_name` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `daily_activity`
--

CREATE TABLE IF NOT EXISTS `daily_activity` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `activity_date` date NOT NULL,
  `activity_type` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `time_taken` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `debit_note_master`
--

CREATE TABLE IF NOT EXISTS `debit_note_master` (
  `id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `estimate_id` int(11) NOT NULL,
  `vendor_type` varchar(300) NOT NULL,
  `vendor_type_id` int(11) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `destination_master`
--

CREATE TABLE IF NOT EXISTS `destination_master` (
  `dest_id` int(11) NOT NULL,
  `dest_name` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`dest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destination_master`
--

INSERT INTO `destination_master` (`dest_id`, `dest_name`, `status`) VALUES
(1, 'Andaman And Nicobar Islands', 'Active'),
(2, 'Andhra Pradesh', 'Active'),
(3, 'Assam', 'Active'),
(4, 'Goa', 'Active'),
(5, 'Gujarat', 'Active'),
(6, 'Himachal Pradesh', 'Active'),
(7, 'Jammu and Kashmir', 'Active'),
(8, 'Karnataka', 'Active'),
(9, 'Kerala', 'Active'),
(10, 'Madhya Pradesh', 'Active'),
(11, 'Maharashtra', 'Active'),
(12, 'Puducherry', 'Active'),
(13, 'Rajasthan', 'Active'),
(14, 'Sikkim', 'Active'),
(15, 'Tamil Nadu', 'Active'),
(16, 'Uttar Pradesh', 'Active'),
(17, 'Uttarakhand', 'Active'),
(18, 'West Bengal', 'Active'),
(19, 'Bangkok', 'Active'),
(20, 'China', 'Active'),
(21, 'Combodia', 'Active'),
(22, 'Hongkong', 'Active'),
(23, 'Indonesia', 'Active'),
(24, 'Iran', 'Active'),
(25, 'Japan', 'Active'),
(26, 'Kuwait', 'Active'),
(27, 'Malaysia', 'Active'),
(28, 'Maldives', 'Active'),
(29, 'Myanmar Burma', 'Active'),
(30, 'Nepal', 'Active'),
(31, 'Phuket', 'Active'),
(32, 'Qatar', 'Active'),
(33, 'Saudi Arabia', 'Active'),
(34, 'Singapore', 'Active'),
(35, 'Sri Lanka', 'Active'),
(36, 'Taiwan', 'Active'),
(37, 'Thailand', 'Active'),
(38, 'Turkey', 'Active'),
(39, 'UAE', 'Active'),
(40, 'Bhutan', 'Active'),
(41, 'Hyderabad', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `dmc_master`
--

CREATE TABLE IF NOT EXISTS `dmc_master` (
  `dmc_id` int(50) NOT NULL,
  `city_id` int(100) NOT NULL,
  `company_name` varchar(300) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `contact_person_name` varchar(300) NOT NULL,
  `immergency_contact_no` varchar(100) NOT NULL,
  `country_name` varchar(300) NOT NULL,
  `city_name` varchar(200) NOT NULL,
  `state_name` varchar(200) NOT NULL,
  `dmc_address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`dmc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_group_entries`
--

CREATE TABLE IF NOT EXISTS `email_group_entries` (
  `id` int(11) NOT NULL,
  `email_group_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `email_id_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_group_master`
--

CREATE TABLE IF NOT EXISTS `email_group_master` (
  `email_group_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `email_group_name` varchar(150) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_promo_send_enteries`
--

CREATE TABLE IF NOT EXISTS `email_promo_send_enteries` (
  `id` int(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_template_master`
--

CREATE TABLE IF NOT EXISTS `email_template_master` (
  `template_id` int(11) NOT NULL,
  `template_type` varchar(120) NOT NULL,
  `offer_amount` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_template_master`
--

INSERT INTO `email_template_master` (`template_id`, `template_type`, `offer_amount`, `description`, `created_at`) VALUES
(1, 'Monthly Offers', '30%', 'Your text message should be laser focused and succinct. Thereâ€™s no room for fluff in mobile marketing. Know who your target audience is and speak directly to it. Leave out extraneous details and simply describe how to take advantage of your offer and its benefits.', '2017-12-19'),
(2, 'Full Payment', '80', 'Book your Bus & Train Tickets, pick the best-suited seat and experience easy ticket booking service online. Get your seats reserved, book bus tickets today at Paytm. Pack your bags for the journey, book hotels & flights online! Plan your next trip with Paytm, book flight tickets and make a hotel booking online conveniently across India.Full Payment', '2017-12-19'),
(3, 'Repeater', '60%', 'happy repeater\n', '2018-11-03'),
(4, 'Senior Citizens', '900', 'World Senior Citizen Day Messages\nby admin\nWorld Senior Citizen Day Messages\n\n \nWorld Senior Citizen Day falls on August 8th every year. On this special day, a mega event is organized in order to felicitate senior citizens over 80 years of age. This is the day which celebrates the wisdom and work of senior citizens .', '2017-12-19'),
(5, 'Womens Special', '25%', 'Womenâ€™s Day is celebrated on March 8 every year in honor of womenâ€™s rights and their role in the society. The significance of this day has blended with diverse cultures and ethnicity across the world, and is celebrated in varied forms.', '2018-03-26'),
(6, 'Eid', '250', '"In every shared smile and laughter; In every silent prayer answered; In every opportunity that comes your way - may Allah bless you immensely! Eid Mubarak"', '2017-12-19'),
(8, 'Gudi Padwa', '258%', 'Gudi Padwa SMS in English to celebrate the beginning of New Years Day for people of Maharashtra by sending heartfelt Gudi Padwa SMS wishes. Let your loved ones know you are thinking of them on the special occassion of Gudi Padwa festival by sharing these original and creative Gudi Padwa SMS Wishes in English.', '2017-12-19'),
(10, 'Raksha Bandhan', '25000', 'Dear brother, even though I am far away from you, but you will always be there in my heart. Happy Raksha Bandhan.', '2018-11-03'),
(11, 'Ganesha Chaturthi', 'Up To 1500', 'You will get all type of Happy Ganesh Chaturthi Wishes in Hindi Sudh and Ganesh Chaturthi Wishes in English. Send Ganesh Chaturthi Wishes Messages / Happy Ganesh Chaturthi Wishes SMS to your WhatsApp and Facebook friends. So, enjoy the collection with your friends and family!', '2018-05-16'),
(12, 'Diwali', '80', 'Todayâ€™s the `Festival of Lightsâ€™ all over, A joyful day for minds and hearts and souls, Laughter and smiles for many days, Let there be triumph in every wayâ€¦â€¦.!!!\n', '2017-12-19'),
(13, 'Christmas', 'Hhk', 'â€œThis New Year I wish that God showers you with His choicest Blessings, Fate never takes you for a bumpy ride, Cupid strikes you with his sweetest arrow, Lady Luck bestows upon you health and wealth, your Guardian Angel keeps your mind alert and bright.â€HAPPY NEW YEAR', '2018-12-08'),
(14, 'New Year', '!@@@', '!@@@', '2018-11-03'),
(16, 'Father''s Day', '80&', 'â€œYouâ€™ll always have your own special place in my heart, Papa.â€\nâ€œHappy Fatherâ€™s Day to the best grandpa in the world!â€\nâ€œI hope I can create as many good memories for my grandchildren as you have given me.â€', '2017-12-19'),
(17, 'Mother''s Day', '85.20%', 'Though I can never repay you for your love and care, I cant miss to express my gratitude, love and reverence on this beautiful day of the year! Special Mothers Day Greetings to my special mom!', '2018-11-03'),
(18, 'Valentine Day', '250', 'I just wanted to tell you, on this very special Valentineâ€™s Day: Iâ€™m exceptionally thankful you lowered your standards enough to date me.', '2017-12-19'),
(19, 'Easter', '25%', 'Now that we truly understand the meaning of Easter, we should be not only be thankful and rejoice in what we have but also wish the same blessings to others. This Easter, greet your family and loved ones a happy Easter. Here are some samples of Easter messages that you can use.', '2017-12-19'),
(20, 'Halloween', 'Rs .256', 'Hope your day doesnâ€™t suck like a vampire. May you have an amazing day and a freakishly scary Halloween!\nKeep calm, trick or treat and carry on', '2017-12-19'),
(21, 'Thanks Giving', '10000', 'oooooooooooooooooooooooooooo', '2018-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance_log`
--

CREATE TABLE IF NOT EXISTS `employee_attendance_log` (
  `attendance_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `att_date` date NOT NULL,
  PRIMARY KEY (`attendance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee_performance_master`
--

CREATE TABLE IF NOT EXISTS `employee_performance_master` (
  `id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `year` int(200) NOT NULL,
  `month` int(11) NOT NULL,
  `competency` int(200) NOT NULL,
  `leadership` int(200) NOT NULL,
  `communication` int(200) NOT NULL,
  `analytical_skills` int(200) NOT NULL,
  `ethics` int(200) NOT NULL,
  `conceptual_thinking` int(200) NOT NULL,
  `teamwork` int(200) NOT NULL,
  `ave_ratings` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee_salary_master`
--

CREATE TABLE IF NOT EXISTS `employee_salary_master` (
  `salary_id` int(100) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `year` varchar(100) NOT NULL,
  `month` varchar(100) NOT NULL,
  `basic_pay` int(11) NOT NULL,
  `dear_allow` int(11) NOT NULL,
  `hra` int(11) NOT NULL,
  `travel_allow` int(11) NOT NULL,
  `medi_allow` int(11) NOT NULL,
  `special_allow` int(11) NOT NULL,
  `uniform_allowance` int(11) NOT NULL,
  `incentive` int(11) NOT NULL,
  `meal_allowance` decimal(50,2) NOT NULL,
  `phone_allowance` decimal(50,2) NOT NULL,
  `misc_earning` decimal(50,2) NOT NULL,
  `salary_advance` decimal(50,2) NOT NULL,
  `loan_ded` decimal(50,2) NOT NULL,
  `surcharge_deduction` decimal(50,2) NOT NULL,
  `cess_deduction` decimal(50,2) NOT NULL,
  `leave_deduction` decimal(50,2) NOT NULL,
  `gross_salary` decimal(50,2) NOT NULL,
  `employee_pf` decimal(50,2) NOT NULL,
  `esic` decimal(50,2) NOT NULL,
  `pt` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `labour_all` decimal(50,2) NOT NULL,
  `employer_pf` decimal(50,2) NOT NULL,
  `deduction` decimal(50,2) NOT NULL,
  `net_salary` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`salary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emp_master`
--

CREATE TABLE IF NOT EXISTS `emp_master` (
  `emp_id` int(50) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `role_id` int(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(400) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `mobile_no2` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `age` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `location_id` int(50) NOT NULL,
  `date_of_join` date NOT NULL,
  `branch_id` int(50) NOT NULL,
  `salary` decimal(50,2) NOT NULL,
  `target` varchar(150) NOT NULL,
  `id_proof_url` varchar(200) NOT NULL,
  `photo_upload_url` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `incentive` decimal(50,2) NOT NULL,
  `enquiry_count` int(11) NOT NULL,
  `temp_enq_count` int(11) NOT NULL,
  `task_count` int(11) NOT NULL,
  `temp_task_count` int(11) NOT NULL,
  `leave_count` int(11) NOT NULL,
  `temp_leave_count` int(11) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_type` varchar(200) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `visa_amt` decimal(50,2) NOT NULL,
  `renewal_amount` decimal(50,2) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `ifsc` varchar(200) NOT NULL,
  `acc_no` varchar(200) NOT NULL,
  `basic_pay` decimal(50,2) NOT NULL,
  `dear_allow` decimal(50,2) NOT NULL,
  `hra` decimal(50,2) NOT NULL,
  `travel_allow` decimal(50,2) NOT NULL,
  `medi_allow` decimal(50,2) NOT NULL,
  `special_allow` decimal(50,2) NOT NULL,
  `uniform_allowance` decimal(50,2) NOT NULL,
  `incentive_per` decimal(50,2) NOT NULL,
  `meal_allowance` decimal(50,2) NOT NULL,
  `gross_salary` decimal(50,2) NOT NULL,
  `employee_pf` decimal(50,2) NOT NULL,
  `esic` decimal(50,2) NOT NULL,
  `pt` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `labour_all` decimal(50,2) NOT NULL,
  `employer_pf` decimal(50,2) NOT NULL,
  `deduction` decimal(50,2) NOT NULL,
  `net_salary` decimal(50,2) NOT NULL,
  `uan_code` varchar(200) NOT NULL,
  `app_smtp_status` varchar(20) NOT NULL,
  `app_smtp_host` varchar(100) NOT NULL,
  `app_smtp_port` varchar(50) NOT NULL,
  `app_smtp_password` varchar(100) NOT NULL,
  `app_smtp_method` varchar(100) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_master`
--

CREATE TABLE IF NOT EXISTS `enquiry_master` (
  `enquiry_id` int(100) NOT NULL,
  `login_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `enquiry_type` varchar(100) NOT NULL,
  `enquiry` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(150) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `location` varchar(100) NOT NULL,
  `enquiry_specification` varchar(800) NOT NULL,
  `enquiry_date` date NOT NULL,
  `followup_date` datetime NOT NULL,
  `reference_id` int(100) NOT NULL,
  `assigned_emp_id` int(50) NOT NULL,
  `enquiry_content` text NOT NULL,
  `status` varchar(200) NOT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`enquiry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_master_entries`
--

CREATE TABLE IF NOT EXISTS `enquiry_master_entries` (
  `entry_id` int(100) NOT NULL,
  `enquiry_id` int(50) NOT NULL,
  `followup_reply` varchar(500) NOT NULL,
  `followup_status` varchar(200) NOT NULL,
  `followup_type` varchar(200) NOT NULL,
  `followup_date` datetime NOT NULL,
  `followup_stage` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `estimate_type_master`
--

CREATE TABLE IF NOT EXISTS `estimate_type_master` (
  `id` int(50) NOT NULL,
  `estimate_type` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estimate_type_master`
--

INSERT INTO `estimate_type_master` (`id`, `estimate_type`) VALUES
(1, 'Group Tour'),
(2, 'Package Tour'),
(3, 'Car Rental'),
(4, 'Visa Booking'),
(5, 'Passport Booking'),
(6, 'Ticket Booking'),
(7, 'Hotel Booking'),
(8, 'Train Ticket Booking'),
(9, 'Bus Booking'),
(10, 'Forex Booking'),
(12, 'Excursion Booking'),
(13, 'Miscellaneous Booking');

-- --------------------------------------------------------

--
-- Table structure for table `excursion_inventory_master`
--

CREATE TABLE IF NOT EXISTS `excursion_inventory_master` (
  `entry_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `total_tickets` varchar(50) NOT NULL,
  `valid_from_date` date NOT NULL,
  `valid_to_date` date NOT NULL,
  `rate` decimal(10,0) NOT NULL,
  `cancel_date` date NOT NULL,
  `reminder1` date NOT NULL,
  `reminder2` date NOT NULL,
  `note` text NOT NULL,
  `created_at` date NOT NULL,
  `active_flag` varchar(50) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master`
--

CREATE TABLE IF NOT EXISTS `excursion_master` (
  `exc_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `exc_issue_amount` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(200) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` varchar(300) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `exc_total_cost` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`exc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_coupons`
--

CREATE TABLE IF NOT EXISTS `excursion_master_coupons` (
  `entry_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `offer_in` varchar(20) NOT NULL,
  `offer_amount` decimal(50,2) NOT NULL,
  `agent_type` varchar(12) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_entries`
--

CREATE TABLE IF NOT EXISTS `excursion_master_entries` (
  `entry_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `exc_date` datetime NOT NULL,
  `city_id` int(11) NOT NULL,
  `exc_name` int(11) NOT NULL,
  `total_adult` int(11) NOT NULL,
  `total_child` int(11) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_cost` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `status` varchar(300) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_images`
--

CREATE TABLE IF NOT EXISTS `excursion_master_images` (
  `entry_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `image_url` varchar(300) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_offers`
--

CREATE TABLE IF NOT EXISTS `excursion_master_offers` (
  `entry_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `offer_in` varchar(12) NOT NULL,
  `offer_amount` decimal(50,2) NOT NULL,
  `agent_type` varchar(15) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_tariff`
--

CREATE TABLE IF NOT EXISTS `excursion_master_tariff` (
  `entry_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `excursion_name` varchar(100) NOT NULL,
  `transfer_option` varchar(20) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `departure_point` varchar(200) NOT NULL,
  `rep_time` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `note` varchar(300) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `terms_condition` text NOT NULL,
  `useful_info` text NOT NULL,
  `booking_policy` text NOT NULL,
  `canc_policy` text NOT NULL,
  `currency_code` int(11) NOT NULL,
  `active_flag` varchar(10) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_master_tariff_basics`
--

CREATE TABLE IF NOT EXISTS `excursion_master_tariff_basics` (
  `entry_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_cost` decimal(50,2) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `excursion_service_voucher`
--

CREATE TABLE IF NOT EXISTS `excursion_service_voucher` (
  `id` int(11) NOT NULL,
  `booking_type` varchar(20) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exc_payment_master`
--

CREATE TABLE IF NOT EXISTS `exc_payment_master` (
  `payment_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(200) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exc_refund_entries`
--

CREATE TABLE IF NOT EXISTS `exc_refund_entries` (
  `id` int(11) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exc_refund_master`
--

CREATE TABLE IF NOT EXISTS `exc_refund_master` (
  `refund_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(300) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `clearance_status` varchar(300) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `finance_transaction_master`
--

CREATE TABLE IF NOT EXISTS `finance_transaction_master` (
  `finance_transaction_id` int(100) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_entry_id` varchar(300) NOT NULL,
  `gl_id` int(100) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_particular` text NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `payment_side` varchar(100) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `row_specification` varchar(100) NOT NULL,
  `ledger_particular` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`finance_transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `financial_year`
--

CREATE TABLE IF NOT EXISTS `financial_year` (
  `financial_year_id` int(50) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`financial_year_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fixed_asset_entries`
--

CREATE TABLE IF NOT EXISTS `fixed_asset_entries` (
  `entry_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `asset_ledger` varchar(300) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_amount` decimal(50,2) NOT NULL,
  `depr_type` varchar(200) NOT NULL,
  `rate_of_depr` varchar(300) NOT NULL,
  `depr_interval` int(11) NOT NULL,
  `depr_till_date` decimal(50,2) NOT NULL,
  `carrying_amount` decimal(50,2) NOT NULL,
  `sold_amount` decimal(50,2) NOT NULL,
  `profit_loss` decimal(50,2) NOT NULL,
  `remark` text NOT NULL,
  `evidence_url` text NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fixed_asset_master`
--

CREATE TABLE IF NOT EXISTS `fixed_asset_master` (
  `entry_id` int(11) NOT NULL,
  `asset_name` varchar(300) NOT NULL,
  `asset_type` varchar(300) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fixed_asset_master`
--

INSERT INTO `fixed_asset_master` (`entry_id`, `asset_name`, `asset_type`) VALUES
(1, 'Building', 'Tangible Asset'),
(2, 'Furniture & Fixtures', 'Tangible Asset'),
(3, 'Land', 'Tangible Asset'),
(4, 'Office Equipments', 'Tangible Asset'),
(5, 'Plant & Equipment', 'Tangible Asset'),
(6, 'Vehicles', 'Tangible Asset'),
(7, 'Computer Softwares', 'Intangible Asset'),
(8, 'Goodwill', 'Intangible Asset'),
(9, 'Licences', 'Intangible Asset'),
(10, 'Patent', 'Intangible Asset'),
(11, 'TradeMarks', 'Intangible Asset'),
(12, 'Invesment in Debentures & Bonds', 'Investments'),
(13, 'Invesment in Equity Shares', 'Investments'),
(14, 'Invesment in Government Securities', 'Investments'),
(15, 'Invesment in Mutual Funds', 'Investments'),
(16, 'Invesment in Preference Shares', 'Investments');

-- --------------------------------------------------------

--
-- Table structure for table `flight_quotation_master`
--

CREATE TABLE IF NOT EXISTS `flight_quotation_master` (
  `quotation_id` int(200) NOT NULL,
  `enquiry_id` int(200) NOT NULL,
  `login_id` int(200) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `traveling_date` datetime NOT NULL,
  `sector_from` varchar(200) NOT NULL,
  `sector_to` varchar(200) NOT NULL,
  `preffered_airline` varchar(200) NOT NULL,
  `class_type` varchar(200) NOT NULL,
  `trip_type` varchar(200) NOT NULL,
  `total_seats` int(200) NOT NULL,
  `subtotal` int(200) NOT NULL,
  `markup_cost` decimal(50,2) NOT NULL,
  `markup_cost_subtotal` decimal(50,2) NOT NULL,
  `service_tax` int(200) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `taxation_id` int(200) NOT NULL,
  `quotation_cost` decimal(50,2) NOT NULL,
  `quotation_date` date NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `flight_quotation_plane_entries`
--

CREATE TABLE IF NOT EXISTS `flight_quotation_plane_entries` (
  `id` int(200) NOT NULL,
  `quotation_id` int(200) NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(200) NOT NULL,
  `to_location` varchar(200) NOT NULL,
  `airline_name` varchar(200) NOT NULL,
  `class` varchar(200) NOT NULL,
  `arraval_time` datetime NOT NULL,
  `dapart_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `flight_supplier_payment`
--

CREATE TABLE IF NOT EXISTS `flight_supplier_payment` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `bank_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `clearance_status` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followup_and_birthday_reminder`
--

CREATE TABLE IF NOT EXISTS `followup_and_birthday_reminder` (
  `reminder_id` int(100) NOT NULL,
  `reminder_date` date NOT NULL,
  PRIMARY KEY (`reminder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forex_booking_master`
--

CREATE TABLE IF NOT EXISTS `forex_booking_master` (
  `booking_id` int(100) NOT NULL,
  `customer_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `manadatory_docs` text NOT NULL,
  `photo_proof_given` text NOT NULL,
  `residence_proof` text NOT NULL,
  `booking_type` varchar(300) NOT NULL,
  `currency_code` varchar(100) NOT NULL,
  `rate` decimal(50,2) NOT NULL,
  `forex_amount` decimal(50,2) NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(50) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `refund_basic_cost` decimal(50,2) NOT NULL,
  `refund_service_charge` decimal(50,2) NOT NULL,
  `refund_service_tax_subtotal` decimal(50,2) NOT NULL,
  `refund_net_total` decimal(50,2) NOT NULL,
  `booking_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forex_booking_payment_master`
--

CREATE TABLE IF NOT EXISTS `forex_booking_payment_master` (
  `payment_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fourth_coming_attraction_master`
--

CREATE TABLE IF NOT EXISTS `fourth_coming_attraction_master` (
  `id` int(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `valid_date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fourth_coming_att_images`
--

CREATE TABLE IF NOT EXISTS `fourth_coming_att_images` (
  `attr_id` int(200) NOT NULL,
  `fourth_id` int(200) NOT NULL,
  `upload` varchar(200) NOT NULL,
  PRIMARY KEY (`attr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallary_master`
--

CREATE TABLE IF NOT EXISTS `gallary_master` (
  `entry_id` int(11) NOT NULL,
  `dest_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(200) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallary_master`
--

INSERT INTO `gallary_master` (`entry_id`, `dest_id`, `description`, `image_url`) VALUES
(1, 1, 'Baratang Island is an island of the Andaman Islands. It belongs to the North and Middle Andaman', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Baratang_Island.jpg'),
(2, 1, 'The main archipelago of the Andaman Islands of India. It comprises seven major islands.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Great_Andaman.jpg'),
(3, 1, 'Great Nicobar is the southernmost and largest of the Nicobar Islands of India, north of Sumatra.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Great_Nicobar_Island.jpg'),
(4, 1, 'It is part of Ritchieâ€™s ArchipelagoItâ€™s known for its dive sites and beaches with its coral reefs.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Havelock_Island.jpg'),
(5, 1, 'It is famous beaches of Neil Island,It is ideal for places for swimming and sun bathing.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Lakshmanpur.jpg'),
(6, 1, 'Little Andaman Island is the fourth largest of the Andaman Islands of India with an area of 707 kmÂ²', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Little_Andaman.jpg'),
(7, 1, 'Is a national park of India near Wandoor on the Andaman Islands..', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Mahatma_Gandhi_Marine_National_Park.jpg'),
(8, 1, 'Neil Island is an Islands, in the Bay of Bengal. Bharatpur Beach has coral reefs teeming with fishs.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Neil_Island.jpg'),
(9, 1, 'North Andaman Island is the northern island of Great Andaman of the Andaman Islands. ', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_North_Andaman_Island.jpg'),
(10, 1, 'Port Blair on South Andaman Island is the capital city of the Andaman and Nicobar Islands.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_portblai.jpg'),
(11, 1, 'South Andaman Island, the island of the Great Andaman and home for majority of the population.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_South_Andaman_Island.jpg'),
(12, 1, 'Wandoor is a small village near the southern tip of South Andaman.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Wandoor.jpg'),
(13, 1, 'A village in the Nicobar district of Andaman Islands, It is located in the Great Nicobar.', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Indira_Point.jpg'),
(14, 1, 'A large island in Middle Andaman with pristine beaches, waterfalls, and interesting islands. ', 'http://itourscloud.com/destination_gallery/asia/india/andaman_and_nicobar_islands/Asia_India_Andaman_and_Nicobar_Islands_Rangat.jpg'),
(15, 2, 'The Dhyana Buddha statue is a statue of a Buddha in Amaravathi, India.\n', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Amaravati.jpg'),
(16, 2, ' ISKCON temple is in the shape of a horse drawn chariot, with statues of 4 huge horses in front.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Anantapur.jpg'),
(17, 2, 'Annavaram is one of the most famous Holy Shrines in India and enjoying second place after Tirupati.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Annavaram.jpg'),
(18, 2, 'Araku Valley is a hill station surrounded by the thick forests of the Eastern Ghats mountain range. ', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_araku_valley.jpg'),
(19, 2, 'Chandragiri Fort, a historical fort, built in the 11th century in Chandragiri, in Andhra Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Chandragiri.jpg'),
(20, 2, 'Horsley Hills is an enthralling, charming little hill station in Andra Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Horsley_Hills.jpg'),
(21, 2, 'The Charminar, is a historical place with mosque on top floor since 425 years.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Hyderabad.jpg'),
(22, 2, 'Pithapuram is often referred to as Dakshin Kashi, is home to Sri Surya Ayurvedic Nilayam.\n', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Kakinada.jpg'),
(23, 2, 'Kurnool District is one of the 13 districts in the state of Andhra Pradesh, India.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Kurnool.jpg'),
(24, 2, ' Lepakshi is archaeologically significant, dedicated to Shiva, Vishnu and Veerabhadra.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Lepakshi.jpg'),
(25, 2, 'Lord Narasimha and Lord Panakala Narasimha Swamy temple located on the top of the Mangalgiri hill.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Mangalagiri.jpg'),
(26, 2, 'Nagalapuram falls is located near Arai village in Chittoor district.Famous for waterfalls trekking.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Nagalapuram.jpg'),
(27, 2, 'Sri Ranganathaswamy Temple, get a devotional feel while entering in to the temple premises.\n', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Nellore.jpg'),
(28, 2, 'Puttaparthi , has given birth to one such prophet, Sri Satya Sai Baba.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Puttaparthi.jpg'),
(29, 2, 'Located on the bank of Godavari river. Place for devotion, Usually crowded on Krishna astami.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Rajahmundry.jpg'),
(30, 2, 'Andhra Pradesh ', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Ramoji_Film_City.jpg'),
(31, 2, 'Srikalahasti is a holy town in Chittoor district of the Indian state of Andhra Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Srikalahasti.jpg'),
(32, 2, 'The ancient world famous Chintala Venkataramana Temple over 5 acre area is located in Tadipatri.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Tadipatri.jpg'),
(33, 2, 'Tirupati Venkateswara Temple is one of the most popular temple  visited by a number of visitors.', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Tirumala.jpg'),
(34, 2, 'Andhra Pradesh ', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Tirupati.jpg'),
(35, 2, 'Jalakandeswarar Temple features many sculptures.The Government Museum has prehistoric relics.\n', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Vellore.jpg'),
(36, 2, 'Tenneti Park also known as is an Urban park in the city of Visakhapatnam, India. ', 'http://itourscloud.com/destination_gallery/asia/india/andhra_pradesh/Asia_India_AP_Visakhapatnam.jpg'),
(37, 3, 'Barpeta Road is a city and a municipal board in Barpeta district in the state of Assam, India.\n', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Barpeta_Road.jpg'),
(38, 3, 'Sri Surya Pahar, once it was one of the holiest pilgrimage sites in the region.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Goalpara.jpg'),
(39, 3, 'Guwahati holy sites like Kamakhya Temple, featuring shrines to the Hindu deities Shiva and Vishnu.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Guwahati.jpg'),
(40, 3, 'Haflong is known for picturesque views, rich cultural legacy, hilly breathtaking views of valleys.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Haflong.jpg'),
(41, 3, ' Guwahati and Jorhat are underway to become two sunshine cities of Assam.\n\n', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Jorhat.jpg'),
(42, 3, 'Kaziranga National Park is a park in the Golaghat and Nagaon districts of the state of Assam.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_kaziranga_national_park.jpg'),
(43, 3, 'Assam', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Lanka.jpg'),
(44, 3, 'Majuli is a lush green environment friendly and pollution free fresh water island in the river.\n', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Majuli.jpg'),
(45, 3, 'Manas National Park is a UNESCO Natural World Heritage site.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_manas_national_park.jpg'),
(46, 3, ' Tezpur is a historical place in Sonitpur district of Assam.', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Tezpur.jpg'),
(47, 3, 'Umrongso is a small town in Dima Hasao district of Assam.\n', 'http://itourscloud.com/destination_gallery/asia/india/assam/Asia_India_Assam_Umrangso.jpg'),
(48, 4, 'Anjuna Beach Goa. Goa nightlife and beaches has always been dazzling.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Anjuna.jpg'),
(49, 4, ' Very famous for its night market,The Saturday Night Market', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Arpora.jpg'),
(50, 4, 'One of the most popular beaches of Goa, Baga Beach is located close to Calangute beach.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Baga.jpg'),
(51, 4, 'Bogmalo Beach is a small beach-side village in Goa. Situated in a bay with curving sandy beach.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Bogmalo_Beach.jpg'),
(52, 4, 'Calengute is perhaps the busiest of all Goan beach resorts', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Calangute.jpg'),
(53, 4, 'Candolim is a small town in the western Indian. Standing on the shores of the Arabian Sea.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Candolim.jpg'),
(54, 4, ' well known beach at the southernmost tip of the Salcete beach stretch that starts from Majorda.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Cavelossim.jpg'),
(55, 4, 'olva is a famous beach in south Goa lying close to the city of Margao at a distance of 4 kms. ', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Colva.jpg'),
(56, 4, 'The Dona Paula Beach is a pristine beach with a tragic love story to its name.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Dona_Paula.jpg'),
(57, 4, 'Portuguese style church have the unique Sunray falls exactly on the statue for 2 days in the year', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Margao.jpg'),
(58, 4, ' The Mollem reserve also has several temples dating back to the Kadamba Dynasty.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Mollem_National_Park.jpg'),
(59, 4, 'Morjim Beach is famous for Olive Ridley Sea Turtles also offers a plenty of things to do.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Morjim.jpg'),
(60, 4, 'The forest is predominantly moist deciduous type, patches of semi-evergreen forest in the valleys. \n', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Netravali_Wildlife_Sanctuary.jpg'),
(61, 4, 'Old Goa or Velha Goa is a historical city in North Goa district in the Indian state of Goa. ', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Old_Goa.jpg'),
(62, 4, 'Panji, the city has cobblestone streets with colorful villas from the Portuguese colonial era. ', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Panji.jpg'),
(63, 4, ' Ponda is surrounded by scenic green villages and grand temples & home to large industrial estates. ', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Ponda.jpg'),
(64, 4, 'Utorda Beach is a serene and beautiful beach. Loved the white sands, blue sea and peaceful ambiance.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Utorda.jpg'),
(65, 4, 'Vagator Beach is one of the most beautiful beaches in Goa. It is located in Bardez taluk of Goa.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Vagator_Beach.jpg'),
(66, 4, 'Vasco da Gama is a city on the Mormugao peninsula in Goa, western India.', 'http://itourscloud.com/destination_gallery/asia/india/goa/Asia_India_Goa_Vasco_da_Gama.jpg'),
(67, 5, 'Ahmedabad also known as Amdavad or Karnavati is the largest city and former capital of Gujarat.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Ahmedabad.jpg'),
(68, 5, 'Bharuch, The city has a rich mythological and archaeological history..', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Bharuch.jpg'),
(69, 5, 'Bhavnagar, also known as the Sanskari Kendra or Cultural City- identified for cultural ingenuity.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Bhavnagar.jpg'),
(70, 5, 'The citadel built by Mahmud Begda has walls running north-south, with many bastions and gates.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Champaner.jpg'),
(71, 5, '\n\n\n\n\n\nDwarka is one of the seven ancient towns (sapta puris) to visit.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Dwarka.jpg'),
(72, 5, 'Gandhinagar city of Gujarat, also known as the cleanest city in Asia with temples of swaminarayan.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Gandhinagar.jpg'),
(73, 5, '\n\n\n\n\n\nThe Gir National Park is a wildlife sanctuary in Junagadh, Gujarat.\n', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Gir_Forest_National_Park.jpg'),
(74, 5, 'Maharao Lakhpat old palace, built in Kutchi style, a small fortified courtyard in old part of city.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Gujrat-Bhuj.jpg'),
(75, 5, '\n\n\n Maqbara Palace, also Mausoleum of Hasainbhai, that was once home to the Muslims rulers.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Junagadh.jpg'),
(76, 5, 'Rich, Beautiful And Diverse Architecture having hindu and islamic touch.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Mandvi.jpg'),
(77, 5, 'Mani Mandir Monument in Morbi.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Morbi.jpg'),
(78, 5, 'The Palitana temples, are considered the most sacred pilgrimage place by the Jain community.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Palitana.jpg'),
(79, 5, 'Rani ki vav is an intricately constructed stepwell situated in the town of Patan in Gujarat, India.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Patan.jpg'),
(80, 5, 'Shri Hari Mandir, for years has been Bhaishriâ€™s genesis vision and has taken 13 years to be reality.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Porbandar.jpg'),
(81, 5, 'Rajkot is the centre of the Saurashtra region of Gujarat.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Rajkot.jpg'),
(82, 5, 'Saputara,  The Artist Village cultural center displays & sells, arts and crafts with  waterfalls.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Saputara.jpg'),
(83, 5, 'The Ambika-Niketan Temple is one of the famous spots in Surat.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Surat.jpg'),
(84, 5, '\n\nThe Laxmi Vilas Palace, built by R.H.Chisholm was built in 19th century for Rs.6 million.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Vadodara.jpg'),
(85, 5, 'Valsad, cosists of beaches, greenery and the fort which was biult earlier.', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Valsad.jpg'),
(86, 5, 'Somnath temple  located near Veraval , considered first of all Jyotirlings, named after moon(soma)', 'http://itourscloud.com/destination_gallery/asia/india/gujarat/Asia_India_Gujrat_Veraval.jpg'),
(87, 6, 'The very famous ancient temple of Lord Shiva (Baijnath) is situated here giving the town its name.\n', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Baijnath.jpg'),
(88, 6, 'Barot is a quite serene place situated in mandi district of himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Barot.jpg'),
(89, 6, 'Bir Billing is recognized for paragliding hub. Since the time this particular adventure sports come.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Bir.jpg'),
(90, 6, 'Chail is a small beautiful hamlet, spread over three scattered hills in the Shiwalik region.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Chail.jpg'),
(91, 6, ' Chamba, town has numerous temples and palaces,[3][4] and hosts two popular jatras (fairs).', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Chamba.jpg'),
(92, 6, 'chitkul, small village located deep within the Kinnaur Valley.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Chitkul.jpg'),
(93, 6, 'Dalhousie, Known for its pleasant climate and natural beauty, most famous hill stations.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Dalhousie.jpg'),
(94, 6, ' Dharamshala, the prime hill station and one of the most popular tourist places in Himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Dharamshala.jpg'),
(95, 6, 'Fagu is a petite township in Himachal Pradesh to the side a saddle.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Fagu.jpg'),
(96, 6, 'Jawalamukhi Temple â€“ Famous Shakti Peetha in Himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Jawalamukhi.jpg'),
(97, 6, 'Jispa is one in Lahaul Valley in Himachal Pradesh or going to Leh â€“ Ladakh via Manali', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Jispa.jpg'),
(98, 6, 'Kangra is the most populous district of the Indian state of Himachal Pradesh, India.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kangra.jpg'),
(99, 6, 'Kasauli is a cantonment and town, located in Solan district in the Indian state of Himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kasauli.jpg'),
(100, 6, 'kasol, This Himachalâ€™s popular destination is best known for its thrilling treks, food.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kasol.jpg'),
(101, 6, 'Kaza- A Beautiful Town in Lahaul and Spiti Valley, Himachal Pradesh. ', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kaza.jpg'),
(102, 6, 'Khajjiar is a popular hill station about 26 km from Dalhousie in Himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Khajjiar.jpg'),
(103, 6, ' Kufri is a picturesque hill station situated 20 km from Shimla in Himachal Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kufri.jpg'),
(104, 6, 'Known as the Valley of Gods, Kullu is a cluster of beautiful valleys in Himachal Pradesh.  ', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Kullu.jpg'),
(105, 6, 'Himachal Pradesh ', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Manali.jpg'),
(106, 6, 'Manikaran is a famous pilgrimage centre for both Sikhs and Hindus, situated 45 km from Kullu.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Manikaran.jpg'),
(107, 6, 'Mashobra is a town in Shimla, mist bathed hills, pine tree, oak, cedar and deodar, apple orchards.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Mashobra.jpg'),
(108, 6, 'Naggar, situated on sleepy hill, nearer to the left bank of Beas river.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Naggar.jpg'),
(109, 6, 'Nahan, fishing on the rivers and streams has been a pretty old past time in the district..\n', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Nahan.jpg'),
(110, 6, ' Naina Devi temple is an ancient Indian temple. Naina Devi temple is located in Bilaspur district.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Naina_Devi.jpg'),
(111, 6, 'Naldehra, is a paradise for nature lovers & adventure seekers. ', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Naldehra.jpg'),
(112, 6, 'Narkanda Hill Station ,situated at an altitude- 2700 meters & offers a view of ranges of Himalayas.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Narkanda.jpg'),
(113, 6, 'Palampur is a hill station known for its tea gardens like the Palampur Cooperative Tea Factory.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Palampur.jpg'),
(114, 6, 'Paonta Sahib, can explore the Paonta Sahib, Gurudwara Shergarh, Assan Lake and many ancient temples.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Paonta_Sahib.jpg'),
(115, 6, ' Ranjit Sagar Dam, is part of a hydroelectric project constructed by the Government of Punjab.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_ranjit_sagar.jpg'),
(116, 6, 'The statue of Padmasambhava (Guru Rimpoche) above Rewalsar Lake and village..\n', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Rewalsar.jpg'),
(117, 6, 'Kamru Fort, Visitors follow the walking path from the heart of Sangla.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Sangla.jpg'),
(118, 6, 'Shimla, one of the heaven in india after Jammu and Kashmir.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Shimla.jpg'),
(119, 6, 'The magnificent Tabo Caves are located above the ancient Tabo Monastery, was founded 1000 years ago.', 'http://itourscloud.com/destination_gallery/asia/india/himachal_pradesh/Asia_India_HP_Tabo.jpg'),
(120, 7, 'Jammu; multi-hued flags, shrines in the city, the tantalizing aromas .', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_Jammu.jpg'),
(121, 7, 'Khardung La by road, highest motorable road in the world-18,380 feet gives beautiful view of Leh.', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_Khardong_Leh.jpg'),
(122, 7, 'Scenic beauty of Mountains and Pangong tso Lake, blue sky and Himalayan mountains in background.', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_Pangong_Tso.jpg'),
(123, 7, 'Zanskar River and Waterfall trek is probably one of the most adventurous routes that you can watch.', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_ranjit_sagar.jpg'),
(124, 7, 'chorten in saboo village, near leh, jammu and kashmir, india.', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_Saboo_Leh.jpg'),
(125, 7, 'The pearl of kashmir, the Venice of Jammu & Kashmir is a magnificent city where thousands reside.', 'http://itourscloud.com/destination_gallery/asia/india/jammu_and_kashmir/Asia_India_HP_srinagar.jpg'),
(126, 8, 'Chalukyan capital across the Malaprabha river to Aihole  where monuments fill your eyes everywhere.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Aihole.jpg'),
(127, 8, 'Bdami; It has a combination of South and North Indian Style as seen in the Shikharas or Spires.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Badami.jpg'),
(128, 8, 'A tiger reserve  Bandipur National Park.Well known for its breathtaking natural beauty.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Bandipur_National_Park.jpg'),
(129, 8, 'The Bangalore Palace is a striking embodiment of class and eminence.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Banglore.jpg'),
(130, 8, 'Chennakesava Temple, the temples and monuments of Belur are the examples of Hoysala architecture.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Belur.jpg'),
(131, 8, 'Bidar is symbolically described as City of Whispering Monuments.\n', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Bidar.jpg'),
(132, 8, 'Bijapur is a historic fort city(earlier They called it Vijayapura or the City of Victory).', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Bijapur.jpg'),
(133, 8, 'Abode of Mysticism-The Golden Pagoda,Bylakuppe, Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Bylakuppe.jpg'),
(134, 8, ' Chikmagalur district is the highest peak in Karnataka with an altitude of 1950 meters.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Chikmagalur.jpg'),
(135, 8, 'Dandeli Karnataka â€“ an enthralling gateway to nature, fun & adventure!\n', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Dandeli.jpg'),
(136, 8, 'Gorkhana-seaside idyll, seclusion, religion and pleasure come together.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Gokarna.jpg'),
(137, 8, 'The Hoysaleshwara Temples, Halebidu, Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Halebidu.jpg'),
(138, 8, 'Hampi is one of the most impressive sites to visit in India. Inscribed as UNESCO Heritage site.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Hampi.jpg'),
(139, 8, 'Jog falls, being the tallest waterfalls in India is situated in the dense evergreen forests.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Jog_falls.jpg'),
(140, 8, 'Shiva temple at Lepakshi, Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Lepakshi.jpg'),
(141, 8, 'Madikeri, a popular hill station located in the state of Karnataka, India.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Madikeri.jpg'),
(142, 8, 'Mangalore is the principal port city of the Indian province of Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Mangalore.jpg'),
(143, 8, 'Masinagudi is a big tourist destination known for Wildlife tourism located in  Nilgiri District.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Mudumalai_National_Park.jpg'),
(144, 8, 'Mysore has a royal history, a rich and regal heritage and an important center of art and culture.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Mysore.jpg'),
(145, 8, 'Nagarhole National Park is a national park in Karnataka state in South India.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Nagarhole_National_Park.jpg'),
(146, 8, 'Nandi Hills, also known as Nandidurg or Nandi Betta is an ancient hill fortress .', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Nandi Hills.jpg'),
(147, 8, 'Pattadakal was capital of the Chalukya dynasty of Karnataka between the 6th and 8th centuries. \n\n\n', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Pattadakal.jpg'),
(148, 8, 'Provides greenery to eyes, beautiful scenic nature with rail routes.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Sakleshpur.jpg'),
(149, 8, 'Shimoga district, is a beautiful sight, dotted with waterfalls, swaying palms and lush paddy fields.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Shimoga.jpg'),
(150, 8, ' Sivanasamudra Falls is on the Kaveri River, the river has found its way through the rocks .', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Shivanasamudra Falls.jpg'),
(151, 8, 'Shravanabelagola Temple, Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Shravanabelagola.jpg'),
(152, 8, 'Marikamba temple at Sirsi.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Sirsi.jpg'),
(153, 8, 'The Keshava temple at Somanathapura is another magnificent Hoysala monument, perhaps the last. ', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Somanathapura.jpg'),
(154, 8, 'Sringeri houses the very significant Sri Sarada Samsthanam established in the 7th century.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Sringeri.jpg'),
(155, 8, 'Srirangapatna, a historical place belongs to Mandya district of Karnataka state in India..', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Srirangapatna.jpg'),
(156, 8, 'The architectural & structural design and construction services is much more attractive.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Tumkur.jpg'),
(157, 8, 'Udipi famous for its South india food all over the country, is a coastal town with carved temples.', 'http://itourscloud.com/destination_gallery/asia/india/karnataka/Asia_India_Karnataka_Udupi.jpg'),
(158, 9, ' Alappuzha Beach is a popular picnic spot; famous for its boat races, backwater holidays, beaches.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Alappuzha.jpg'),
(159, 9, 'Ashtamudi Lake is the most visited backwater; a unique ecosystem and a large palm-shaped water body.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Ashtamudi.jpg'),
(160, 9, 'Bandipur National Park established in 1974 as a tiger reserve under Project Tiger in kerela.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Bandipur_national_park.jpg'),
(161, 9, 'Bekal Fort, is the largest fort in Kerala, situated at Bekal village in Kasargod taluk of Karnataka.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Bekal_Fort.jpg'),
(162, 9, 'Chinnar Wildlife Sanctuary, unique protected area located in rain shadow region of Western Ghats.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Chinnar_wildlife_sanctuary.jpg'),
(163, 9, ' Kochi or Cochin is popularly known as the Queen of Arabian Sea, major port city.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Kochin.jpg'),
(164, 9, 'Kodungallur was known to the Greeks as Muziris and is a place immersed in rich history.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Kodungallur.jpg'),
(165, 9, 'Kottayam Places to Visit and its attractive sight seeing places Kumarakom,Elaveezhapoonchira,Vaikom.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Kottayam.jpg'),
(166, 9, 'Kovalam beach only Black Sand Beach in Kerala. A beautiful creation of God.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Kovalam.jpg'),
(167, 9, 'Kumarakom is a popular tourism destination located near the city of Kottayam.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Kumarakom.jpg'),
(168, 9, 'Malampuzha Dam is the largest reservoir in Kerala.This picnic spot has a dam and garden for leisure.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Malampuzha.jpg'),
(169, 9, 'Malampuzha gardens, rock-cut gardens in South India, winner of the Padmashree award.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Malampuzhagarden.jpg'),
(170, 9, ' Marari beach in Mararikulam, is a tribute to the fisherfolk of this region ', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Mararikulam.jpg'),
(171, 9, 'Munnar, A hill station, it is surrounded by rolling hills dotted with tea plantations', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Munnar.jpg'),
(172, 9, 'Periyar National Park, also known as Periyar Tiger Reserve, is in the mountainous Western Ghats.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Periyar_National_Park.jpg'),
(173, 9, 'Poovar island is one of the best estuary island in kerala.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Poovar.jpg'),
(174, 9, 'Padmanabha Swamy Temple, Dedicated to Lord Vishnu and for the art lovers.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Thiruvananthapuram.jpg'),
(175, 9, 'Thrippunithura or Tripunithura is a suburb of the city of Kochi in the state of Kerala, India.', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Thrippunithura.jpg'),
(176, 9, 'Vembanad Rail Bridge is a rail connecting Edappally and Vallarpadam in Kochi, Kerala..', 'http://itourscloud.com/destination_gallery/asia/india/kerela/Asia_India_Kerela_Vembanad_bridge.jpg'),
(177, 10, 'Amarkantak is a pilgrim town and a Nagar Panchayat in Anuppur, Madhya Pradesh, India.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Amarkantak.jpg'),
(178, 10, 'The Dhuandhar Falls is a waterfall in Jabalpur district in the Indian state of Madhya Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Bhedaghat.jpg'),
(179, 10, 'Bhojpur is a town of historical and religious importance in Raisen District of Madhya Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Bhojpur.jpg'),
(180, 10, 'Chitrakoot is a holy township, located in Satna district of Madhya Pradesh. ', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Chitrakoot.jpg'),
(181, 10, 'Gwalior, known for its palaces and temples, including the Sas Bahu Ka Mandir .', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Gwalior.jpg'),
(182, 10, 'Indore, known for the 7-story Rajwada Palace and the Lal Baag Palace.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Indore.jpg'),
(183, 10, 'Jabalpur, On a rocky hilltop on the outskirts of the city is the Madan Mahal Fort & waterfalls.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Jabalpur.jpg'),
(184, 10, 'orchcha, the hidden beauty, during the medieval period  lots of gems & Bundellas architecture there.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Jhansi.jpg'),
(185, 10, 'Kanha National Park is a national park and a Tiger Reserve in the Mandla and Balaghat.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Kanha_Tiger_Reserve.jpg'),
(186, 10, 'About 1000AD year old; the temples of Khajuraho were constructed during the Chandella Dynasty.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Khajuraho_Group_of_Monuments.jpg'),
(187, 10, 'Sharda temple Maihar , the goddess sharda mata temple is situated there.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Maihar.jpg'),
(188, 10, 'Mandu is an ancient fort city in the central Indian state of Madhya Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Mandu.jpg'),
(189, 10, 'Omkareshwar is a Hindu temple dedicated to God Shiva. It is one of the 12 revered Jyotirlinga .', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Omkareshwar.jpg'),
(190, 10, 'The monuments here retain the historic touch to give tourists an insight into its rich past.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Orchha.jpg'),
(191, 10, 'Pachmarhi, also known as Satpura ki Rani, is a hill station in the state of Madhya Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Pachmarhi.jpg'),
(192, 10, 'Pench National Park derives its name from the Pench River that flows through the park.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Pench_National_Park.jpg'),
(193, 10, 'Rewa is known as the land of white tigers and waterfalls.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Rewa.jpg'),
(194, 10, 'Sanchi Stupa, is a Buddhist complex, famous for its Great Stupa, on a hilltop at Sanchi..', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Sanchi.jpg'),
(195, 10, 'Ujjain is an ancient city beside the Kshipra River in the central Indian state of Madhya Pradesh.', 'http://itourscloud.com/destination_gallery/asia/india/madhya_pradesh/Asia_India_MP_Ujjain.jpg'),
(196, 11, 'Alibaug is a coastal town in the Konkan region well known for its sandy beaches, clean water.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Alibag.jpg'),
(197, 11, 'Aurangabad is a historic city in Maharashtra state of India.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Aurangabad.jpg'),
(198, 11, 'Dombivli is a city in the Thane District of Maharashtra state in Konkan division.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Dombivli.jpg'),
(199, 11, 'Ganpatipule temple on the Ganpatipule beach is followed by most of the devotees.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Ganpatipule.jpg'),
(200, 11, 'Junnar is a city with thousands of years of history in the Pune district of the Maharashtra.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Junnar.jpg'),
(201, 11, 'Khandala is a hill station in the Western Ghat mountains of Maharashtra, western India.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Khandala.jpg'),
(202, 11, 'Kolhapur,  known for its temples, like the ancient Mahalakshmi Temple.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Kolhapur.jpg'),
(203, 11, 'Lonavala is a hill station surrounded by green valley. The Karla Caves and the Bhaja Caves are made.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Lonavla.jpg'),
(204, 11, 'Mahabaleshwar,  is a hill station located in the Sahyadri mountain range.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Mahabaleshwar.jpg'),
(205, 11, 'Malvan is one of the few places where scuba diving can be done in India.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Malvan.jpg'),
(206, 11, 'Matheran is a hill station, known for its mild climate and well-preserved colonial architecture.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Matheran.jpg'),
(207, 11, 'Mumbai, city of dreams and the gate way of India is located & the bollywood city.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Mumbai.jpg'),
(208, 11, 'Nagpur, the winter capital of Maharashtra and the city of oranges.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Nagpur.jpg'),
(209, 11, 'Nanded is the district in Indian state of Maharashtra known an important holy place for the Sikh.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Nanded.jpg'),
(210, 11, 'Nashik is an ancient holy city in Maharashtra, a state in western India known for the Ramayana epic.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Nashik.jpg'),
(211, 11, 'Panchgani also called Paachgani is a famous hill station and municipal council in Satara.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Panchgani.jpg'),
(212, 11, 'Panhala is in Maharashtra and is best known for the fort associated with the Maratha king Shivaji.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Panhala.jpg'),
(213, 11, 'Panvel is a city in Raigad district of Maharashtra in Konkan Division.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Panvel.jpg'),
(214, 11, 'pench nation park ever green forests of western ghats to deciduous forest of Vidarbha.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Pench_National_Park.jpg'),
(215, 11, 'Shreemant Dagdusheth Halwai Ganapati Temple in Pune is dedicated to the Hindu God Ganesh. ', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Pune.jpg'),
(216, 11, 'Sanjay Gandhi National Park, formerly Borivali National Park, is a large protected area.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Sanjay_Gandhi_National_Park.jpg'),
(217, 11, 'Shani Shingnapur or Shani Shinganapur or Shingnapur or Sonai is a village.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Shani_Shingnapur.jpg'),
(218, 11, 'Shirdi is known as the former home of revered spiritual leader Sai Baba and a major pilgrimage site.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Shirdi.jpg'),
(219, 11, 'Tadoba Andhari Tiger Reserve is a tiger reserve in Chandrapur district in India.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia_India_Maharashtra_Tadoba_Andhari_Tiger_Project.jpg'),
(220, 11, 'This Mumbai Pune highway is  passing through lonavla gives a scenic view from vehical.', 'http://itourscloud.com/destination_gallery/asia/india/maharashtra/Asia-India-Maharashtra-Pune_Express_way.jpg'),
(221, 12, 'Karaikal is a major port city of east coast of India', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Karaikal.jpg'),
(222, 12, 'Pondicherry is one of the top-tourist destinations to visit in India.', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Madagadipet.jpg'),
(223, 12, 'Thirunallar is a small village.This place is dedicated voted to Saturn.', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Nedungadu.jpg'),
(224, 12, 'Pondicherry, a French colonial settlement in India until 1954, is now a Union Territory.', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Pondicherry.jpg'),
(225, 12, ' The charming place of Pondicherry has something for everyone.', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Singirikudi.jpg'),
(226, 12, 'Thiruvandarkoil Temple, Thiruvandarkoil is on of the Village in Mannadipet Tehsil.', 'http://itourscloud.com/destination_gallery/asia/india/puducherry/Asia_India_Poducherry_Thiruvandarkoil.jpg'),
(227, 13, 'Chand Baori is a stepwell situated in the village of Abhaneri in the Indian state of Rajasthan.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Abhaneri.jpg'),
(228, 13, 'The dargah of Moinuddin Chishti, known as Ajmer Sharief Dargah or Ajmer Sharief.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Ajmer.jpg'),
(229, 13, ' Alwar City Palace, from 1793, blends architectural styles and has marble pavilions on lotus-shaped.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Alwar.jpg'),
(230, 13, 'Amer palace is located in amer, a town with 11 kilometers from Jaipur.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Amer.jpg'),
(231, 13, 'The Bhangarh Fort is a 17th-century fort built in the Rajasthan state of India.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Bhangarh.jpg'),
(232, 13, 'Lohagarh Fort is situated at Bharatpur, India. It was constructed by Bharatpur Jat rulers.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Bharatpur.jpg'),
(233, 13, 'Bhilwara, This seven storied fort stands atop a hill and presents breathtaking views all around. ', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Bhilwara.jpg'),
(234, 13, 'Junagarh Fort (Rajasthani: à¤œà¥à¤¨à¤¾à¤—à¥à¤¦ à¤•à¤¼à¤¿à¤²à¤¾) is a fort in the city of Bikaner, Rajasthan, India. ', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Bikaner.jpg'),
(235, 13, 'The Taragarh Fort crowns the crest of a steep hill overlooking the town.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Bundi.jpg'),
(236, 13, 'CHITTORGARH RANI PADMINI PALACE: stories of Rajputana bravery, pride and passion. ', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Chittorgarh.jpg'),
(237, 13, 'Deeg Palace is a palace built in 1772 as a luxurious summer resort for the rulers of Bharatpur.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Deeg.jpg'),
(238, 13, 'This is at the famous Karni Matha temple in Deshnok, Rajasthan. The temple is full of rats.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Deshnoke.jpg'),
(239, 13, 'Hawa Mahal: This pyramid-shaped five storied mask is among the most popular.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Jaipur.jpg'),
(240, 13, '\n\nJaisalmer is where you need to journey. Sonar Qila (Golden Fort) Unlike most other forts in India.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Jaisalmer.jpg'),
(241, 13, 'JHALAWAR THE HISTORICAL CITY:  called Brijnagar is known for its rich natural wealth. ', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Jhalawar.jpg'),
(242, 13, 'Jodhpur is a sunny city set against a bright blue sky. A popular travel destination in Rajasthan.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Jodhpur.jpg'),
(243, 13, 'KOTA CHAMBAL RIVER:  Kota is famous for paintings, palaces, museums, and places of worship.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Kota.jpg'),
(244, 13, 'The castle Mandwa hotel was built in 1755.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Mandawa.jpg'),
(245, 13, 'Mount Abu  is a popular hill station in the Aravalli Range in Sirohi district of Rajasthan state.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Mount_Abu.jpg'),
(246, 13, 'Built since 1464 Neemrana Fort-Palace the third capital of descendants of Prithviraj Chauhan III.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Neemrana.jpg'),
(247, 13, 'Harihara temple is among one best temple in Osian Temples.Harihara temple is located at Osian.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Osian.jpg'),
(248, 13, 'OM TEMPLE: this large complex,constructed in the shape of the ancient Sanskrit symbol OM.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Pali.jpg'),
(249, 13, 'Pushkar is one of the five dhams or sacred places that are highly revered by Hindus .', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Pushkar.jpg'),
(250, 13, ' Rajsamand Lake, an artificial lake created in the 17th century by Rana Raj Singh of Mewar. ', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Rajsamand.jpg'),
(251, 13, 'magnificent architecture and numerous pillars, the place is famous population of monkeys that live.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Ranakpur.jpg');
INSERT INTO `gallary_master` (`entry_id`, `dest_id`, `description`, `image_url`) VALUES
(252, 13, 'Ranthambhore Tour:  abandoned to nature for in this national park, the tiger has right of stay.', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Ranthambore_National_Park.jpg'),
(253, 13, 'UDAIPUR MONSOON PALACE: THE CITY OF LAKES AND PALACES', 'http://itourscloud.com/destination_gallery/asia/india/rajasthan/Asia_India_Rajasthan_Udaipur.jpg'),
(254, 14, ' Roads less traveled are often the most splendid these titanic vistas happen to colossal  art.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Dzuluk.jpg'),
(255, 14, 'Gangtok is largest town of the Indian state of Sikkim and is also known as the land of monasteries', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Gangtok.jpg'),
(256, 14, 'Mount Katao is yet another extreme places in Sikkim!', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Katao.jpg'),
(257, 14, 'Kupup Lake, one of the famous lake in sikkim.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Kupup.jpg'),
(258, 14, 'Nathang Valley appears in different colours in different times of the year.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Nathang_Valley.jpg'),
(259, 14, 'Pelling today has emerged as one of the important tourist destination of the state after Gangtok.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Pelling.jpg'),
(260, 14, 'On the birth anniversary of Lord Gautama Buddha in 2006 this statue was made in sikkim.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Ravangla.jpg'),
(261, 14, 'Flowing water, green nature and whistling sound of birds is the main attractuion of the Reshi.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Reshi.jpg'),
(262, 14, 'Singalila National Park -Leopard, Pangolin, Chinkara, Elephant, Barking deer.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Singalila_National_Park.jpg'),
(263, 14, 'The Temi Tea Garden in Ravangla, established in 1969 by the Government of Sikkim.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Temi.jpg'),
(264, 14, 'Tshoka is a small settlement in the Kanchenjunga National Park in West Sikkim.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Tshoka.jpg'),
(265, 14, 'Yumthang Valley in Sikkim, Valley of Flowers.This valley is a natural landscape filled with springs.', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Yumthang_Valley_of_Flowers.jpg'),
(266, 14, 'Zemu Glacier: Sikkims largest glacier melting point. ', 'http://itourscloud.com/destination_gallery/asia/india/sikkim/Asia_India_Sikkim_Zemu_Glacier.jpg'),
(267, 15, 'Chennai or Madras as it was called before, on the Coromandel Coast;  the capital city of Tamil Nadu.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Chennai.jpg'),
(268, 15, 'This temple dedicated to Lord Shiva called as Natarajar is one of the Five Sabhas [divin e stages].', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Chidambaram.jpg'),
(269, 15, 'A 112-foot tall statue of Lord Shiva,dedicated to Adiyogi in Coimbatore, declared worlds largest.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Coimbatore.jpg'),
(270, 15, 'Some of Tamil Nadus most famous hill resorts are located here.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Coonoor.jpg'),
(271, 15, 'Water Falls of Courtallam, The 60 ft Peraruvi the prominent falls has a deep crater at Pongumakadal.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Courtallam.jpg'),
(272, 15, 'Tamil Nadus Ghost Town; Dhanushkodi is a small, sparsely populated beach town.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Dhanushkodi.jpg'),
(273, 15, 'Kanchipuram , This town is famous as the Moksha Pradayi Nagar..', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Kanchipuram.jpg'),
(274, 15, 'Lord Vishnu Commanded Devraj Indra,  have appeared Kanyakumari from the holy fire of the sacrifice.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Kanyakumari.jpg'),
(275, 15, 'Constructed like a lotus, Madurai is mostly popular for its Meenakshi Temple. ', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Madurai.jpg'),
(276, 15, ' world heritage site by UNESCO, this city has really nicely preserved ancient temples to see here..\n', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Mamallapuram.jpg'),
(277, 15, 'The natural surroundings of Ooty include landscapes, dense forest reserves and national parks.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Ooty.jpg'),
(278, 15, '\nPondicherry  Come here to experience the French magic still felt here in the food and its culture.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Pondicherry.jpg'),
(279, 15, ' the famous Rameshwaram temple visited by thousands of devotees every year.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Rameswaram.jpg'),
(280, 15, 'The temple is considered the first prominent Vishnu temples and also one of popular tourist places.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Srirangam.jpg'),
(281, 15, 'Brihadeshwara Temple, Thanjavur: built by Chola Emperor in a fascinating way .', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Thanjavur.jpg'),
(282, 15, ' Vaishnava temple, the temple comprises of Lord Vishnu and Goddess Lakshmi as main idols.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Tiruchirappalli.jpg'),
(283, 15, 'Tirunelveli, also known as Nellai and historically as Tinnevelly, is a major city.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Tirunelveli.jpg'),
(284, 15, 'Monkey Falls is a famous and popular tourism spot. Located on road connecting Pollachi and Valparai.', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Valparai.jpg'),
(285, 15, 'The history of the District assumes great significance & relevance, as we unfold the glorious past. ', 'http://itourscloud.com/destination_gallery/asia/india/tamil_nadu/Asia_India_TN_Vellore.jpg'),
(286, 16, 'Agra has earned fame for being heritage in the country. Reflecting the architecture of Mughal Era.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Agra.jpg'),
(287, 16, 'Sir Syed & Strachey Hall, Mushtaq Manzil, Asman Manzil, Nizam Museum,Lytton Library are attractions.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Aligarh.jpg'),
(288, 16, 'ALLAHABAD FORT, UTTAR PRADESH â€“ A MAJESTIC REPOSITORY OF HISTORY', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Allahabad.jpg'),
(289, 16, 'Ayodhya, the ancient city, sacred cities of Hinduism, as it is the birthplace of Lord Rama. ', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Ayodhya.jpg'),
(290, 16, 'Three destinations Varanasi, Chunar, and Vindhyachal and these cities have their own beauty.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Chunar.jpg'),
(291, 16, 'India Gate, Delhi, New Delhi, Uttar Pradesh, India .', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Delhi.jpg'),
(292, 16, 'Gulab Bari, the rose garden is one of the most beautiful gardens in town.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Faizabad.jpg'),
(293, 16, 'Fatehpur Sikri, the 16th century city, was built by the renowned Mughal emperor Akbar. ', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Fatehpur_Sikri.jpg'),
(294, 16, 'Govardhan is in the hilly terrain of the hill Giriraj, place has many tales of Lord Krishna.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Govardhan.jpg'),
(295, 16, 'Jama Masjid, situated in Jaunpur, forms a prime religious as well as tourist site of the state.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Jaunpur.jpg'),
(296, 16, 'Jim Corbett National Park: Wildlife Sanctuary in Uttarakhand State is the oldest national park. ', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Jim Corbett_National_Park.jpg'),
(297, 16, 'The capital of Uttar Pradesh and famously referred to as The city of Nawabs,Lucknow', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Lucknow.jpg'),
(298, 16, 'Mathura is the birthplace of Lord Krishna and it is amongst the sacred cities of Hinduism.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Mathura.jpg'),
(299, 16, 'Noida is a planned city in Indiaâ€™s northern state of Uttar Pradesh.\n', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Noida.jpg'),
(300, 16, 'Orchha town , with its fascinating temples and palaces, revealing tales of battles between kings.\n', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Orchha.jpg'),
(301, 16, 'Sarnath, famous as the site where Gautama Buddha first taught the Dharma.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Sarnath.jpg'),
(302, 16, 'Religious Capital of India as Varanasi is called, pilgrims done from various parts of the world.', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Varanasi.jpg'),
(303, 16, 'Vrindavan, the place where Lord Krishna is said to have spent his childhood.\n', 'http://itourscloud.com/destination_gallery/asia/india/uttar_radesh/Asia_India_UP_Vrindavan.jpg'),
(304, 17, 'Almora, popular hill station of Uttarakhand is known as the cultural capital of Kumaon.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Almora.jpg'),
(305, 17, 'Badrinath Dham is one of the oldest of Hindu places of worship.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Badrinath.jpg'),
(306, 17, ' Dehradun, Nestled in the mountain ranges of the Himalayas, Dehradun is the capital of Uttarakhand.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Dehradun.jpg'),
(307, 17, 'The main religious places among theChar Dham pilgrimage areas, Gangotri, situated in Uttarkashi.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Gangotri.jpg'),
(308, 17, 'Haridwar is the gateway to the four pilgrimages of Uttarakhand. ', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Haridwar.jpg'),
(309, 17, 'Jageshwar, there are 124 temples that are located in the town and include small & large temple.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Jageshwar.jpg'),
(310, 17, 'Jyotirmath, The place is revered by Hindus and it is an important pilgrimage center in the country.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Jyotirmath.jpg'),
(311, 17, 'Kedarnath in the state of Uttarakhand boast of unparallel credentials in the religious arena.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Kedarnath.jpg'),
(312, 17, 'Hilly topography with fruit orchards Mukteshwar, the name derived from Lord Shiva,who offers Moksha.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Mukteshwar.jpg'),
(313, 17, 'Mussoorie, Queen of the Hills, located some 290 km north, is among the most popular hill stations.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Mussoorie.jpg'),
(314, 17, 'One of the most popular and exquisite hill station "Nainital" is located in the Kumaon region.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Nainital.jpg'),
(315, 17, 'Ranikhet has everything to pacify the nerves of an avid city dweller.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Ranikhet.jpg'),
(316, 17, 'Rishikesh, a place in northern Uttar Pradesh, surrounded by hills and bisected by the wide Ganges.', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Rishikesh.jpg'),
(317, 17, 'Srinagar is a beautiful city Pauri Garhwal Uttarakhand. ', 'http://itourscloud.com/destination_gallery/asia/india/uttarakhand/Asia_India_Uttakhand_Srinagar.jpg'),
(318, 18, 'Bakkhali Beach The long, wide beach of Bakkhali stretches from Bakkhali to Frazergunj.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Bakkhali.jpg'),
(319, 18, 'Madanmohan Mandir In Bankura District, West Bengal.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Bankura.jpg'),
(320, 18, 'Curzon Gate One of the popular tourist sites in Bardhaman, the beauty is spellbinding.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Bardhaman.jpg'),
(321, 18, 'Bishnupur has a glorious past that is reflected in its rich architecture, music and handicrafts.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Bishnupur.jpg'),
(322, 18, 'West Bengal', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Cooch Behar.jpg'),
(323, 18, 'Cooch Behar is one of the important destinations to visit in the Indian state of West Bengal.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Dakshineswa.jpg'),
(324, 18, 'Darjeeling is in the Indian state of West Bengal, is internationally famous for its tea industry.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Darjeeling.jpg'),
(325, 18, 'Ghum, The place is the home of the Ghum Monastery and the Batasia Loop.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Ghum.jpg'),
(326, 18, 'Howrah Bridge is a cantilever bridge with a suspended span over the Hooghly River in West Bengal.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Howrah.jpg'),
(327, 18, 'DAKSHINESWAR KALI TEMPLE KOLKATA:  celebration, festival, religion and spiritualism.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Kalighat.jpg'),
(328, 18, 'Victoria Memorial, a massive structure of white-marble dedicated to Queen Victoria.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Kolkata.jpg'),
(329, 18, 'The Lava Monastery or Lava Kagyu Thekchen Ling Monastery & Retreat Centre is sion top of a hill.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Lava.jpg'),
(330, 18, 'There are many places of interest in Maithon such as Kalyaneswari Temple, Maithon Dam, Panchet Dam.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Maithon.jpg'),
(331, 18, 'Mayapur a very holy and sacred place is located on the banks of the Ganges river.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Mayapur.jpg'),
(332, 18, 'Santiniketan is a home to Ranbindranath Tagore.', 'http://itourscloud.com/destination_gallery/asia/india/west_bengal/Asia_India_West Bengal_Santiniketan.jpg'),
(333, 19, 'Ayutthaya temples, stone ruins and Buddha statues in the old capital of Thailand.', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Ayuthaya.jpg'),
(334, 19, 'Biggest and popular of all floating markets, mainly to foreign visitors and is still a must-see.', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Floating_Markets.jpg'),
(335, 19, 'The city of Kanchanaburi is a microcosm of what makes Thailand such an interesting country. ', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Kanchanaburi.jpg'),
(336, 19, 'Khao Yai National Park is a scenic and green nation park in Bangkok.', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Khao_Yai_National_Park.jpg'),
(337, 19, 'Koh Larn: The beach is probably more beautiful and has a nicer vibe.', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Koh_Larn.jpg'),
(338, 19, ' \n\nSafari World; a tourist attraction in Bangkok,  parks named Marine Park and Safari Park.', 'http://itourscloud.com/destination_gallery/asia/bangkok/Asia_bangkok_Safari_World.jpg'),
(339, 20, 'Beijing, Chinaâ€™s massive capital, has history stretching back 3 millennia. ', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_Beijing.jpg'),
(340, 20, 'Great Wall of China is one of the attractions around the world owing to its architectural grandeur.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_Great_Wall_of_China.jpg'),
(341, 20, 'Hangzhou is the capital of Zhejiang Province and one of the seven ancient capitals of China.', 'http://itourscloud.com/destination_gallery/asia/china/\nAsia_china_Hangzhouchina.jpg'),
(342, 20, 'Hong Kong great city for an adventurous eater with huge sky touching buildings with modern autonomy.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_hong_kong_china.jpg'),
(343, 20, 'Jiuzhaigou National Park is a network of valleys in Chinaâ€™s Sichuan province.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_Jiuzhaigou_china.jpg'),
(344, 20, 'Kunming, the modern capital city and transportation hub of China southern Yunnan province.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_kunming_china.jpg'),
(345, 20, 'Fascinated with beautiful natural scenery, travel with your kids to the Spring City Kunming.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_kunming_Yangshuo_china.jpg'),
(346, 20, ' Lhasa is a jewel of a destination. Potala Palace, the former residence of the Dalai Lama.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_lhasa_china.jpg'),
(347, 20, 'The fortifications of Xian , also known as Xian City Wall, in Xian, an ancient capital of China.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_Xi''an_china.jpg'),
(348, 20, ' must visit while in Shanghai is the 468-meter-tall Oriental Pearl Radio & TV Tower  in Pudong-Park.', 'http://itourscloud.com/destination_gallery/asia/china/Asia_china_Xi''Shanghai_china.jpg'),
(349, 21, ' world largest Hindu temple in Combodia Angkor Wat.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_Angkor_Wat.jpg'),
(350, 21, 'Banteay Srei is a 10th-century Cambodian temple dedicated to the Hindu god Shiva.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_banteay_srei.jpg'),
(351, 21, 'The Bayon is a well-known and richly decorated Khmer temple at Angkor in Cambodia.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_Bayon_Temple.jpg'),
(352, 21, 'Bokor Hill Station refers to a collection of French colonial building.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_bokor_hill_station.jpg'),
(353, 21, 'The main structure, Koh Ker Temple, is a stepped 7-tiered pyramid.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_koh_ker.jpg'),
(354, 21, 'Kratie is one of the four provinces in northeastern Cambodia.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_kratie.jpg'),
(355, 21, 'Preah Vihear Temple is an ancient Hindu temple built during the period of the Khmer Empire.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_preah_vihear.jpg'),
(356, 21, 'Sihanoukville Beaches. - The Cambodia Beach and Seaside.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_sihanoukville.jpg'),
(357, 21, 'The Silver Pagoda is located on the south side of the Royal Palace, Phnom Penh.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_silver_pagoda.jpg'),
(358, 21, 'TonlÃ© Sap refers to a seasonally inundated freshwater lake, the TonlÃ© Sap Lake.', 'http://itourscloud.com/destination_gallery/asia/combodia/Asia_combodia_tonle_Sap.jpg'),
(359, 22, 'Hong Kong - Shenzhen - Macau.', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Macau.jpg'),
(360, 22, 'Main Temple of Po Lin Monastery of Ngong Ping.', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Po_Lin_Monastery.jpg'),
(361, 22, 'Sai Kung Hoi was a fishing harbour and fishermen still gather there..', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Sai_Kung.jpg'),
(362, 22, 'Shenzhen is located in Guangdong province, adjacent to Hong Kong \n', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Shenzhen.jpg'),
(363, 22, 'Tokyo Cheung Chau, Hongkong.', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Tokyo_Cheung_Chau.jpg'),
(364, 22, 'Hong Kong Disneyland is a theme park located on reclaimed land in Penny Bay.', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Tokyo_Disneyland.jpg'),
(365, 22, 'Guangzhou is the stronghold of the worldâ€™s most popular style of Chinese cooking.', 'http://itourscloud.com/destination_gallery/asia/hongkong/Asia_hongkong_Tokyo_Guangzhou.jpg'),
(366, 23, 'Barabudur is a 9th-century Mahayana Buddhist temple in Magelang, Central Java, Indonesia.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Borobudur.jpg'),
(367, 23, 'Candi Plaosan, is one of the Buddhist temples located in Bugisan village.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Candi_Plaosan.jpg'),
(368, 23, 'Indonesia', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_one.jpg'),
(369, 23, 'Prambanan or Rara Jonggrang is a 9th-century Hindu temple compound in Central Java.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Prambanan.jpg'),
(370, 23, 'Pura Besakih, a temple in the village of Besakih on the slopes of Mount Agung in eastern Bali.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Pura_Besakih.jpg'),
(371, 23, 'Uluwatu Temple is a Balinese sea temple in Uluwatu.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Pura_Luhur_Uluwatu.jpg'),
(372, 23, 'Pura Ulun Danu Beratan, or Pura Bratan, is a major Shaivite water temple on Bali, Indonesia.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Pura_Ulun_Danu_Beratan.jpg'),
(373, 23, 'Ratu Boko or Ratu Boko Palace is an archaeological site in Java.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Ratu_Boko_Temple.jpg'),
(374, 23, 'Sewu is an eighth century Mahayana Buddhist temple in Indonesia.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Sewu_Temple.jpg'),
(375, 23, 'Tanah Lot is a rock formation off the Indonesian island of Bali.', 'http://itourscloud.com/destination_gallery/asia/indonesia/Asia_Indonesia_Tanah_Lot.jpg'),
(376, 24, 'Kandovan, village exemplifies manmade cliff dwellings which are still inhabited. ', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran__Kando_an_village.jpg'),
(377, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Abyaneh_village.jpg'),
(378, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Esfahan_bridges.jpg'),
(379, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Esfahan_city_center.jpg'),
(380, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Masuleh_village.jpg'),
(381, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Persepolis.jpg'),
(382, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Tabriz_bazaar.jpg'),
(383, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Traditional_houses_in_Kashan.jpg'),
(384, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_US_Den_of_Espionage.jpg'),
(385, 24, 'Iran', 'http://itourscloud.com/destination_gallery/asia/iran/Asia_Iran_Wind_catchers_in_Yazd.jpg'),
(386, 25, 'Hiroshima is the capital of Hiroshima Prefecture and the largest city in the ChÅ«goku.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Hiroshima.jpg'),
(387, 25, 'Ishigaki is a city on Japan Ishigaki Island and a jumping-off point for beaches and coral reefs.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Ishigaki.jpg'),
(388, 25, 'Kamakura is a seaside Japanese city just south of Tokyo. The political center of medieval Japan.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Kamakura.jpg'),
(389, 25, 'Kanazawa is the capital of Ishikawa Prefecture, on Japanâ€™s central Honshu Island.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Kanazawa.jpg'),
(390, 25, 'Mount KÅya is the name of mountains in Wakayama Prefecture to the south of Osaka.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Koya_san.jpg'),
(391, 25, 'Kyoto, famous for its numerous classical Buddhist temples, as well as gardens, imperial palaces.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Kyoto.jpg'),
(392, 25, 'Nara, The city has significant temples and artwork dating to the 8th century.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Nara.jpg'),
(393, 25, 'Nikko is a small city in Japanâ€™s Tochigi Prefecture, in the mountains north of Tokyo.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Nikko.jpg'),
(394, 25, 'Takayama is a city in Japans mountainous Gifu Prefecture. The narrow streets of its Sanmachi Suji.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Takayama.jpg'),
(395, 25, 'Tokyo, Japanâ€™s busy capital, mixes the ultramodern and the traditional, from neon-lit skyscrapers.', 'http://itourscloud.com/destination_gallery/asia/japan/Asia_japan_Tokyo.jpg'),
(396, 26, 'Kuwait that has a good range of pools, floats and slides.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Al_Messila_Water_Village.jpg'),
(397, 26, 'Al Shaheed Park is the largest urban park in Kuwait.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Al_Shaheed_Park.jpg'),
(398, 26, 'Graceful buildings in Kuwait reflect the commitment to community in the country past and future. ', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Amricani_Cultural_Centre.jpg'),
(399, 26, 'Large-scale bayside water-park with colorful flumes, slides & pools.\n', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Aqua_Park.jpg'),
(400, 26, 'Bait Al-Othman is a historic museum in Kuwait located in Hawalli. ', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Bait_Al_Othman_Museum.jpg'),
(401, 26, 'Bayan Palace is the main palace of the Emir of Kuwait. It is located in the Bayan area.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Bayan_Palace.jpg'),
(402, 26, 'The Green Island is an artificial island in Kuwait, off the coast of Kuwait Citys promenade.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Green_Island.jpg'),
(403, 26, 'Kuwait Scientific Center: Movie theater chain known for presenting 3D films on a giant screen.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Kuwait_Scientific_Center.jpg'),
(404, 26, 'Kuwait Zoo, one of the places that will keep the visitors-bounded every time they see the animals.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Kuwait_Zoo.jpg'),
(405, 26, 'The Liberation Tower is a 372-meter-high telecommunications tower in Kuwait City.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Liberation_Tower.jpg'),
(406, 26, 'This musical dancing fountain is one of the world largest fountains and is located in Kuwait City.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Musical_Fountain.jpg'),
(407, 26, 'Museum & cultural center displaying weavings & other Bedouin handicrafts in a traditional house.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Sadu_House.jpg'),
(408, 26, 'Museum with a collection of over 30,000 items relating to Islamic art & calligraphy.', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_Tareq_Rajab_Museum.jpg'),
(409, 26, ' The Only House in the World entirely covered with Mirror Mosaic by a single artist! ', 'http://itourscloud.com/destination_gallery/asia/kuwait/Asia_Kuwait_The_Mirror_House.jpg'),
(410, 27, 'The Aquaria KLCC is an oceanarium located beneath Kuala Lumpur Convention Centre .', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Aquaria_KLCC.jpg'),
(411, 27, 'Batu Caves is a limestone hill that has a series of caves and cave temples in Gombak.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Batu_Caves.jpg'),
(412, 27, 'Berjaya Times Square Theme Park is an indoor theme park on the 5th to 8th floors .', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Berjaya_Times_Square_Theme_Park.jpg'),
(413, 27, 'Fort Cornwallis, a star fort in George Town, Malaysia, built by the British East India Company.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Fort_Cornwallis.jpg'),
(414, 27, 'Genting Highlands, an integrated resort having hotels, casinos, shopping malls and a theme park .', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Genting_Highlands.jpg'),
(415, 27, 'Gunung Mulu National Park is a protected rainforest in Malaysian Borneo.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Gunung_Mulu_National_Park.jpg'),
(416, 27, 'The Islamic Arts Museum Malaysia was officially opened on 12 December 1998.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Islamic_Arts_Museum_Malaysia.jpg'),
(417, 27, 'The Kek Lok Si Temple is a Buddhist temple situated in Air Itam in Penang facing the sea.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Kek_Lok_Si.jpg'),
(418, 27, 'The Khoo Kongsi is a large Chinese clanhouse with elaborate and highly ornamented architecture.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Khoo_Kongsi.jpg'),
(419, 27, 'Kinabalu Park, established as one of the first national parks of Malaysia in 1964.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Kinabalu_Park.jpg'),
(420, 27, 'The KLCC Park is a public park located in the vicinity of Suria KLCC, Kuala Lumpur,.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_KLCC_Park.jpg'),
(421, 27, 'The Kuala Lumpur Tower is a communications tower located in Kuala Lumpur, Malaysia.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Kuala Lumpur Tower.jpg'),
(422, 27, 'Kuala Lumpur Bird Park is a 20.9-acre public aviary in Kuala Lumpur, Malaysia.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Kuala_Lumpur_Bird_Park.jpg'),
(423, 27, 'Langkawi Sky Bridge is a 125-metre (410 ft) curved pedestrian cable-stayed bridge in Malaysia.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Langkawi Sky Bridge.jpg'),
(424, 27, 'The Langkawi Cable Car, also known as Langkawi SkyCab, is one of the major attractions.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Langkawi_Cable_Car.jpg'),
(425, 27, 'Mabul is a small island off the south-eastern coast of Sabah in Malaysia. ', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Mabul_Island.jpg'),
(426, 27, 'Mount Kinabalu is a mountain in Sabah, Malaysia. It is protected as Kinabalu Park.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Mount_Kinabalu.jpg'),
(427, 27, 'A national mosque in Kuala Lumpur, Malaysia. It has a capacity for 15,000 people.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_National_Mosque_of_Malaysia.jpg'),
(428, 27, 'Malaysia', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_one.jpg'),
(429, 27, 'Pangkor Island lies west coast of Peninsular Malaysia. Itâ€™s known for beaches like Teluk Nipah.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Pangkor_Island.jpg'),
(430, 27, 'Penang Hill is a hill resort comprising a group of peaks on Penang Island, Malaysia. ', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Penang_Hill.jpg'),
(431, 27, 'The Petronas Towers, also known as the Petronas Twin Towers, are twin skyscrapers in Kuala Lumpur.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_petronas_twin_tower.jpg'),
(432, 27, 'The Putra Mosque is the principal mosque of Putrajaya, Malaysia. ', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Putra_Mosque.jpg'),
(433, 27, 'Redang Island, It is one of the largest islands off the east coast of Peninsular Malaysia.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Redang_Island.jpg'),
(434, 27, 'The Sultan Abdul Samad Building is a late nineteenth century building.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Sultan_Abdul_Samad_Building.jpg'),
(435, 27, 'Taman Negara is a vast national park in Malaysia on the Malay peninsula.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Taman_Negara.jpg'),
(436, 27, 'The Tunku Abdul Rahman National Park comprises a group of 5 islands.', 'http://itourscloud.com/destination_gallery/asia/malaysia/Asia_Malaysia_Tunku_Abdul_Rahman_National_Park.jpg'),
(437, 28, 'Dharavandhoo is one of the best islands of Baa Atoll and is surrounded by clear waters.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Dharavandhoo.jpg'),
(438, 28, 'Dhigurah Island is situated at the southern tip of Ari Atoll. Dhigurah means long .', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Dhigurah.jpg'),
(439, 28, 'Immerse yourself in the pristine tropical beauty of this remote island hideaway.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Giraavaru.jpg'),
(440, 28, 'Hanimaadhoo, Resort beach in Malaysia.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Hanimaadhoo.jpg'),
(441, 28, 'Himmafushi Island in Malaysia.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Himmafushi.jpg'),
(442, 28, 'Hithadhoo beach in Maldives.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Hithadhoo.jpg'),
(443, 28, 'Keyodhoo beach in Maldives.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Keyodhoo.jpg'),
(444, 28, 'Maafushi beach in Maldives.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Maafushi.jpg'),
(445, 28, 'The golden dome of this impressive modern mosque dominates the skyline of Male .', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Male_Friday_Mosque.jpg'),
(446, 28, 'Mathiveri beach in Maldives.', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Mathiveri.jpg'),
(447, 28, 'Maldives', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_one.jpg'),
(448, 28, 'Maldives', 'http://itourscloud.com/destination_gallery/asia/maldives/Asia_Malaysia_Two.jpg'),
(449, 29, 'The Ananda Temple located in Bagan, Myanmar is a Buddhist temple built in 1105 AD.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Ananda_Temple.jpg'),
(450, 29, 'The Bagan Archaeological Museum was opened on 17th April 1998 in the world.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Bagan_Archaeological_Museum.jpg'),
(451, 29, 'The Botataung Pagoda is a famous pagoda located in downtown Yangon, Myanmar.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Botataung_Pagoda.jpg'),
(452, 29, 'Chaukhtatgyi Buddha Temple is the most well-known Buddhist temple in Bahan.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Chauk-htat-gyi_Buddha_Temple.jpg'),
(453, 29, 'Burmese pagodas are stupas; typically house Buddhist relics, associated with Buddha. ', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Dhammayazika_Pagoda.jpg'),
(454, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Five.jpg'),
(455, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Four.jpg'),
(456, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Gawdawpalin_Temple.jpg'),
(457, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Gu_Byauk_Gyi.jpg'),
(458, 29, 'Ananda Temple is one of the four main temples remaining in Bagan.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Htilominlo_Temple.jpg'),
(459, 29, 'Inle Lake is a freshwater lake located in the Nyaungshwe Township of Taunggyi .', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Inle_lake.jpg'),
(460, 29, 'The Kaba Aye paya or â€œWorld peace pagodaâ€ is a relatively recent pagoda in Yangon. ', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Kaba_Aye_Pagoda.jpg'),
(461, 29, 'Kandawgyi Lake, is one of two major lakes in Yangon, Burma. ', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Kandawgyi_Lake.jpg'),
(462, 29, 'The Kaunghmudaw Pagoda is a large pagoda on the northwestern outskirts of Sagaing in Myanmar. ', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Kaunghmudaw_Pagoda.jpg'),
(463, 29, 'Lawkananda Pagoda is a Buddhist zedi located in Bagan, Burma.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Lawkananda_Pagoda.jpg'),
(464, 29, 'Mount Popa is a volcano 1518 metres above sea level, and located in central Myanmar.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Mount_Popa.jpg'),
(465, 29, 'Namdapha National Park is the largest protected area in the Eastern Himalaya biodiversity .', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Namdapha_National_Park.jpg'),
(466, 29, 'Nanpaya Temple is a Hindu temple located in Myinkaba in Burma.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Nanpaya_Temple.jpg'),
(467, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_National_Kandawgyi_Botanical_Gardens.jpg'),
(468, 29, 'The National Museum, located in Dagon, Yangon, is the one of the national museum of Burmese art.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_National_Museum_of_Myanmar.jpg'),
(469, 29, 'Myanmar Gems Museum, located at in Yangon,is a museum dedicated to precious Burmese gem stones.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_one.jpg'),
(470, 29, 'Burma Pindaya Caves,  are a Buddhist pilgrimage site and a tourist attraction.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Pindaya_Caves.jpg'),
(471, 29, 'Sai Yok National Park is a national park in Sai Yok district.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Sai_Yok_National_Park.jpg'),
(472, 29, 'No visit to the Myanmar is complete without a visit to the 2,500 years old Shwedagon Pagoda.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Shwedagon Pagoda.jpg'),
(473, 29, 'Shwezigon was built as the most important reliquary shrine in Bagan, a centre of prayer.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Shwezigon_Pagoda.jpg'),
(474, 29, 'The Sule Pagoda is a Burmese stupa located in the heart of downtown .', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Sule_Pagoda.jpg'),
(475, 29, 'Thatbyinnyu Temple, Sabbannu or "the Omniscient", is a famous temple located in Bagan.', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Thatbyinnyu_Temple.jpg'),
(476, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Three.jpg'),
(477, 29, 'Myanmar', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Two.jpg'),
(478, 29, 'Burma Uppatasanti Pagoda: The pagoda houses a Buddha tooth relic from China. ', 'http://itourscloud.com/destination_gallery/asia/myanmar/Asia_Myanmar_Burma_Uppatasanti_Pagoda.jpg'),
(479, 30, 'The Annapurna Conservation Area is Nepal largest protected area covering 7,629 km2 .', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Annapurna_Conservation_Area.jpg'),
(480, 30, 'Bardia National Park is the largest untouched wilderness in the Terai region of Nepal.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Bardiya_National_Park.jpg'),
(481, 30, 'Boudhanath Stupa (or Bodnath Stupa) is the largest stupa in Nepal and the holiest Tibetan Buddhist.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Boudhanath.jpg'),
(482, 30, 'The Central Zoo is a 6-hectare zoo in Jawalakhel, Nepal. It is home to some 870 animals.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Central_Zoo.jpg'),
(483, 30, 'Chitwan National Park is a preserved area in the Terai Lowlands of south-central Nepal.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Chitwan_National_Park.jpg'),
(484, 30, 'Davi Falls or Devi Falls is a waterfall located at Pokhara in Kaski District, Nepal.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Davis_Falls.jpg'),
(485, 30, 'Kathmandu Durbar Square in front of the old royal palace of the former Kathmandu Kingdom.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Durbar_Square.jpg'),
(486, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Eight.jpg'),
(487, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Five.jpg'),
(488, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Four.jpg'),
(489, 30, 'Kala Patthar, meaning black rock in Nepali and Hindi, is a notable landmark.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Kala_Patthar.jpg'),
(490, 30, 'Kathmandu Durbar Square of Nepal is one of the famous square since kingdom.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Kathmandu_Durbar_Square.jpg'),
(491, 30, 'Machhapuchhre, is a mountain in the Annapurna Himalayas of north central Nepal.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Machapuchare.jpg'),
(492, 30, 'The Manakamana Templein Gorkha district of Nepal is the sacred place of the Hindu Goddess Bhagwati.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Manakamana.jpg'),
(493, 30, 'Muktinath is a sacred place for both Hindus and Buddhists located in Muktinath Valley.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Muktinath.jpg'),
(494, 30, 'Narayanhiti Durbar is a palace in Kathmandu, which long served as residence .', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Narayanhity_Palace.jpg'),
(495, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Nepal.jpg'),
(496, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Nine.jpg'),
(497, 30, 'The Pashupatinath Temple is a famous, sacred Hindu temple dedicated to Pashupatinath.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Pashupatinath_Temple.jpg'),
(498, 30, 'Sagarmatha National Park is a protected area in the Himalayas of northeast Nepal. .', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Sagarmatha_National_Park.jpg'),
(499, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Seven.jpg'),
(500, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Six.jpg'),
(501, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Ten.jpg'),
(502, 30, 'Tengboche Monastery, also known as Dawa Choling Gompa, in the Tengboche village.', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Tengboche_Monastery.jpg'),
(503, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Three.jpg'),
(504, 30, 'Nepal', 'http://itourscloud.com/destination_gallery/asia/nepal/Asia_Nepal_Two.jpg'),
(505, 31, 'Panwa Beach, also known as Khao Kat Beach, is not a swimming beach, and yet has the charm.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Cape_Panwa.jpg'),
(506, 31, 'Kamala Beach is a quieter stretch of sand with a more relaxed feel.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Kamala.jpg'),
(507, 31, 'Karon Beach features the third-longest beach on Phuket Island.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Karon.jpg'),
(508, 31, 'The pleasant bay of Kata, just a few minutes south of Karon Beach.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Kata_phuket.jpg'),
(509, 31, 'Mai Khao is a beach on the northwestern side of Phuket, Thailand. It is also known as Airport Beach.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Mai_Khao.jpg'),
(510, 31, 'Hat Nai Han beach is a very small but beautiful beach located at south-western Phuket.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Nai_Han.jpg'),
(511, 31, 'Patong is the most famous beach resort on Phuket. With its wide variety of activities and nightlife.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Patong.jpg'),
(512, 31, 'Rawai is a working beach and a launching point for day boat excursions out to Phuket.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Rawai.jpg'),
(513, 31, 'Surin Beach; good reason; plenty of dining venues and beach clubs along a large beach with a sand.', 'http://itourscloud.com/destination_gallery/asia/phuket/Asia_phuket_Hat_Surin.jpg'),
(514, 32, ' The Al Jassasiya site is one of the most mysterious and attractive sites in Qatar. ', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Al_Jassasiya_Carvings.jpg'),
(515, 32, ' Al Wakra Museum is one of the most popular Qatar Attraction highlights countrys architecture.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Al_Wakra_Museum.jpg'),
(516, 32, 'Az Zubara Fort, is a historic Qatari military fortress built.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Al_Zubarah_Fortress.jpg'),
(517, 32, 'Barzan Towers, also known as the Umm Salal Mohammed Fort Towers, ', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Doha_Barzan_Towers.jpg'),
(518, 32, 'Enjoy a full-day safari in the golden sands of Qatarâ€™s desert on this tour from Doha. ', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Doha_Desert.jpg'),
(519, 32, 'A true Gem in Katara. It was built and decorated well.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Doha_Katara_Mosque.jpg'),
(520, 32, 'Imam Muhammad ibn Abd al-Wahhab Mosque is the national mosque of Qatar.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Doha_State_Grand_Mosque.jpg'),
(521, 32, 'The Museum of Islamic Art is a museum located on one end of the seven kilometers long Corniche.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_Doha_The_Museum_of_Islamic_Art.jpg'),
(522, 32, 'Qatar, National Museum has welcomed hundreds of curious guests in the past few weeks.', 'http://itourscloud.com/destination_gallery/asia/qatar/Asia_Qatat_The_National_Museum.jpg'),
(523, 33, 'Abdul Raouf Khalil Museum; Museum complex highlighting the city heritage.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Abdul_Raouf_Khalil_Museum.jpg'),
(524, 33, 'The Abraj Al-Bait is a government-owned megatall complex of seven skyscraper hotels in Mecca.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Abraj_Al_Bait.jpg'),
(525, 33, 'AlShallal Theme Park is spread over area of 60,000 sqrmtr in an ideal location on Jeddah Cornish.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Al_Shallal_Theme_Park.jpg'),
(526, 33, 'Al-Masjid an-NabawÄ« is a mosque established and originally built by the Islamic prophet Muhammad.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Al-Masjid an-Nabawi.jpg'),
(527, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Five.jpg'),
(528, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Four.jpg'),
(529, 33, 'Ibrahim Palace, Saudi Arabia to visit historic site in Al Hofuf.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Ibrahim_Palace.jpg');
INSERT INTO `gallary_master` (`entry_id`, `dest_id`, `description`, `image_url`) VALUES
(530, 33, 'King Fahd Fountain also known as the Jeddah Fountain, is a fountain in Jeddah,', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_King_Fahd_Fountain.jpg'),
(531, 33, 'Masjid al-Qiblatayn, or the Mosque of the Two Qiblas, is a mosque in Medina .', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Masjid_al_Qiblatayn.jpg'),
(532, 33, 'The Masmak is a clay and mud-brick fort, with four watchtowers and thick walls.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Masmak_fort.jpg'),
(533, 33, 'Mecca, in a desert valley in western Saudi Arabia, is Islamâ€™s holiest city,.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_mecca.jpg'),
(534, 33, 'Mount Arafah is a granite hill east of Makkah in the plain of Arafat.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Mount_Arafat.jpg'),
(535, 33, 'The National Museum of Saudi Arabia is a major national museum in Saudi Arabia.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_National_Museum_Saudi_Arabia.jpg'),
(536, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_One.jpg'),
(537, 33, 'Safa and Marwa are two small hills now located in the Great Mosque of Mecca in Saudi Arabia.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_safa_marwa.jpg'),
(538, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Salaam_Park_Riyadh.jpg'),
(539, 33, 'City oasis with many palm trees, play equipment, concessions & a large lake with pedal boats.', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Sea_Front.jpg'),
(540, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_Three.jpg'),
(541, 33, 'South Arabia', 'http://itourscloud.com/destination_gallery/asia/south-arabia/Asia_Saudi_Arabia_two.jpg'),
(542, 34, 'The Asian Civilisations Museum is an institution which forms a part of the four museums.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Asian_Civilisations_Museum.jpg'),
(543, 34, 'The Buddha Tooth Relic Temple and Museum is a Buddhist temple and museum complex.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Buddha_Tooth Relic_Temple_Museum.jpg'),
(544, 34, 'The Changi Museum is a museum dedicated to Singapore history during the Second World War .', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Changi_Museum.jpg'),
(545, 34, 'The East Coast Park is a beach park stretching from Marina East to Bedok.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_East_Coast_Park.jpg'),
(546, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Eight.jpg'),
(547, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_fice.jpg'),
(548, 34, 'Universal Studios Singapore is a theme park located within Resorts World Sentosa .', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Five.jpg'),
(549, 34, 'Fort Canning Park, an iconic hilltop landmark has witnessed many of Singapore historical milestones.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Fort_Canning.jpg'),
(550, 34, 'Fountain of Wealth listed by the Guinness Book of Records in 1998 as the largest fountain in world.\n', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Fountain_Of_Wealth.jpg'),
(551, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Four.jpg'),
(552, 34, 'Gardens by the Bay is a nature park spanning 101 hectares of reclaimed land with unreal trees.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Gardens_by_the_Bay.jpg'),
(553, 34, 'The Helix Bridge(Double Helix) Bridge, is a pedestrian bridge joins Mamrina Bay.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Helix_Bridge.jpg'),
(554, 34, 'Jurong Bird Park is an aviary and tourist attraction in Jurong, Singapore. ', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Jurong_Bird_Park.jpg'),
(555, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Kaaba.jpg'),
(556, 34, 'The National Gallery Singapore is an art gallery located in the Downtown Core of Singapore.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_National_Gallery_Singapore.jpg'),
(557, 34, 'The National Museum of Singapore is the oldest museum in Singapore. ', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_National_Museum.jpg'),
(558, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_One.jpg'),
(559, 34, 'Orchard Road is Singaporeâ€™s retail heart, with discount outlets, department stores .', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Orchard_Road.jpg'),
(560, 34, 'The River Safari is a river-themed zoo and aquarium located in Singapore.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_River_Safari.jpg'),
(561, 34, 'Large aquarium & resort featuring 800 species of marine life in a variety of habitats.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_SEA_Aquarium.jpg'),
(562, 34, 'Half-fish and half-lion, the iconic Merlion resides at the waterfront Merlion Park.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Seven.jpg'),
(563, 34, 'The Singapore Flyer is a giant Ferris wheel in Singapore. ', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Singapore_Flyer.jpg'),
(564, 34, 'The Night Safari is the world 1st zoo & is one of the popular tourist attractions in Singapore.', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Six.jpg'),
(565, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Three.jpg'),
(566, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Two.jpg'),
(567, 34, 'Underwater World, also known as Underwater World Singapore Pte Ltd, ', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Underwater_World_Singapore.jpg'),
(568, 34, 'Singapore', 'http://itourscloud.com/destination_gallery/asia/singapore/Asia_Singapore_Wings_Of_Time.jpg'),
(569, 35, 'Adams Peak is a 2,243 m tall conical mountain located in central Sri Lanka. ', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Adam_Peak.jpg'),
(570, 35, 'Bundala National Park is an internationally wintering ground for migratory water birds in Sri Lanka.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Bundala_National_Park.jpg'),
(571, 35, 'Gangaramaya Temple is one of the most important temples in Colombo, Sri Lanka.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Eight.jpg'),
(572, 35, 'Isurumuniya is a Buddhist temple situated near to the Tissa Wewa in Anuradhapura, Sri Lanka.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Eleven.jpg'),
(573, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Five.jpg'),
(574, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Four.jpg'),
(575, 35, 'Gangaramaya Temple is one of the most important temples in Colombo, ', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Gangaramaya_Buddhist_Temple.jpg'),
(576, 35, 'Isurumuniya is a Buddhist temple situated near to the Tissa Wewa in Anuradhapura.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Isurumuniya.jpg'),
(577, 35, 'Koneswaram temple is a classical-medieval Hindu temple dedicated to Lord Shiva.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Koneswaram_temple.jpg'),
(578, 35, ' Buddha statue at Lungshan Temple of Manka is a must to watch.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Lungshan_Temple_of_Manka.jpg'),
(579, 35, 'National Museum of Colombo, also known as the Sri Lanka National Museum.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_National_Museum_of_Colombo.jpg'),
(580, 35, 'National Zoological Gardens, Its sprawling areas are host to a variety of animals and birds. ', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_National_Zoological_Gardens.jpg'),
(581, 35, 'Pinnawala Elephant Orphanage,an orphanage nursery  for wild Asian elephants', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Nine.jpg'),
(582, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_One.jpg'),
(583, 35, 'Pinnawala Elephant Orphanage,an orphanage nursery  for wild Asian elephants.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Pinnawala_Elephant_Orphanage.jpg'),
(584, 35, 'Royal Botanic Gardens, Peradeniya are about 5.5 km to the west of the city of Kandy.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Royal_Botanical_Gardens_Peradeniya.jpg'),
(585, 35, 'The Ruwanwelisaya is a stupa, a hemispherical structure containing relics, in Sri Lanka.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Ruwanwelisaya.jpg'),
(586, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Seven.jpg'),
(587, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Six.jpg'),
(588, 35, 'St. Clairs Falls is one of the widest waterfalls in Sri Lanka ', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_St._Clairs_Falls.jpg'),
(589, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Ten.jpg'),
(590, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Twelve.jpg'),
(591, 35, 'Shrilanka', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Two.jpg'),
(592, 35, 'Udawalawe National Park lies on the boundary of Sabaragamuwa and Uva Provinces.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Udawalawe_National_Park.jpg'),
(593, 35, 'Udawattakele Forest Reserve, often spelled as Udawatta Kele, is a historic forest reserve.', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Udawattakele_Forest_Reserve.jpg'),
(594, 35, 'The Viharamahadevi Park is a public park located in Colombo, next to the National Museum .', 'http://itourscloud.com/destination_gallery/asia/shrilanka/Asia_Shilanka_Viharamahadevi_Park.jpg'),
(595, 36, 'The National Chiang Kai-shek Memorial Hall is a national monument, landmark .', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Chiang Kai_shek_Memorial_Hall.jpg'),
(596, 36, 'The Chimei Museum is a private museum established in 1992 by the Chi Mei Corporation.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Chimei_Museum.jpg'),
(597, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Eight.jpg'),
(598, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Eleven.jpg'),
(599, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Five.jpg'),
(600, 36, 'The Formosan Aboriginal Culture Village is an amusement park in Yuchi Township, Nantou County.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Formosan_Aboriginal_Culture_Village.jpg'),
(601, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Four.jpg'),
(602, 36, 'Fort Galle is a stunning Unesco World Heritage site, just a short drive from Colombo..', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Galle Fort.jpg'),
(603, 36, 'Horton Plains National Park covers a wild stretch of bleak, high-altitude.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Horton_Plains_National_Park.jpg'),
(604, 36, 'Jiufen is a mountain town in northeastern Taiwan, east of Taipei.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Jiufen.jpg'),
(605, 36, 'The Leofoo Village Theme Park is a theme park and a safari located in Guanxi Township.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Leofoo_Village_Theme_Park.jpg'),
(606, 36, 'Lihpao Land is a theme park located in Houli District, Taichung, Taiwan. ', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Lihpao_Land.jpg'),
(607, 36, 'National Palace Museum has a permanent collection of 700,000 pieces of ancient Chinese artifacts.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_National_Palace_Museum.jpg'),
(608, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Nine.jpg'),
(609, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_One.jpg'),
(610, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Seven.jpg'),
(611, 36, 'Shifen Waterfall is a scenic waterfall located in Pingxi District, New Taipei City, Taiwan.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Shifen_Waterfall.jpg'),
(612, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Six.jpg'),
(613, 36, 'The Taipei Fine Arts Museum is a museum in Zhongshan District, Taipei, Taiwan.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Taipei_Fine_Arts_Museum.jpg'),
(614, 36, 'Confucian Temple, listed as the  historical landmark; the most traditional architectural heritage.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Taiwan_Confucian_Temple.jpg'),
(615, 36, 'Taroko National Park one of the nine national parks in Taiwan and was named after the Taroko Gorge.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Taroko_National_Park.jpg'),
(616, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Ten.jpg'),
(617, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Three.jpg'),
(618, 36, '', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Two.jpg'),
(619, 36, 'Xiao Liuqiu Island is a small island off the coast of southwestern Pingtung.', 'http://itourscloud.com/destination_gallery/asia/taiwan/Asia_Taiwan_Xiaoliuqiu.jpg'),
(620, 37, 'CentralWorld is a shopping plaza and complex in Bangkok, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Central_World.jpg'),
(621, 37, 'Chiang Mai Night Safari is a vocational study center building the concept of foresty and wild life.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Chiang_Mai_Night_Safari.jpg'),
(622, 37, 'Elephant Nature Park is a sanctuary and rescue centre for elephants in Mae Taeng District.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Elephant_Nature_Park.jpg'),
(623, 37, 'Erawan National Park in Thailand, northwest of Bangkok, near the Myanmar (Burma) border.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Erawan_National_Park.jpg'),
(624, 37, 'The Grand Palace is a complex of buildings at the heart of Bangkok, Thailand. ', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Grand_Palace.jpg'),
(625, 37, 'Jim Thompson House; housing the art collection of American businessman in Bangkok.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Jim_Thompson_House.jpg'),
(626, 37, 'Jomtien Beach, a long, straight 6km stretch of sandy coastline that is a less chaotic and crowded.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Jomtien_Beach.jpg'),
(627, 37, 'Ko Khao Phing Kan is an island in Thailand, in Phang Nga Bay', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Khao_Phing_Kan.jpg'),
(628, 37, 'Khao Yai National Park is in the western part of the Sankamphaeng Mountain Range.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Khao_Yai_National_Park.jpg'),
(629, 37, 'Ko Pha Ngan is an island in southeast Thailand thatâ€™s renowned for its monthly Full Moon Party.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Ko_Pha_ngan.jpg'),
(630, 37, 'Lumphini Park , The park offers rare open public space, trees, and playgrounds.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Lumphini_Park.jpg'),
(631, 37, 'MBK Center, also known as Mahboonkrong, is a large shopping mall in Bangkok, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_MBK_Center.jpg'),
(632, 37, 'Patong is a beach resort town on the west coast of Phuket Island, facing the Andaman Sea.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Pa_Tong.jpg'),
(633, 37, 'Prasat Hin Phanom Rung, is a Khmer temple complex set on the rim of an extinct volcano.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Phanom_Rung_Historical_Park.jpg'),
(634, 37, 'Thailand', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Phi_Phi_Islands.jpg'),
(635, 37, 'Thailand', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Phimai_Historical_Park.jpg'),
(636, 37, 'The Phi Phi Islands are an island group in Thailand, between the large island of Phuket.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Railay_Beach.jpg'),
(637, 37, 'Safari World is a tourist attraction in Bangkok, Thailand that consists of two parks .', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Safari_World.jpg'),
(638, 37, 'Sanctuary of Truth is a religious construction in Pattaya, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Sanctuary_of_Truth.jpg'),
(639, 37, 'The Sukhothai Historical Park covers the ruins of Sukhothai, literally Dawn of Happiness.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Sukhothai_Historical_Park.jpg'),
(640, 37, 'The nine floors at Terminal 21 house some 600 shops, a Cineplex, Gourmet Market and a food court.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Terminal.jpg'),
(641, 37, 'The Vimanmek Mansion is a former royal villa in Bangkok, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Vimanmek_Mansion.jpg'),
(642, 37, 'Wat Arun is a Buddhist temple (wat) in Bangkok Yai district of Bangkok, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Arun.jpg'),
(643, 37, 'Wat Chedi Luang is a Buddhist temple in the historic centre of Chiang Mai, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Chedi_Luang.jpg'),
(644, 37, 'The Wat Mahathat is a Buddhist temple in Ayutthaya, central Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Mahathat.jpg'),
(645, 37, 'Wat Phra Kaew, commonly known in English as the Temple of the Emerald Buddha.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Phra_Kaew.jpg'),
(646, 37, 'Wat Phra Singh is a Buddhist temple in Chiang Mai, Northern Thailand. ', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Phra_Singh.jpg'),
(647, 37, 'Wat Phra That Doi Suthep is a Theravada wat in Chiang Mai Province, Thailand. ', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Phra_That_Doi_Suthep.jpg'),
(648, 37, 'Wat Rong Khun, perhaps better known to foreigners as the White Temple.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Rong_Khun.jpg'),
(649, 37, 'Wat Saket Ratcha Wora Maha Wihan in Pom Prap Sattru Phai district, Bangkok, Thailand.', 'http://itourscloud.com/destination_gallery/asia/thailand/Asia_Thailand_Wat_Saket.jpg'),
(650, 38, 'Turkey', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_An.jpg'),
(651, 38, 'The Basilica Cistern, is the largest of several hundred ancient cisterns that lie beneath the city.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Basilica_Cistern.jpg'),
(652, 38, ' Martyrs Bridg, is one of the three suspension bridges spanning the Bosphorus strait in Istanbul.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Bosphorus_Bridge.jpg'),
(653, 38, 'The Church of the Holy Saviour in Chora is a medieval Byzantine Greek Orthodox church.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Chora_Church.jpg'),
(654, 38, 'Turkey', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Dolmabahce_Palace.jpg'),
(655, 38, 'DolmabahÃ§e Palace, served as the main administrative center of the Ottoman Empire from 1856.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Galata_Tower.jpg'),
(656, 38, 'The Grand Bazaar in Istanbul is one of the largest and oldest covered markets in the world.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Grand_Bazaar.jpg'),
(657, 38, 'Hagia Sophia was a Greek Orthodox Christian patriarchal basilica, later an imperial mosque & museum.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Hagia_Sophia.jpg'),
(658, 38, 'The House of the Virgin Mary is a Catholic and Muslim shrine located in the vicinity.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_House_of_the_Virgin_Mary.jpg'),
(659, 38, 'The Istanbul Archaeology Museums is a group of three archeological museums.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Istanbul_Archaeology_Museums.jpg'),
(660, 38, 'Caunos is an ancient Carian site located in Dalyan, near Marmaris town.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Kaunos.jpg'),
(661, 38, 'Little Hagia Sophia Mosque, formerly the Church of the Saints Sergius and Bacchus.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Little_Hagia_Sophia.jpg'),
(662, 38, 'The Maidens Tower,  since the medieval Byzantine period, is a tower lying on a small islet.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Maiden_Tower.jpg'),
(663, 38, 'The MevlÃ¢na Museum, is the mausoleum of Jalal ad-Din Muhammad Rumi, a Persian Sufi mystic.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Mevlana_Museum.jpg'),
(664, 38, 'MiniatÃ¼rk is a miniature park situated at the north-eastern shore of Golden Horn in Istanbul.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Miniaturk.jpg'),
(665, 38, 'The Yeni Cami, meaning New Mosque; originally named the Valide Sultan Mosque.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_New_Mosque.jpg'),
(666, 38, 'Pamukkale is a town in western Turkey known for the mineral-rich thermal waters flowing down.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Pamukkale.jpg'),
(667, 38, 'RumelihisarÄ± Castle is a medieval fortress located in the SarÄ±yer district of Istanbul.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Rumelihisar.jpg'),
(668, 38, 'The Spice Bazaar in Istanbul, Turkey is one of the largest bazaars in the city.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Rustem_Pasha_Mosque.jpg'),
(669, 38, 'Turkey', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Spice_Bazaar.jpg'),
(670, 38, 'The SÃ¼leymaniye Mosque is an Ottoman imperial mosque located on the Third Hill of Istanbul.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Suleymaniye_Mosque.jpg'),
(671, 38, 'The Sultan Ahmed Mosque or Sultan Ahmet Mosque is a historic mosque located in Istanbul.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Sultan_Ahmed_Mosque.jpg'),
(672, 38, 'Sumela Monastery is a Greek Orthodox monastery dedicated to the Virgin Mary.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Sumela_Monastery.jpg'),
(673, 38, 'The Temple of Artemis or Artemision, also known less precisely as the Temple of Diana.', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Temple_of_Artemis.jpg'),
(674, 38, 'The TopkapÄ± Palace or the Seraglio, is a large museum in Istanbul, Turkey. ', 'http://itourscloud.com/destination_gallery/asia/turkey/Asia_Turkey_Topkap_Palace.jpg'),
(675, 39, ' Islands, free beaches and private clubs to get some sun and sand in Abu Dhabi. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Al_Sahil_Beach.jpg'),
(676, 39, 'Capital Gate is a skyscraper in Abu Dhabi adjacent to the Abu Dhabi National Exhibition Centre .', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Capital_Gate.jpg'),
(677, 39, 'UAE', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Emirates_Palace.jpg'),
(678, 39, ' United Arab Emirates, Moreeb dunes (Al Moreb Hill) is a place for organised drag races.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Moreeb_Dune.jpg'),
(679, 39, 'National Auto Museum, There is a vast collection of off-road vehicles and classic American cars.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_National_Auto_Museum.jpg'),
(680, 39, 'The Qasr al-Hosn is the oldest stone building in the city of Abu Dhabi, the capital of the UAE.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Qasr_al_Hosn.jpg'),
(681, 39, 'Saadiyat Island is a tourism-cultural project for nature and Emirati heritage and culture. .', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Saadiyat_Island_Cultural_District.jpg'),
(682, 39, 'Sheikh Zayed Bridge is an arch bridge in Abu Dhabi, United Arab Emirates.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Sheikh_Zayed_Bridge.jpg'),
(683, 39, 'Sheikh Zayed Grand Mosque isThe largest mosque in the country.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Sheikh_Zayed_Grand_Mosque.jpg'),
(684, 39, 'Yas Island is a man-made island in Abu Dhabi, UAE. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Yas_Island.jpg'),
(685, 39, 'The Yas Marina Circuit is the venue for the Abu Dhabi Grand Prix..', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_ABU_DHABI_Yas_Marina_Circuit.jpg'),
(686, 39, 'Abu Dhabi is the capital and the second most populous city of the United Arab Emirates .', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Al_Ain_Oasis.jpg'),
(687, 39, 'Garden features; rolling hill, mixed play areas, picnic spots, flower garden & native plant garden.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Al_Ain_Zoo.jpg'),
(688, 39, 'The Al Ain Classic Car Museum is an automotive museum in the United Arab Emirates.\n', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Al_Al_Ain_Classic_Car_Museum.jpg'),
(689, 39, 'Jabal á¸¤afeet is a mountain located in the environs of Al Ain, which is in Emirate of Abu Dhabi.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Al_Jabel_Hafeet.jpg'),
(690, 39, 'The picturesque Al Jahili Fort is one of the UAE most historic buildings. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Al_Jahili_Fort.jpg'),
(691, 39, 'hot water,camping area, green area, man made lake, overnight camping, great place for a picnic. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Mubazzarah_Park.jpg'),
(692, 39, 'Sheikh Zayed Palace Museum is a museum in the city of Al Ain, within the Emirate of Abu Dhabi.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Al_Ain_Palace_Museum.jpg'),
(693, 39, 'Sheikh Zayed Palace Museum is a museum in the city of Al Ain, within the Emirate .', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Al Bastakiya.jpg'),
(694, 39, 'The Burj Al Arab, a luxury hotel in Dubai, UAE. It is the 3rd tallest hotel in the world.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Burj_Al_Arab.jpg'),
(695, 39, 'The Burj Khalifa, known as the Burj Dubai, a megatall skyscraper in Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Burj_Khalifa.jpg'),
(696, 39, 'Deira Clocktower, originally referred to as the Dubai Clocktower, is a roundabout in Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Deira_Clocktower.jpg'),
(697, 39, 'Underwater tunnel under a huge shark- & ray-filled tank, plus a creepy crawly zone with snakes.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Aquarium_Underwater_Zoo.jpg'),
(698, 39, 'Dubai Dolphinarium is the first fully air-conditioned indoor dolphinarium in the Middle East.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Dolphinarium.jpg'),
(699, 39, 'Dubai Gold Souk or Gold Souk, is a traditional market in Dubai, UAE.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Gold_Souk.jpg'),
(700, 39, 'Dubai Marina is an affluent residential neighborhood known for The Beach at JBR.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Marina.jpg'),
(701, 39, 'The Dubai Miracle Garden is a flower garden located in the district of Dubailand, Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Miracle_Garden.jpg'),
(702, 39, 'Dubai Museum is the main museum in Dubai, United Arab Emirates. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Museum.jpg'),
(703, 39, 'Dubai Zoo, 50 year old zoo to be closed soon.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Dubai_Zoo.jpg'),
(704, 39, 'The Etihad Museum collects, preserves, and displays the heritage of the United Arab Emirates.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Etihad_Museum.jpg'),
(705, 39, 'The Grand Mosque is a mosque in Dubai, United Arab Emirates. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Grand_Mosque.jpg'),
(706, 39, 'Jumeirah Beach Hotel is a hotel in Dubai, United Arab Emirates. The hotel, which opened in 1997.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Jumeirah_Beach_Hotel.jpg'),
(707, 39, 'White-sand beach fronted by hotels, resorts, shopping complexes, a waterpark & more.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Jumeirah_Beach_Park.jpg'),
(708, 39, 'Jumeirah Mosque, a mosque in Dubai City. It is said that is the most photographed mosque in Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Jumeirah_Mosque.jpg'),
(709, 39, 'LEGOLANDÂ® Dubai is the ultimate theme park for children 2-12 and their families in the Middle East. ', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Legoland_Dubai.jpg'),
(710, 39, 'Mall of the Emirates is a shopping mall in Dubai. Developed and owned by Majid al-Futtaim.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Mall_of_the_Emirates.jpg'),
(711, 39, 'Umm Al Emarat Park;a park for all the people of Dhabi. Connecting communities in a safe environment.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Mushrif_Park.jpg'),
(712, 39, 'Palm Islands are three artificial islands, Palm Jumeirah, Deira Island and Palm Jebel Ali.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Palm_Islands.jpg'),
(713, 39, 'Sheikh Saeed Al Maktoum House is a historic building and former residential quarters.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Saeed_Al_Maktoum_House.jpg'),
(714, 39, 'Ski Dubai is an indoor ski resort with 22,500 square meters of indoor ski area.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Ski_Dubai.jpg'),
(715, 39, 'The Dubai Fountain is the world largest choreographed fountain system set on the 30-acre.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_The_Dubai_Fountain.jpg'),
(716, 39, 'The Dubai Mall,  shopping festival, is one of the world largest shopping malls.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_The_Dubai_Mall.jpg'),
(717, 39, 'UAE Green planet, the preciousness of one of our worlds oldest living ecosystems.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_The_Green_Planet_Dubai.jpg'),
(718, 39, 'The Wild Wadi Water Park is an outdoor water park in Dubai, United Arab Emirates.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Wild_Wadi_Water_Park.jpg'),
(719, 39, 'IMG Worlds of Adventure is an indoor amusement park in the United Arab Emirates in Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Worlds_of_Adventure.jpg'),
(720, 39, 'Zabeel Park is an urban public park located in the Zabeel district of Dubai.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_DUBAI_Zabeel_Park.jpg'),
(721, 39, 'The Al Noor Mosque is a mosque in Sharjah. It is located on the Khaled lagoon .', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Al_Noor_Mosque.jpg'),
(722, 39, 'The Arabian Wildlife Center is the only zoo in Arabia which exhibits all the animals naturally.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Arabia''s_Wildlife_Centre.jpg'),
(723, 39, 'This museum offers you the opportunity to explore the rich heritage and deep-rooted history.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Archeological_Museum.jpg'),
(724, 39, 'Sharjah Art Museum displays a captivating collection of modern.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Museum_of_Arts.jpg'),
(725, 39, 'The Sharjah Museum of Islamic Civilization is a museum in Sharjah, United Arab Emirates.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Museum_of_Islamic_Civilization.jpg'),
(726, 39, 'Educational aquarium spread over 2 floors with 20 separate tanks & over 150 different species.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Sharjah_Aquarium.jpg'),
(727, 39, 'Museum showcasing more than 100 cars, motorcycles & bikes, with the earliest model dating from 1917.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Sharjah_Car_Museum.jpg'),
(728, 39, 'Sharjah Fort is a double story traditional rock, coral and adobe fortification.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Sharjah_Fort.jpg'),
(729, 39, 'Opened in 1996, this family-friendly science museum features interactive educational exhibits.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_Sharjah_Sharjah_Science_Museum.jpg'),
(730, 39, 'Playful water park with serpentine slides & a lawn for lounging, plus dining spots & a camping area.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_UMM_AL-QUWAIN_dreamland_park.jpg'),
(731, 39, 'Water park with ice-themed scenery & high-speed slides plus a wave pool, bathing zone & kids area.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_UMM_AL-QUWAIN_Ice_Land_Water_Park.jpg'),
(732, 39, 'Umm al-Quwain holds significant archaeological interest with major finds at Tell Abraq and Ed-Dur.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_UMM_AL-QUWAIN_Tombs_of_Tell_Abraq.jpg'),
(733, 39, 'Umm al-Quwain Fort: A fort which was once home to the emirates ruler.', 'http://itourscloud.com/destination_gallery/asia/uae/Asia_UAE_UMM_AL-QUWAIN_Umm_Al_Quwain_Museum.jpg'),
(734, 40, 'Jomolhari or Chomolhari sometimes known as the bride of Kangchenjunga.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Chomolhari.jpg'),
(735, 40, 'The Dochula Pass is a mountain pass in the snow covered Himalayas within Bhutan .', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Dochula_Pass.jpg'),
(736, 40, 'Highest road pass, mountainous of Bhutan, Chele La Pass at a dizzying 3 988mtr above sea level. ', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Paro_Chele_La_Pass.jpg'),
(737, 40, 'Neat main street of Paro, Bhutan, with shops housed in traditional Bhutanese-style buildings.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Paro_Main_Street.jpg'),
(738, 40, 'Rinpung Dzong is a large dzong - Buddhist monastery and fortress - of the Drukpa Lineage.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Paro_Rinpung_Dzong.jpg'),
(739, 40, 'Paro Taktsang, is a prominent Himalayan Buddhist sacred site and the temple complex .', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Paro_Tigers_Nest.jpg'),
(740, 40, 'The Phobjikha Valley à½•à½¼à½–à¼‹à½¦à¾¦à¾±à½²à½¦à¼‹à½ is a vast U-shaped glacial valley, also known as Gangteng Valley.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Phobjikha_Valley.jpg'),
(741, 40, 'Punakha Dzong is arguably the most beautiful dzong in the country,.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Punakha_Dzong.jpg'),
(742, 40, 'This massive statue of Shakyamuni, making it one of the largest statues of Buddha in the world.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Thimphu_Buddha_Dordenma_Statue.jpg'),
(743, 40, 'Thimphu is only capital in the world without the traffic lights.', 'http://itourscloud.com/destination_gallery/asia/bhutan/Asia_Bhutan_Thimphu_Norzin_Lam_Street.jpg'),
(744, 52, '', 'http://itourscloud.com/destination_gallery/asia/Austria/baroque-church.jpg'),
(745, 52, '', 'http://itourscloud.com/destination_gallery/asia/Austria/hallstatt.jpg'),
(746, 52, '', 'http://itourscloud.com/destination_gallery/asia/Austria/mountains.jpg'),
(747, 52, '', 'http://itourscloud.com/destination_gallery/asia/Austria/vienna-city.jpg'),
(748, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/brussels.jpg'),
(749, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/cultural-capital-Liege.jpg'),
(750, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/Religious-beauty-Tournai.jpg'),
(751, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/Sparkling-Antwerp.jpg'),
(752, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/theatre-tragedy-wars.jpg'),
(753, 53, '', 'http://itourscloud.com/destination_gallery/asia/Belgium/Venice-North.jpg'),
(754, 54, '', 'http://itourscloud.com/destination_gallery/asia/England/england-canterbury-cathedral.jpg'),
(755, 54, '', 'http://itourscloud.com/destination_gallery/asia/England/england-chester-zoo-2.jpg'),
(756, 54, '', 'http://itourscloud.com/destination_gallery/asia/England/england-city-of-bath.jpg'),
(757, 54, '', 'http://itourscloud.com/destination_gallery/asia/England/england-eden-project.jpg'),
(758, 54, '', 'http://itourscloud.com/destination_gallery/asia/England/england-historic-yorkshire.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `generic_count_master`
--

CREATE TABLE IF NOT EXISTS `generic_count_master` (
  `id` int(11) NOT NULL,
  `a_enquiry_count` int(11) NOT NULL,
  `a_temp_enq_count` int(11) NOT NULL,
  `a_task_count` int(11) NOT NULL,
  `a_temp_task_count` int(11) NOT NULL,
  `b_enquiry_count` int(200) NOT NULL,
  `b_temp_enq_count` int(200) NOT NULL,
  `b_task_count` int(200) NOT NULL,
  `b_temp_task_count` int(200) NOT NULL,
  `a_leave_count` int(200) NOT NULL,
  `a_temp_leave_count` int(200) NOT NULL,
  `setup_country_id` int(11) NOT NULL,
  `setup_type` varchar(300) NOT NULL,
  `setup_creator` varchar(300) NOT NULL,
  `setup_created_at` datetime NOT NULL,
  `invoice_format` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generic_count_master`
--

INSERT INTO `generic_count_master` (`id`, `a_enquiry_count`, `a_temp_enq_count`, `a_task_count`, `a_temp_task_count`, `b_enquiry_count`, `b_temp_enq_count`, `b_task_count`, `b_temp_task_count`, `a_leave_count`, `a_temp_leave_count`, `setup_country_id`, `setup_type`, `setup_creator`, `setup_created_at`, `invoice_format`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '2', 'Sweety Ban', '2020-03-16 06:28:00', 'Standard');

-- --------------------------------------------------------

--
-- Table structure for table `group_cruise_entries`
--

CREATE TABLE IF NOT EXISTS `group_cruise_entries` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `dept_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `route` varchar(300) NOT NULL,
  `cabin` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_cruise_master`
--

CREATE TABLE IF NOT EXISTS `group_cruise_master` (
  `cruise_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `dept_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `route` varchar(150) NOT NULL,
  `cabin` varchar(300) NOT NULL,
  `sharing` varchar(300) NOT NULL,
  `seats` int(11) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`cruise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_master`
--

CREATE TABLE IF NOT EXISTS `group_master` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(300) NOT NULL,
  `head_id` int(11) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_master`
--

INSERT INTO `group_master` (`group_id`, `group_name`, `head_id`) VALUES
(1, 'Capital', 1),
(2, 'Cash & Cash Equivalents', 2),
(3, 'Expense (Direct)', 12),
(4, 'Fixed Assets', 7),
(5, 'Income (Direct)', 13),
(6, 'Income (Indirect)', 11),
(7, 'Indirect Expenses_Staff', 4),
(8, 'Indirect Expenses_Finance', 5),
(9, 'Indirect Expenses_Other', 10),
(10, 'Long Term Borrowing', 6),
(11, 'Long Term Loans & Advances', 8),
(12, 'Long Term Provisions', 8),
(13, 'Non-current Investments', 7),
(14, 'Other Current Liabilities', 3),
(15, 'Reserves & Surplus', 1),
(16, 'Short Term Borrowings', 3),
(17, 'Short Term Loans & Advances', 2),
(18, 'Short Term Provisions', 3),
(19, 'Expense (Other Direct)', 9),
(20, 'Trade Receivables', 2),
(21, 'Unsecured Loan', 8);

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_estimate_expense`
--

CREATE TABLE IF NOT EXISTS `group_tour_estimate_expense` (
  `expense_id` int(100) NOT NULL,
  `tour_id` int(50) NOT NULL,
  `tour_group_id` int(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `expense_name` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_plane_entries`
--

CREATE TABLE IF NOT EXISTS `group_tour_plane_entries` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(150) NOT NULL,
  `to_location` varchar(150) NOT NULL,
  `airline_name` varchar(150) NOT NULL,
  `class` varchar(150) NOT NULL,
  `arraval_time` datetime NOT NULL,
  `dapart_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_program`
--

CREATE TABLE IF NOT EXISTS `group_tour_program` (
  `entry_id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `attraction` varchar(150) NOT NULL,
  `day_wise_program` varchar(2000) NOT NULL,
  `stay` varchar(80) NOT NULL,
  `meal_plan` varchar(10) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_quotation_cruise_entries`
--

CREATE TABLE IF NOT EXISTS `group_tour_quotation_cruise_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `dept_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `route` varchar(300) NOT NULL,
  `cabin` varchar(200) NOT NULL,
  `sharing` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_quotation_master`
--

CREATE TABLE IF NOT EXISTS `group_tour_quotation_master` (
  `quotation_id` int(11) NOT NULL,
  `enquiry_id` int(200) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `tour_name` varchar(150) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `total_days` int(11) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `total_adult` int(11) NOT NULL,
  `total_children` int(11) NOT NULL,
  `total_infant` int(11) NOT NULL,
  `total_passangers` int(11) NOT NULL,
  `children_without_bed` decimal(50,0) NOT NULL,
  `children_with_bed` decimal(50,0) NOT NULL,
  `quotation_date` date NOT NULL,
  `booking_type` varchar(150) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `children_cost` decimal(50,2) NOT NULL,
  `infant_cost` decimal(50,2) NOT NULL,
  `with_bed_cost` decimal(50,2) NOT NULL,
  `tour_cost` decimal(50,2) NOT NULL,
  `markup_cost` decimal(50,2) NOT NULL,
  `markup_cost_subtotal` decimal(50,2) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` varchar(150) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `quotation_cost` decimal(50,2) NOT NULL,
  `incl` text NOT NULL,
  `excl` text NOT NULL,
  `terms` text NOT NULL,
  `tour_group_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `login_id` int(200) NOT NULL,
  `tour_group` int(200) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `customer_status` varchar(10) NOT NULL,
  `clone` varchar(10) NOT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_quotation_plane_entries`
--

CREATE TABLE IF NOT EXISTS `group_tour_quotation_plane_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(150) NOT NULL,
  `to_location` varchar(120) NOT NULL,
  `airline_name` varchar(150) NOT NULL,
  `class` varchar(150) NOT NULL,
  `arraval_time` datetime NOT NULL,
  `dapart_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_tour_quotation_train_entries`
--

CREATE TABLE IF NOT EXISTS `group_tour_quotation_train_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `from_location` varchar(150) NOT NULL,
  `to_location` varchar(150) NOT NULL,
  `class` varchar(150) NOT NULL,
  `arrival_date` datetime NOT NULL,
  `departure_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_train_entries`
--

CREATE TABLE IF NOT EXISTS `group_train_entries` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `from_location` varchar(100) NOT NULL,
  `to_location` varchar(100) NOT NULL,
  `class` varchar(150) NOT NULL,
  `arrival_date` datetime NOT NULL,
  `departure_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gst_payable_master`
--

CREATE TABLE IF NOT EXISTS `gst_payable_master` (
  `id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `mode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `bank_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `clearance_status` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `head_master`
--

CREATE TABLE IF NOT EXISTS `head_master` (
  `head_id` int(11) NOT NULL,
  `head_name` varchar(300) NOT NULL,
  PRIMARY KEY (`head_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `head_master`
--

INSERT INTO `head_master` (`head_id`, `head_name`) VALUES
(1, 'Capital'),
(2, 'Current Assets'),
(3, 'Current liabilities'),
(4, 'Employee Benefit Expenses'),
(5, 'Finance Charges'),
(6, 'Long Term Borrowing'),
(7, 'Non-current Assets'),
(8, 'Non-current liabilities'),
(9, 'Other Direct Expenses'),
(10, 'Other Expenses'),
(11, 'Other Income'),
(12, 'Purchases'),
(13, 'Revenue from Operations');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_blackdated_tarrif`
--

CREATE TABLE IF NOT EXISTS `hotel_blackdated_tarrif` (
  `entry_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `room_category` varchar(25) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `single_bed` decimal(50,2) NOT NULL,
  `double_bed` decimal(50,2) NOT NULL,
  `triple_bed` decimal(50,2) NOT NULL,
  `child_with_bed` decimal(50,2) NOT NULL,
  `child_without_bed` decimal(50,2) NOT NULL,
  `first_child` decimal(50,2) NOT NULL,
  `second_child` decimal(50,2) NOT NULL,
  `extra_bed` decimal(50,2) NOT NULL,
  `queen_bed` decimal(50,2) NOT NULL,
  `king_bed` decimal(50,2) NOT NULL,
  `quad_bed` decimal(50,2) NOT NULL,
  `twin_bed` decimal(50,2) NOT NULL,
  `markup_per` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `meal_plan` varchar(15) NOT NULL,
  `max_occupancy` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking_entries`
--

CREATE TABLE IF NOT EXISTS `hotel_booking_entries` (
  `entry_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `city_id` int(100) NOT NULL,
  `hotel_id` int(100) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime NOT NULL,
  `no_of_nights` varchar(100) NOT NULL,
  `rooms` varchar(100) NOT NULL,
  `room_type` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `accomodation_type` varchar(300) NOT NULL,
  `extra_beds` varchar(300) NOT NULL,
  `meal_plan` varchar(300) NOT NULL,
  `conf_no` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking_master`
--

CREATE TABLE IF NOT EXISTS `hotel_booking_master` (
  `booking_id` int(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `pass_name` varchar(100) NOT NULL,
  `adults` varchar(100) NOT NULL,
  `childrens` varchar(100) NOT NULL,
  `infants` varchar(100) NOT NULL,
  `sub_total` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(100) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `discount` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `total_fee` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `unique_timestamp` text NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `refund_total_fee` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking_payment`
--

CREATE TABLE IF NOT EXISTS `hotel_booking_payment` (
  `payment_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking_refund_entries`
--

CREATE TABLE IF NOT EXISTS `hotel_booking_refund_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `entry_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking_refund_master`
--

CREATE TABLE IF NOT EXISTS `hotel_booking_refund_master` (
  `refund_id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_contracted_tarrif`
--

CREATE TABLE IF NOT EXISTS `hotel_contracted_tarrif` (
  `entry_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `room_category` varchar(25) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `single_bed` decimal(50,2) NOT NULL,
  `double_bed` decimal(50,2) NOT NULL,
  `triple_bed` decimal(50,2) NOT NULL,
  `child_with_bed` decimal(50,2) NOT NULL,
  `child_without_bed` decimal(50,2) NOT NULL,
  `first_child` decimal(50,2) NOT NULL,
  `second_child` decimal(50,2) NOT NULL,
  `extra_bed` decimal(50,2) NOT NULL,
  `queen_bed` decimal(50,2) NOT NULL,
  `king_bed` decimal(50,2) NOT NULL,
  `quad_bed` decimal(50,2) NOT NULL,
  `twin_bed` decimal(50,2) NOT NULL,
  `markup_per` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `meal_plan` varchar(15) NOT NULL,
  `max_occupancy` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_inventory_master`
--

CREATE TABLE IF NOT EXISTS `hotel_inventory_master` (
  `entry_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `room_type` varchar(100) NOT NULL,
  `total_rooms` varchar(50) NOT NULL,
  `valid_from_date` date NOT NULL,
  `valid_to_date` date NOT NULL,
  `rate` decimal(50,2) NOT NULL,
  `cancel_date` date NOT NULL,
  `reminder1` date NOT NULL,
  `reminder2` date NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL,
  `active_flag` varchar(50) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_master`
--

CREATE TABLE IF NOT EXISTS `hotel_master` (
  `hotel_id` int(50) NOT NULL,
  `city_id` int(50) NOT NULL,
  `hotel_name` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(100) NOT NULL,
  `hotel_address` varchar(400) NOT NULL,
  `country` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `rating_star` varchar(200) NOT NULL,
  `meal_plan` varchar(50) NOT NULL,
  `hotel_type` varchar(50) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `ifsc_code` varchar(100) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  `description` text NOT NULL,
  `policies` text NOT NULL,
  `amenities` varchar(600) NOT NULL,
  `cwb_from` int(11) NOT NULL,
  `cwb_to` int(11) NOT NULL,
  `cwob_from` int(11) NOT NULL,
  `cwob_to` int(11) NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_offers_tarrif`
--

CREATE TABLE IF NOT EXISTS `hotel_offers_tarrif` (
  `entry_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `offer` varchar(500) NOT NULL,
  `offer_amount` decimal(50,2) NOT NULL,
  `agent_type` varchar(25) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_type_master`
--

CREATE TABLE IF NOT EXISTS `hotel_type_master` (
  `entry_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_type_master`
--

INSERT INTO `hotel_type_master` (`entry_id`, `type`) VALUES
(1, 'Adventure Hotel'),
(2, 'Airport Hotels'),
(3, 'Business Hotels'),
(4, 'Bed and Breakfast (B&B)'),
(5, 'Casino Hotels'),
(6, 'Resorts'),
(7, 'Self-Catering Hotels'),
(8, 'Service Apartments'),
(9, 'Suite Hotels'),
(10, 'Boatels'),
(11, 'City Center'),
(12, 'Motel'),
(13, 'Suburb Hotels'),
(14, 'Floating Hotels'),
(15, 'Heritage Hotel'),
(16, 'Rotels');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_vendor_images_entries`
--

CREATE TABLE IF NOT EXISTS `hotel_vendor_images_entries` (
  `id` int(100) NOT NULL,
  `hotel_id` varchar(500) NOT NULL,
  `hotel_pic_url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_vendor_price_list`
--

CREATE TABLE IF NOT EXISTS `hotel_vendor_price_list` (
  `entry_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `single_bed_cost` decimal(50,2) NOT NULL,
  `double_bed_cost` decimal(50,2) NOT NULL,
  `triple_bed_cost` decimal(50,2) NOT NULL,
  `quad_bed_cost` decimal(50,2) NOT NULL,
  `with_bed_cost` decimal(50,2) NOT NULL,
  `without_bed_cost` varchar(50) NOT NULL,
  `queen` decimal(50,2) NOT NULL,
  `king` decimal(50,2) NOT NULL,
  `twin` decimal(50,2) NOT NULL,
  `meal_plan` varchar(150) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_vendor_price_master`
--

CREATE TABLE IF NOT EXISTS `hotel_vendor_price_master` (
  `pricing_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`pricing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_weekend_tarrif`
--

CREATE TABLE IF NOT EXISTS `hotel_weekend_tarrif` (
  `entry_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `room_category` varchar(20) NOT NULL,
  `day` varchar(15) NOT NULL,
  `single_bed` decimal(50,2) NOT NULL,
  `double_bed` decimal(50,2) NOT NULL,
  `triple_bed` decimal(50,2) NOT NULL,
  `child_with_bed` decimal(50,2) NOT NULL,
  `child_without_bed` decimal(50,2) NOT NULL,
  `first_child` decimal(50,2) NOT NULL,
  `second_child` decimal(50,2) NOT NULL,
  `extra_bed` decimal(50,2) NOT NULL,
  `queen_bed` decimal(50,2) NOT NULL,
  `king_bed` decimal(50,2) NOT NULL,
  `quad_bed` decimal(50,2) NOT NULL,
  `twin_bed` decimal(50,2) NOT NULL,
  `markup_per` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `meal_plan` varchar(15) NOT NULL,
  `max_occupancy` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inclusions_exclusions_master`
--

CREATE TABLE IF NOT EXISTS `inclusions_exclusions_master` (
  `inclusion_id` int(100) NOT NULL,
  `inclusion` text NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(200) NOT NULL,
  `for_value` varchar(200) NOT NULL,
  PRIMARY KEY (`inclusion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `insuarance_vendor`
--

CREATE TABLE IF NOT EXISTS `insuarance_vendor` (
  `vendor_id` int(50) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `mobile_no` varchar(300) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `concern_person_name` varchar(300) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(100) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inter_bank_transfer_master`
--

CREATE TABLE IF NOT EXISTS `inter_bank_transfer_master` (
  `entry_id` int(11) NOT NULL,
  `from_bank_id` int(11) NOT NULL,
  `to_bank_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `favouring_name` varchar(530) NOT NULL,
  `transaction_date` date NOT NULL,
  `transaction_type` varchar(200) NOT NULL,
  `instrument_no` varchar(300) NOT NULL,
  `instrument_date` date NOT NULL,
  `lapse_date` date NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `itinerary_paid_services`
--

CREATE TABLE IF NOT EXISTS `itinerary_paid_services` (
  `service_id` int(100) NOT NULL,
  `city_id` int(100) NOT NULL,
  `service_name` varchar(300) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_cost` decimal(50,2) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `description` text NOT NULL,
  `image_upload_url` varchar(200) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `journal_entry_accounts`
--

CREATE TABLE IF NOT EXISTS `journal_entry_accounts` (
  `acc_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `ledger_id` int(11) NOT NULL,
  `type` varchar(300) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`acc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `journal_entry_master`
--

CREATE TABLE IF NOT EXISTS `journal_entry_master` (
  `entry_id` int(11) NOT NULL,
  `entry_date` date NOT NULL,
  `narration` text NOT NULL,
  `created_at` datetime NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `journy_mail_while_tour`
--

CREATE TABLE IF NOT EXISTS `journy_mail_while_tour` (
  `mail_status_id` int(100) NOT NULL,
  `tour_id` int(100) NOT NULL,
  `date_mail` date NOT NULL,
  `tour_type` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`mail_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leave_credits`
--

CREATE TABLE IF NOT EXISTS `leave_credits` (
  `id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `casual` int(200) NOT NULL,
  `paid` int(200) NOT NULL,
  `medical` int(200) NOT NULL,
  `maternity` int(200) NOT NULL,
  `paternity` int(200) NOT NULL,
  `leave_without_pay` int(200) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE IF NOT EXISTS `leave_request` (
  `request_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `no_of_days` int(200) NOT NULL,
  `type_of_leave` varchar(200) NOT NULL,
  `reason_for_leave` text NOT NULL,
  `created_date` date NOT NULL,
  `comments` text NOT NULL,
  `reply_date` date NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_master`
--

CREATE TABLE IF NOT EXISTS `ledger_master` (
  `ledger_id` int(11) NOT NULL,
  `ledger_name` varchar(300) NOT NULL,
  `alias` varchar(200) NOT NULL,
  `group_sub_id` int(11) NOT NULL,
  `balance` decimal(50,2) NOT NULL,
  `dr_cr` varchar(200) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  PRIMARY KEY (`ledger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ledger_master`
--

INSERT INTO `ledger_master` (`ledger_id`, `ledger_name`, `alias`, `group_sub_id`, `balance`, `dr_cr`, `customer_id`, `user_type`) VALUES
(1, 'Accounting Fees', '', 69, '0.00', 'Dr', 0, ''),
(2, 'Advance from customers', '', 22, '0.00', 'Cr', 0, ''),
(3, 'Advances to Suppliers', '', 23, '0.00', 'Dr', 0, ''),
(4, 'Auditor Fees', '', 69, '0.00', 'Dr', 0, ''),
(5, 'Bank ', '', 24, '0.00', 'Dr', 0, ''),
(6, 'Bank Charges', '', 47, '0.00', 'Dr', 0, ''),
(7, 'Bank Overdraft', '', 25, '0.00', 'Cr', 0, ''),
(8, 'Building', '', 100, '0.00', 'Dr', 0, ''),
(9, 'Bus Booking Expenses', '', 26, '0.00', 'Dr', 0, ''),
(10, 'Bus Booking Services Sales', '', 87, '0.00', 'Cr', 0, ''),
(11, 'Bus Booking Services Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(12, 'Bus Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(13, 'Capital Advances', '', 28, '0.00', 'Dr', 0, ''),
(14, 'Capital Redemption Reserve', '', 29, '0.00', 'Cr', 0, ''),
(15, 'Capital Reserves', '', 30, '0.00', 'Cr', 0, ''),
(16, 'Car Rental Booking Expenses', '', 31, '0.00', 'Dr', 0, ''),
(17, 'Car Rental Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(18, 'Car Rental Services Sales', '', 87, '0.00', 'Cr', 0, ''),
(19, 'Car Rental Services Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(20, 'Cash In Hand', '', 33, '0.00', 'Dr', 0, ''),
(21, 'Output CGST', '', 99, '0.00', 'Cr', 0, ''),
(22, 'Commission from Forex Services', '', 87, '0.00', 'Cr', 0, ''),
(23, 'Commission from Insurance Services', '', 34, '0.00', 'Cr', 0, ''),
(24, 'Commission Paid to Agents', '', 3, '0.00', 'Dr', 0, ''),
(25, 'Commission Received', '', 5, '0.00', 'Cr', 0, ''),
(26, 'Communication Expenses', '', 35, '0.00', 'Dr', 0, ''),
(27, 'Computer Softwares', '', 60, '0.00', 'Dr', 0, ''),
(28, 'Contribution to Provident & Other Funds', '', 84, '0.00', 'Dr', 0, ''),
(29, 'Cruise Booking Expenses', '', 36, '0.00', 'Dr', 0, ''),
(30, 'Cruise Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(31, 'Deffered Payment Liabilities', '', 38, '0.00', 'Cr', 0, ''),
(32, 'Delivery Charges Paid', '', 3, '0.00', 'Dr', 0, ''),
(33, 'Delivery Charges Received', '', 5, '0.00', 'Cr', 0, ''),
(34, 'Deposits (Liabilities)', '', 39, '0.00', 'Cr', 0, ''),
(35, 'Depreciation ', '', 40, '0.00', 'Dr', 0, ''),
(36, 'Discount Granted', '', 3, '0.00', 'Dr', 0, ''),
(37, 'Discount Received', '', 5, '0.00', 'Cr', 0, ''),
(38, 'Dividend received', '', 41, '0.00', 'Cr', 0, ''),
(39, 'DMC Booking Expenses', '', 42, '0.00', 'Dr', 0, ''),
(40, 'DMC Cancellation', '', 79, '0.00', 'Dr', 0, ''),
(41, 'Electricity', '', 43, '0.00', 'Dr', 0, ''),
(42, 'ESIC Payable', '', 99, '0.00', 'Cr', 0, ''),
(43, 'Excursion Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(44, 'Excursion Packages Sales', '', 87, '0.00', 'Cr', 0, ''),
(45, 'Excursion Packages Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(46, 'Excursion Purchased', '', 46, '0.00', 'Dr', 0, ''),
(47, 'Fixed Deposits', '', 24, '0.00', 'Dr', 0, ''),
(48, 'Flight Booking Expenses', '', 48, '0.00', 'Dr', 0, ''),
(49, 'Flight Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(50, 'Flight Tickets Sales(Domestic)', '', 87, '0.00', 'Cr', 0, ''),
(51, 'Flight Tickets Sales Return(Domestic)', '', 89, '0.00', 'Dr', 0, ''),
(52, 'Foreign Exchange Gain', '', 50, '0.00', 'Cr', 0, ''),
(53, 'Foreign Exchange Loss', '', 51, '0.00', 'Dr', 0, ''),
(54, 'Furniture & Fixtures', '', 100, '0.00', 'Dr', 0, ''),
(55, 'Gain/(Loss) on Sale of Investment', '', 52, '0.00', 'Cr', 0, ''),
(56, 'Gain/(Loss) on Sale or disposal of Fixed Assets', '', 53, '0.00', 'Cr', 0, ''),
(57, 'General Reserve', '', 54, '0.00', 'Cr', 0, ''),
(58, 'Goodwill', '', 60, '0.00', 'Dr', 0, ''),
(59, 'Group Tours Sales', '', 87, '0.00', 'Cr', 0, ''),
(60, 'Group Tours Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(61, 'GST Payable', '', 99, '0.00', 'Cr', 0, ''),
(62, 'Hotel Booking Expenses', '', 55, '0.00', 'Dr', 0, ''),
(63, 'Hotel Booking Services Sales', '', 87, '0.00', 'Cr', 0, ''),
(64, 'Hotel Booking Services Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(65, 'Hotel Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(66, 'Housekeeping & Office Maintenance', '', 57, '0.00', 'Dr', 0, ''),
(67, 'Output IGST', '', 99, '0.00', 'Cr', 0, ''),
(68, 'Income received in advance', '', 63, '0.00', 'Cr', 0, ''),
(69, 'Insurance Premium Paid', '', 59, '0.00', 'Dr', 0, ''),
(70, 'Interest Accrued but due', '', 61, '0.00', 'Cr', 0, ''),
(71, 'Interest Accrued but not due', '', 62, '0.00', 'Cr', 0, ''),
(72, 'Interest on Cash Credit Facilities', '', 47, '0.00', 'Dr', 0, ''),
(73, 'Interest on delayed payments of statutory liabilities', '', 47, '0.00', 'Dr', 0, ''),
(74, 'Interest on Term Loans', '', 47, '0.00', 'Dr', 0, ''),
(75, 'Interest received', '', 63, '0.00', 'Cr', 0, ''),
(76, 'Invesment in Debentures & Bonds', '', 64, '0.00', 'Dr', 0, ''),
(77, 'Invesment in Equity Shares', '', 65, '0.00', 'Dr', 0, ''),
(78, 'Invesment in Government Securities', '', 66, '0.00', 'Dr', 0, ''),
(79, 'Invesment in Mutual Funds', '', 67, '0.00', 'Dr', 0, ''),
(80, 'Invesment in Preference Shares', '', 68, '0.00', 'Dr', 0, ''),
(81, 'Land', '', 100, '0.00', 'Dr', 0, ''),
(82, 'Legal Fees', '', 69, '0.00', 'Dr', 0, ''),
(83, 'Licence Fees Paid', '', 8, '0.00', 'Dr', 0, ''),
(84, 'Licences', '', 60, '0.00', 'Dr', 0, ''),
(85, 'Loans & Advances from Related Parties', '', 70, '0.00', 'Cr', 0, ''),
(86, 'Loans & Advances to Related Parties', '', 71, '0.00', 'Dr', 0, ''),
(87, 'Miscelleneous Expenses', '', 72, '0.00', 'Dr', 0, ''),
(88, 'Office Equipments', '', 100, '0.00', 'Dr', 0, ''),
(89, 'Other Cancellation Charges Paid', '', 73, '0.00', 'Dr', 0, ''),
(90, 'Other Vehicle Rental Expenses', '', 74, '0.00', 'Dr', 0, ''),
(91, 'Package Tours Sales', '', 87, '0.00', 'Cr', 0, ''),
(92, 'Package Tours Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(93, 'Passport Services Sales', '', 87, '0.00', 'Cr', 0, ''),
(94, 'Passport Services Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(95, 'Patent', '', 60, '0.00', 'Dr', 0, ''),
(96, 'Petrol & Diesel', '', 75, '0.00', 'Dr', 0, ''),
(97, 'Petty Cash', '', 33, '0.00', 'Dr', 0, ''),
(98, 'Plant & Equipment', '', 100, '0.00', 'Dr', 0, ''),
(99, 'Postage & Courier Expenses', '', 9, '0.00', 'Dr', 0, ''),
(100, 'Printing & Stationery Expenses', '', 76, '0.00', 'Dr', 0, ''),
(101, 'Provident Fund payable', '', 99, '0.00', 'Cr', 0, ''),
(102, 'Provisions for Gratuity (Long Term)', '', 77, '0.00', 'Cr', 0, ''),
(103, 'Provsion for gratuity (Short Term)', '', 78, '0.00', 'Cr', 0, ''),
(104, 'PT payable', '', 99, '0.00', 'Cr', 0, ''),
(105, 'Rates & Taxes', '', 80, '0.00', 'Dr', 0, ''),
(106, 'Rent', '', 81, '0.00', 'Dr', 0, ''),
(107, 'Rent Received', '', 6, '0.00', 'Cr', 0, ''),
(108, 'Repairs & Maintenance', '', 82, '0.00', 'Dr', 0, ''),
(109, 'Revaluation Reserve', '', 83, '0.00', 'Cr', 0, ''),
(110, 'Salaries Paid', '', 84, '0.00', 'Dr', 0, ''),
(111, 'Salary & Other payables', '', 85, '0.00', 'Cr', 0, ''),
(112, 'Sale of Scrap', '', 86, '0.00', 'Cr', 0, ''),
(113, 'Sales Promotion Expenses', '', 88, '0.00', 'Dr', 0, ''),
(114, 'Securities Premium Reserve', '', 90, '0.00', 'Cr', 0, ''),
(115, 'Security Deposits (Liability)', '', 91, '0.00', 'Dr', 0, ''),
(116, 'Security Expenses', '', 92, '0.00', 'Dr', 0, ''),
(117, 'Service Charges Paid', '', 3, '0.00', 'Dr', 0, ''),
(118, 'Service Charges Received', '', 93, '0.00', 'Cr', 0, ''),
(119, 'Output SGST', '', 99, '0.00', 'Cr', 0, ''),
(120, 'Share Capital', '', 94, '0.00', 'Cr', 0, ''),
(121, 'Sight Seeing Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(122, 'Sight Seeing Expenses', '', 96, '0.00', 'Dr', 0, ''),
(123, 'Staff Recruitment Expenses', '', 97, '0.00', 'Dr', 0, ''),
(124, 'Staff training Expenses', '', 98, '0.00', 'Dr', 0, ''),
(125, 'Staff Wefare Expenses', '', 44, '0.00', 'Dr', 0, ''),
(126, 'TDS Payable', '', 99, '0.00', 'Cr', 0, ''),
(127, 'TDS Receivable', '', 17, '0.00', 'Dr', 0, ''),
(128, 'Trade Payables', '', 14, '0.00', 'Cr', 0, ''),
(129, 'Trade Receivables', '', 20, '0.00', 'Dr', 0, ''),
(130, 'TradeMarks', '', 60, '0.00', 'Dr', 0, ''),
(131, 'Train Ticket Cancellation  Expenses', '', 79, '0.00', 'Dr', 0, ''),
(132, 'Train Ticket Expenses', '', 102, '0.00', 'Dr', 0, ''),
(133, 'Train Tickets Sales', '', 87, '0.00', 'Cr', 0, ''),
(134, 'Train Tickets Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(135, 'Travelling Cost', '', 103, '0.00', 'Dr', 0, ''),
(136, 'Unpaid dividends', '', 104, '0.00', 'Cr', 0, ''),
(137, 'Unsecured Loan', '', 21, '0.00', 'Cr', 0, ''),
(138, 'Output UTGST', '', 99, '0.00', 'Cr', 0, ''),
(139, 'Vehicles', '', 100, '0.00', 'Dr', 0, ''),
(140, 'Visa Services sales', '', 87, '0.00', 'Cr', 0, ''),
(141, 'Visa Services sales Return', '', 89, '0.00', 'Dr', 0, ''),
(142, 'Insurance Commission', '', 3, '0.00', 'Dr', 0, ''),
(143, 'Expenses For Passport Services ', '', 3, '0.00', 'Dr', 0, ''),
(144, 'Expenses For Visa Services', '', 3, '0.00', 'Dr', 0, ''),
(145, 'Input CGST', '', 106, '0.00', 'Dr', 0, ''),
(146, 'Input SGST ', '', 106, '0.00', 'Dr', 0, ''),
(147, 'Input UTGST ', '', 106, '0.00', 'Dr', 0, ''),
(148, 'Input IGST ', '', 106, '0.00', 'Dr', 0, ''),
(149, 'Input VAT', '', 107, '0.00', 'Dr', 0, ''),
(150, 'Output VAT', '', 99, '0.00', 'Cr', 0, ''),
(151, 'IGst On Purchase Cancellation A/c', '', 99, '0.00', 'Cr', 0, ''),
(152, 'IGst On Sale Cancellation A/c', '', 99, '0.00', 'Dr', 0, ''),
(153, 'Sgst On Purchase Cancellation A/c', '', 99, '0.00', 'Cr', 0, ''),
(154, 'Sgst On Sale Cancellation A/c', '', 99, '0.00', 'Dr', 0, ''),
(155, 'Cgst On Purchase Cancellation A/c', '', 99, '0.00', 'Cr', 0, ''),
(156, 'Cgst On Sale Cancellation A/c', '', 99, '0.00', 'Dr', 0, ''),
(157, 'Ugst On Purchase Cancellation A/c', '', 99, '0.00', 'Cr', 0, ''),
(158, 'Ugst On Sale Cancellation A/c', '', 99, '0.00', 'Dr', 0, ''),
(159, 'Vat On Sale Cancellation A/c', '', 99, '0.00', 'Dr', 0, ''),
(160, 'Vat On Purchase Cancellation A/c', '', 99, '0.00', 'Cr', 0, ''),
(161, 'Cancellation Charges Received', '', 6, '0.00', 'Cr', 0, ''),
(162, 'Visa Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(163, 'Passport Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(164, 'Dmc Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(165, 'Profit and Loss Account ', '', 1, '0.00', 'Cr', 0, ''),
(166, 'Sales Incentive Paid', '', 3, '0.00', 'Dr', 0, ''),
(167, 'Other Purchases', '', 3, '0.00', 'Dr', 0, ''),
(168, 'Other Purchases Cancellation', '', 79, '0.00', 'Dr', 0, ''),
(169, 'Miscellaneous Services Sales', '', 87, '0.00', 'Cr', 0, ''),
(170, 'Miscellaneous Services Sales Return', '', 89, '0.00', 'Dr', 0, ''),
(171, 'Expenses For Miscellaneous Services', '', 3, '0.00', 'Dr', 0, ''),
(172, 'Miscellaneous Cancellation Expenses', '', 79, '0.00', 'Dr', 0, ''),
(173, 'Profit Of The Year', '', 111, '0.00', 'Cr', 0, ''),
(174, 'Flight Tickets Sales(international)', '', 87, '0.00', 'Cr', 0, ''),
(175, 'Flight Tickets Sales Return(international)', '', 89, '0.00', 'Dr', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `location_id` int(50) NOT NULL,
  `location_name` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meal_plan_master`
--

CREATE TABLE IF NOT EXISTS `meal_plan_master` (
  `entry_id` int(11) NOT NULL,
  `meal_plan` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meal_plan_master`
--

INSERT INTO `meal_plan_master` (`entry_id`, `meal_plan`) VALUES
(1, 'Breakfast'),
(2, 'Lunch'),
(3, 'Dinner'),
(4, 'B+L'),
(5, 'B+D'),
(6, 'L+D'),
(7, 'B+L+D'),
(8, 'NA');

-- --------------------------------------------------------

--
-- Table structure for table `miscellaneous_master`
--

CREATE TABLE IF NOT EXISTS `miscellaneous_master` (
  `misc_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `misc_issue_amount` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` decimal(50,2) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `misc_total_cost` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  `due_date` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  `narration` text NOT NULL,
  `service` varchar(300) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`misc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `miscellaneous_master_entries`
--

CREATE TABLE IF NOT EXISTS `miscellaneous_master_entries` (
  `entry_id` int(11) NOT NULL,
  `misc_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `passport_id` varchar(200) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `miscellaneous_payment_master`
--

CREATE TABLE IF NOT EXISTS `miscellaneous_payment_master` (
  `payment_id` int(11) NOT NULL,
  `misc_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(200) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `miscellaneous_refund_entries`
--

CREATE TABLE IF NOT EXISTS `miscellaneous_refund_entries` (
  `id` int(11) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `miscellaneous_refund_master`
--

CREATE TABLE IF NOT EXISTS `miscellaneous_refund_master` (
  `refund_id` int(50) NOT NULL,
  `misc_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `modulewise_video_master`
--

CREATE TABLE IF NOT EXISTS `modulewise_video_master` (
  `entry_id` int(11) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `video_url` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modulewise_video_master`
--

INSERT INTO `modulewise_video_master` (`entry_id`, `module_name`, `video_url`, `description`, `status`) VALUES
(0, 'Purchase', 'https://drive.google.com/file/d/17NPw2BnS0L6RmJoKMPsHNjIbBYggOAB_/', '', ''),
(1, 'Dashboard', 'https://drive.google.com/file/d/1r7D_6i_bY_7bKCE7osb0580F5FooP3Yd/', '', 'Acitve'),
(2, 'Location and Branches', 'https://drive.google.com/file/d/1nMPysuz1m10E8DO_4yVmUdtK-8iJmvRr/', '', 'Acitve'),
(3, 'App Settings', 'https://drive.google.com/file/d/1zamZv_jhqYUFXAoDOKyV3SNF0zjvYcl9/', '', 'Acitve'),
(4, 'Roles', 'https://drive.google.com/file/d/1hUcERKRjt84_y3W2LG4-Q1yskjmRgXeT/', '', 'Acitve'),
(5, 'User Privilege', 'https://drive.google.com/file/d/1DYZksgRK5NdKnbn6JJkJhqX-uiq9G3XH/', '', 'Acitve'),
(6, 'Branch Privilege', 'https://drive.google.com/file/d/14AfOjbubAbs-U0vXGYP3FL8oukgUxzhG/', '', 'Acitve'),
(7, 'Users', 'https://drive.google.com/file/d/1Gdr444_c0VUWz34GeFsq1940MbRKd5UT/', '', 'Acitve'),
(8, 'Customers', 'https://drive.google.com/file/d/1NQal9nUDg4bDVyfArSDWUOb3_nI3B1VF/', '', 'Acitve'),
(9, 'Terms and Conditions', 'https://drive.google.com/file/d/1e4S00u-UrIcBFlxBbLC2jYkgvUCl9gNv/', '', 'Acitve'),
(10, 'Financial Year', 'https://drive.google.com/file/d/1F96qwBzSVu80owlw8vWypEJXFLqJYHI4/', '', 'Acitve'),
(11, 'Email CMS', 'https://drive.google.com/file/d/1EVhmtMpZoRQe0DSuFVuqHkbekU5XSFzR/', '', 'Acitve'),
(12, 'Other Master', 'https://drive.google.com/file/d/1SkcWwPXUI9cMN8uE1BYvDL5OapMWw6Oe/', '', 'Acitve'),
(13, 'Vehicle', 'https://drive.google.com/file/d/1i_kKRP0OAmc3Z9wHXBZV5nfiZ2CsVvLo/', '', 'Acitve'),
(14, 'Group Tours', 'https://drive.google.com/file/d/13KzwVLGGQsy0U8BZSqU5IgZlIU_P44HG/', '', 'Acitve'),
(15, 'Package Tours', 'https://drive.google.com/file/d/1tKQinmjM8RbJkuslQxixsIiumXhLF2To/', '', 'Acitve'),
(16, 'Visa', 'https://drive.google.com/file/d/1WgtbS27zL50UmDfEYe-NxhfxKQT_GHoy/', '', 'Acitve'),
(17, 'Excursion', 'https://drive.google.com/file/d/1Guk-JL7JMPbUa26VrZclqv1-w2eLaYg3/', '', 'Acitve'),
(18, 'B2B Packages', 'https://drive.google.com/file/d/1peJrPQMQqMUZcp3KkX8a5gDEAzG35Jhy/', '', 'Acitve'),
(19, 'Supplier Packages', 'https://drive.google.com/file/d/1wpnk4lKXEvWgCxpVZ1UtChr8Uyd2cK-8/edit', '', 'Acitve'),
(20, 'Hotels', 'https://drive.google.com/file/d/1UyBc46PxD18_hdT4vx1OBPd-_RHx4uhP/', '', 'Acitve'),
(21, 'Transporter', 'https://drive.google.com/file/d/1rfFER00bw-Z-BtzO8saS7InDSUtnpG9b/', '', 'Acitve'),
(22, 'DMC', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(23, 'Car Rental', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(24, 'Visa', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(25, 'Flight Ticket', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(26, 'Excursion', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(27, 'Cruise', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(28, 'Train Ticket', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(29, 'Passport', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(30, 'Insurance', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(31, 'Other Suppliers', 'https://drive.google.com/file/d/1E8tMcAhyxpkgz1FzduSoNQdx7euIIk2q/', '', 'Acitve'),
(32, 'Bank Master', 'https://drive.google.com/file/d/1zjwnW_O74zX98IsSfJ4ghj4PpC-K8eJJ/', '', 'Acitve'),
(33, 'Cheque Clearance', 'https://drive.google.com/file/d/1YWil0O2MNY8Fvhoh5EEUchrHlb1HAOSx/', '', 'Acitve'),
(34, 'Tax Amount(%)', 'https://drive.google.com/file/d/1M35ProoDy8uQmMNb6im30LfrU0S9T47Q/', '', 'Acitve'),
(35, 'Group Master', 'https://drive.google.com/file/d/1x_NJEh6ig3PxBVJ-x2wEeLQ9bXeOseqa/', '', 'Acitve'),
(36, 'Ledger Master', 'https://drive.google.com/file/d/1vyxv5-kaqFC7W54buDYXVR71-GTnwhQZ/', '', 'Acitve'),
(37, 'SAC Master', 'https://drive.google.com/file/d/1sa6gNqd2OWrTGELPCRG6zmOguuDYSqTI/', '', 'Acitve'),
(38, 'Journal Entries', 'https://drive.google.com/file/d/1z4igMamigLf8PVbptNw2C7cL22ePzQDE/', '', 'Acitve'),
(39, 'Enquiry', 'https://drive.google.com/file/d/1hLKaQ5VzwrRPHCOu66SM6PEnkSVSEYeW/', '', 'Acitve'),
(40, 'Package Quotation', 'https://drive.google.com/file/d/1a_-p6b9Shs91G2ZaUd5SQ-6tVGjEMjrA/', '', 'Acitve'),
(41, 'Group Quotation', 'https://drive.google.com/file/d/1gYvm-E65qj0405UmXx0BQpw0FhpJB-aR/', '', 'Acitve'),
(42, 'Car Rental Quotation', 'https://drive.google.com/file/d/1HkYYb82QhOnjsHCbSAaOB9_9OBmoMMHM/', '', 'Acitve'),
(43, 'Flight Quotation', 'https://drive.google.com/file/d/1tbZk3WCVJeyM3TQkmIO7SD-B7_1XANWK/', '', 'Acitve'),
(44, 'Tour Checklist', 'https://drive.google.com/file/d/1S8w796v1U4ScM8jB1X-PwDgvoNenrVaT/', '', 'Acitve'),
(45, 'Hotel Service Voucher', 'https://drive.google.com/file/d/1rxyAGHMjGpBqyba1XlgARfvr2b2Elgm1/', '', 'Acitve'),
(46, 'Transport Service Voucher', 'https://drive.google.com/file/d/1bRKPIqR6NZy7AE3WoFf4zujeJlzWn62y/', '', 'Acitve'),
(47, 'ID Proof', 'https://drive.google.com/file/d/19JywqSCWv-tv0oIZK9bBNdc23XkUyzBA/', '', 'Acitve'),
(48, 'Visa Status', 'https://drive.google.com/file/d/1rhuSeURZoterZdZtQxVrtIl8FDMIco4_/', '', 'Acitve'),
(49, 'Group Tour', 'https://drive.google.com/file/d/14MtV9KE72OPwHvrvqkBxnDPT0mdHTkB2/', '', 'Acitve'),
(50, 'Package Tour', 'https://drive.google.com/file/d/1CrqjG9PE63Ay0dYsk5VfK1iJPxKicRlV/', '', 'Acitve'),
(51, 'Visa', 'https://drive.google.com/file/d/1rTj1eON1mIM4GNMaZ5-Ko8czNzhfReeV/', '', 'Acitve'),
(52, 'Flight Ticket', 'https://drive.google.com/file/d/1OghrTnxnodlc4soOweXROxA-attgSAIp/', '', 'Acitve'),
(53, 'Train Ticket', 'https://drive.google.com/file/d/18PM4gRkydU3Kw9G8POEhMTsOxcx-e71T/', '', 'Acitve'),
(54, 'Hotel', 'https://drive.google.com/file/d/1O5-QBccwXzRYG3vyB_vXCuHkP0ZQji92/', '', 'Acitve'),
(55, 'Bus', 'https://drive.google.com/file/d/1wgUbki2Kj_p_MvjsGEBb-N3RH9_d9qLy/', '', 'Acitve'),
(56, 'Car Rental', 'https://drive.google.com/file/d/1MilrU70Au64Uyp79nYlyiCfxJyHXYAro/', '', 'Acitve'),
(57, 'Passport', 'https://drive.google.com/file/d/1PXp7b2dKjzly9n273aHBdbPf2ljIs4-R/', '', 'Acitve'),
(58, 'Forex', 'https://drive.google.com/file/d/1ApnlsSfXWncd2_Rxqtv6KFXnBhAIHidi/', '', 'Acitve'),
(59, 'Excursion', 'https://drive.google.com/file/d/1FU3S8iT52hy4BdM8enDsyF4JJXNHTA8N/', '', 'Acitve'),
(60, 'Miscellaneous', '', '', 'Acitve'),
(61, 'Quotation Request', 'https://drive.google.com/file/d/1mEXcRI6qA2aFDvbfgY5XaUgwPzeIy-uu/', '', 'Acitve'),
(62, 'Purchase Management', 'https://drive.google.com/file/d/1MoAsqCJoL_K0AwKcJhu2pf99eEprRSJP/', '', 'Acitve'),
(63, 'Cancel and Refund', 'https://drive.google.com/file/d/1Z8j7Or-E5udQlHsy7c6_UWd6ygYj4it_/', '', 'Acitve'),
(64, 'Complete Tour Cancel', 'https://drive.google.com/file/d/1zp4cw6a4rJH-bmO3WkZ_r6HRk6gAHuCP/', '', 'Acitve'),
(65, 'Complete Tour Refund', 'https://drive.google.com/file/d/1HQstGOR_fnZWoiusUtUTnH-tYaX2CRw0/', '', 'Acitve'),
(66, 'Group Tour Cancel', 'https://drive.google.com/file/d/1coN6B4Lxd1vskRpTp-nL9zkdr2Jkt8VC/', '', 'Acitve'),
(67, 'Group Tour Refund', 'https://drive.google.com/file/d/1278scrJzQN62ZittFJDwUE6M3cQErxFw/', '', 'Acitve'),
(68, 'Package Tour Cancel', 'https://drive.google.com/file/d/12ecTF1k3nWN3p0Rvbj7KzVi6Xie_IMcL/', '', 'Acitve'),
(69, 'Package Tour Refund', 'https://drive.google.com/file/d/1cfh36gR9QZGeVK6hQ-VYdjQmnjl403w_/', '', 'Acitve'),
(70, 'Car Rental Refund', 'https://drive.google.com/file/d/1KlaAMxYkGTPiV2BVGtHl8ptcYiHvCrNK/', '', 'Acitve'),
(71, 'Visa Cancel/Refund', 'https://drive.google.com/file/d/1I7PgbNgu0vcP2hqqDV8Nfyjy-RDFByHg/', '', 'Acitve'),
(72, 'Passport Cancel/Refund', 'https://drive.google.com/file/d/1Ky4Qi8USHYcU2_n0bJhlUwRyWkYw-0Ow/', '', 'Acitve'),
(73, 'Flight Cancel/Refund', 'https://drive.google.com/file/d/1_jxdhygE7pz1VoJ9eTXf3oQAXhWqpPQ-/', '', 'Acitve'),
(74, 'Train Cancel/Refund', 'https://drive.google.com/file/d/1JKhtkPPbNG9i9TFWCpUAjg5uWLS8ckxe/', '', 'Acitve'),
(75, 'Hotel Cancel/Refund', 'https://drive.google.com/file/d/1sHEWCFMk8QtoWDnALYjUOCgAF6xwk7fL/', '', 'Acitve'),
(76, 'Bus Cancel/Refund', 'https://drive.google.com/file/d/1L4Qx-4XlsHnZ_jKG5Z6fXaXa57FNSpZX/', '', 'Acitve'),
(77, 'Excursion Cancel/Refund', 'https://drive.google.com/file/d/1KW4ycZJwoNOgEqmWyiZhRD5OPZHBMUNi/', '', 'Acitve'),
(78, 'Miscellaneous Cancel/Refund', '', '', 'Acitve'),
(79, 'Group Tour Receipt', 'https://drive.google.com/file/d/1IQV7ddwQ0K_yM6ALP8Di0BnjPRbsOv6r/', '', 'Acitve'),
(80, 'Package Tour Receipt', 'https://drive.google.com/file/d/1Sk32eKkT-JTWyLjaQYL06BaYDfnLytKT/', '', 'Acitve'),
(81, 'Car Rental Receipt', 'https://drive.google.com/file/d/10jSC_nNPInbCMF3EidDgOCzHgRxWoqt5/', '', 'Acitve'),
(82, 'Other Receipts', 'https://drive.google.com/file/d/1IrqCNfJ7fOVj5B9g3Sob9mzW1pu9xPkg/', '', 'Acitve'),
(83, 'Other Expense', 'https://drive.google.com/file/d/1pPBec5Yb0tqR_ZqPn2fKAEyUpSHSS5so/', '', 'Acitve'),
(84, 'Sales Incentive', 'https://drive.google.com/file/d/1KMIoSpVwxFYGnuzcV4zdJoBcT3lcudu9/', '', 'Acitve'),
(85, 'Airline Topup', 'https://drive.google.com/file/d/1KA8JzlTYuQJeGaujBtDoXGXVhUZY0Xls/', '', 'Acitve'),
(86, 'Visa Topup', 'https://drive.google.com/file/d/1I8KaqcZZ27fv_2xFo8y5tR33VUsj2Ov2/', '', 'Acitve'),
(87, 'Bank Vouchers', 'https://drive.google.com/file/d/18vouIxeMUD4u23s5BotLGObsJ5C-6Hvu/', '', 'Acitve'),
(88, 'User Attendance', 'https://drive.google.com/file/d/17OgXwyVWJ0fwN8wobAR7OJIq8AYpLOKQ/', '', 'Acitve'),
(89, 'Leave Request', 'https://drive.google.com/file/d/1izh6uDd8KnehZtwNMcdr4u3_poCJZ7op/', '', 'Acitve'),
(90, 'Leave Management', 'https://drive.google.com/file/d/1iuSomwTDp3pMvhLYXGnHwP8C3byFskAr/', '', 'Acitve'),
(91, 'Tasks', 'https://drive.google.com/file/d/1BaJvY6xRus_sSWUJNfrWk7aPtpOOF2WV/', '', 'Acitve'),
(92, 'User Activities', 'https://drive.google.com/file/d/1d6VNy4QA-lgoa1JnW8sw7qCYulaFKwaz/', '', 'Acitve'),
(93, 'User Logs', 'https://drive.google.com/file/d/1qqvdY5rmJOsQcu6TV4w4lYkWcFQk-m7K/', '', 'Acitve'),
(94, 'Performance Rating', 'https://drive.google.com/file/d/14zxnvA2r5m1flIj6MdWZCd20O9uQ2Whl/', '', 'Acitve'),
(95, 'Tour Report', 'https://drive.google.com/file/d/1NONC6sCE97WPor7dIrKNhgoHV2B-lPpO/', '', 'Acitve'),
(96, 'Business Report', 'https://drive.google.com/file/d/1GKfIyjyqhyBfdzSi01HoYiRx5NDxcQkt/', '', 'Acitve'),
(97, 'HR Report', 'https://drive.google.com/file/d/19LhGPyZKnyaD6MLYYFhf7XQMF2odPdE8/', '', 'Acitve'),
(98, 'Account Report', 'https://drive.google.com/file/d/1TSifIAAQereO_yCLdOMfrCczc9XcFccp/', '', 'Acitve'),
(99, 'SMS Promotion', 'https://drive.google.com/file/d/18txIrH-x_arMc5cQzkahD6yyz4A-Qhtc/', '', 'Acitve'),
(100, 'Email Promotion', 'https://drive.google.com/file/d/1M213L9ReoKZKRgfuDEcoMGLHyxC7Y8ZD/', '', 'Acitve'),
(101, 'Sightseeing attractions', 'https://drive.google.com/file/d/1t1AA00vfdEC1KoiL-N1-x369KmpF7YGp/', '', 'Acitve'),
(102, 'Upcoming Offers', 'https://drive.google.com/file/d/1n66z4eCdbbBZDpff-doRq5ZlHa2K-FLo/', '', 'Acitve'),
(103, 'User Manual', 'https://drive.google.com/file/d/1cgpyFceI1lCr-v3pg46qDepW4P6o9_WP/', '', 'Active'),
(104, 'Ticket Support', '', '', 'Active'),
(105, 'Data Backup', '', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `office_expense_type`
--

CREATE TABLE IF NOT EXISTS `office_expense_type` (
  `expense_type_id` int(50) NOT NULL,
  `gl_id` int(50) NOT NULL,
  `expense_type` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `office_expense_type`
--

INSERT INTO `office_expense_type` (`expense_type_id`, `gl_id`, `expense_type`) VALUES
(1, 91, 'Office Rent '),
(2, 40, 'Electricity '),
(3, 113, 'Phone Service '),
(4, 117, 'Travel '),
(5, 93, 'Repairs and Maintenance'),
(6, 3, 'Advertising '),
(7, 149, 'Meals and Entertainment'),
(8, 36, 'Depreciation and Section'),
(9, 16, 'Bank Charges Paid '),
(10, 59, 'Licenses and permits '),
(11, 82, 'Postage and Delivery '),
(12, 83, 'Printing & Stationery '),
(13, 63, 'Uniforms '),
(14, 61, 'Loan Interest Paid '),
(15, 63, 'Miscellaneous '),
(16, 0, 'Internet '),
(17, 0, 'Business Insurance '),
(18, 0, 'Accounting '),
(19, 0, 'Equipment rent '),
(20, 0, 'Security ');

-- --------------------------------------------------------

--
-- Table structure for table `other_complaince_master`
--

CREATE TABLE IF NOT EXISTS `other_complaince_master` (
  `id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `comp_name` varchar(150) NOT NULL,
  `under_statue` varchar(100) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `due_date` date NOT NULL,
  `resp_person` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `comp_date` date NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_expense_master`
--

CREATE TABLE IF NOT EXISTS `other_expense_master` (
  `expense_id` int(50) NOT NULL,
  `expense_type_id` int(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `taxation_type` varchar(200) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` varchar(200) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `total_fee` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `expense_date` date NOT NULL,
  `invoice_url` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_expense_payment_master`
--

CREATE TABLE IF NOT EXISTS `other_expense_payment_master` (
  `payment_id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `expense_type_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(150) NOT NULL,
  `payment_date` date NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(300) NOT NULL,
  `evidance_url` text NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_income_master`
--

CREATE TABLE IF NOT EXISTS `other_income_master` (
  `income_id` int(11) NOT NULL,
  `income_type_id` int(11) NOT NULL,
  `receipt_from` varchar(150) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(11) NOT NULL,
  `service_tax` varchar(200) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `total_fee` decimal(50,2) NOT NULL,
  `receipt_date` date NOT NULL,
  `particular` text NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`income_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_income_payment_master`
--

CREATE TABLE IF NOT EXISTS `other_income_payment_master` (
  `payment_id` int(50) NOT NULL,
  `income_type_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_income_type_master`
--

CREATE TABLE IF NOT EXISTS `other_income_type_master` (
  `income_type_id` int(50) NOT NULL,
  `income_type` varchar(300) NOT NULL,
  `gl_id` int(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`income_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `other_vendors`
--

CREATE TABLE IF NOT EXISTS `other_vendors` (
  `vendor_id` int(50) NOT NULL,
  `city_id` int(200) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `profession` varchar(300) NOT NULL,
  `service_tax_no` varchar(300) NOT NULL,
  `mobile_no` varchar(300) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(100) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_cruise_master`
--

CREATE TABLE IF NOT EXISTS `package_cruise_master` (
  `cruise_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `dept_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `route` varchar(300) NOT NULL,
  `cabin` varchar(300) NOT NULL,
  `sharing` varchar(300) NOT NULL,
  `seats` int(11) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`cruise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_hotel_accomodation_master`
--

CREATE TABLE IF NOT EXISTS `package_hotel_accomodation_master` (
  `id` int(50) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `city_id` varchar(200) NOT NULL,
  `hotel_id` varchar(200) NOT NULL,
  `from_date` datetime NOT NULL,
  `to_date` datetime NOT NULL,
  `rooms` varchar(200) NOT NULL,
  `catagory` varchar(200) NOT NULL,
  `room_type` varchar(100) NOT NULL,
  `meal_plan` varchar(100) NOT NULL,
  `confirmation_no` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_payment_master`
--

CREATE TABLE IF NOT EXISTS `package_payment_master` (
  `payment_id` int(100) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `payment_for` varchar(100) NOT NULL,
  `travel_type` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `advance_status` varchar(30) NOT NULL,
  `amount_transfer_date` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_plane_master`
--

CREATE TABLE IF NOT EXISTS `package_plane_master` (
  `plane_id` int(20) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `date` datetime NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(50) NOT NULL,
  `to_location` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `arraval_time` datetime NOT NULL,
  PRIMARY KEY (`plane_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_quotation_program`
--

CREATE TABLE IF NOT EXISTS `package_quotation_program` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `attraction` varchar(150) NOT NULL,
  `day_wise_program` varchar(2000) NOT NULL,
  `stay` varchar(80) NOT NULL,
  `meal_plan` varchar(10) NOT NULL,
  `day_count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_receipt_master`
--

CREATE TABLE IF NOT EXISTS `package_receipt_master` (
  `receipt_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `payment_id` varchar(50) NOT NULL,
  `receipt_for` varchar(100) NOT NULL,
  `receipt_of` varchar(100) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_refund_traveler_cancalation_entries`
--

CREATE TABLE IF NOT EXISTS `package_refund_traveler_cancalation_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `traveler_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_refund_traveler_cancelation`
--

CREATE TABLE IF NOT EXISTS `package_refund_traveler_cancelation` (
  `refund_id` int(30) NOT NULL,
  `booking_id` varchar(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `total_refund` decimal(50,2) NOT NULL,
  `refund_mode` varchar(50) NOT NULL,
  `refund_date` date NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `unique_timestamp` varchar(400) NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_refund_traveler_estimate`
--

CREATE TABLE IF NOT EXISTS `package_refund_traveler_estimate` (
  `estimate_id` int(100) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `cancel_amount` decimal(10,0) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_booking_master`
--

CREATE TABLE IF NOT EXISTS `package_tour_booking_master` (
  `booking_id` int(100) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `dest_id` int(11) NOT NULL,
  `new_package_id` int(11) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `tour_name` varchar(200) NOT NULL,
  `package_id` int(11) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `tour_from_date` date NOT NULL,
  `tour_to_date` date NOT NULL,
  `total_tour_days` varchar(100) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `required_rooms` varchar(100) NOT NULL,
  `child_with_bed` varchar(100) NOT NULL,
  `child_without_bed` varchar(100) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `country_name` varchar(300) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `train_upload_ticket` varchar(700) NOT NULL,
  `plane_upload_ticket` varchar(700) NOT NULL,
  `cruise_upload_ticket` varchar(700) NOT NULL,
  `driver_name` varchar(200) NOT NULL,
  `train_expense` decimal(50,2) NOT NULL,
  `train_service_charge` decimal(50,2) NOT NULL,
  `train_taxation_id` int(50) NOT NULL,
  `train_service_tax` varchar(100) NOT NULL,
  `train_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_train_expense` decimal(50,2) NOT NULL,
  `plane_expense` decimal(50,2) NOT NULL,
  `plane_service_charge` decimal(50,2) NOT NULL,
  `plane_taxation_id` int(50) NOT NULL,
  `plane_service_tax` varchar(100) NOT NULL,
  `plane_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_plane_expense` decimal(50,2) NOT NULL,
  `cruise_expense` decimal(50,2) NOT NULL,
  `cruise_service_charge` decimal(50,2) NOT NULL,
  `cruise_taxation_id` int(11) NOT NULL,
  `cruise_service_tax` decimal(50,2) NOT NULL,
  `cruise_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_cruise_expense` decimal(50,2) NOT NULL,
  `total_travel_expense` decimal(50,2) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_amount` decimal(50,2) NOT NULL,
  `visa_service_charge` decimal(50,2) NOT NULL,
  `visa_taxation_id` int(50) NOT NULL,
  `visa_service_tax` varchar(200) NOT NULL,
  `visa_service_tax_subtotal` decimal(50,2) NOT NULL,
  `visa_total_amount` decimal(50,2) NOT NULL,
  `insuarance_company_name` varchar(100) NOT NULL,
  `insuarance_amount` decimal(50,2) NOT NULL,
  `insuarance_service_charge` decimal(50,2) NOT NULL,
  `insuarance_taxation_id` int(50) NOT NULL,
  `insuarance_service_tax` varchar(100) NOT NULL,
  `insuarance_service_tax_subtotal` decimal(50,2) NOT NULL,
  `insuarance_total_amount` decimal(50,2) NOT NULL,
  `total_hotel_expense` decimal(50,2) NOT NULL,
  `total_tour_expense` decimal(50,2) NOT NULL,
  `subtotal` decimal(50,2) NOT NULL,
  `tour_taxation_id` int(50) NOT NULL,
  `tour_service_tax` varchar(100) NOT NULL,
  `tour_service_tax_subtotal` decimal(50,2) NOT NULL,
  `currency_code` varchar(100) NOT NULL,
  `rue_cost` decimal(50,2) NOT NULL,
  `subtotal_with_rue` decimal(50,2) NOT NULL,
  `tour_cost_total` decimal(50,2) NOT NULL,
  `actual_tour_expense` decimal(50,2) NOT NULL,
  `special_request` varchar(500) NOT NULL,
  `booking_date` datetime NOT NULL,
  `due_date` date NOT NULL,
  `feedback_mail_status` varchar(100) NOT NULL,
  `unique_timestamp` varchar(600) NOT NULL,
  `tour_status` varchar(200) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_estimate_expense`
--

CREATE TABLE IF NOT EXISTS `package_tour_estimate_expense` (
  `expense_id` int(100) NOT NULL,
  `expense_name` varchar(350) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_excursion_master`
--

CREATE TABLE IF NOT EXISTS `package_tour_excursion_master` (
  `entry_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `exc_id` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_hotel_service_voucher`
--

CREATE TABLE IF NOT EXISTS `package_tour_hotel_service_voucher` (
  `enquiry_id` int(50) NOT NULL,
  `hotel_accomodation_id` int(50) NOT NULL,
  PRIMARY KEY (`enquiry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_hotel_service_voucher1`
--

CREATE TABLE IF NOT EXISTS `package_tour_hotel_service_voucher1` (
  `enquiry_id` int(11) NOT NULL,
  `hotel_accomodation_id` int(11) NOT NULL,
  `confirm_by` varchar(200) NOT NULL,
  `terms_conditions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_costing_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_costing_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `tour_cost` decimal(50,2) NOT NULL,
  `markup_cost` decimal(50,2) NOT NULL,
  `markup_subtotal` decimal(50,2) NOT NULL,
  `excursion_cost` decimal(50,2) NOT NULL,
  `taxation_id` decimal(50,2) NOT NULL,
  `service_tax` decimal(50,2) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_tour_cost` decimal(50,2) NOT NULL,
  `package_id` int(11) NOT NULL,
  `transport_cost` decimal(50,2) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_cost` decimal(50,2) NOT NULL,
  `infant_cost` decimal(50,2) NOT NULL,
  `child_with` decimal(50,2) NOT NULL,
  `child_without` decimal(50,2) NOT NULL,
  `extra_bedc` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_cruise_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_cruise_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `dept_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `route` varchar(300) NOT NULL,
  `cabin` varchar(150) NOT NULL,
  `sharing` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_excursion_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_excursion_entries` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `city_name` int(11) NOT NULL,
  `excursion_name` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `excursion_amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_hotel_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_hotel_entries` (
  `id` int(50) NOT NULL,
  `quotation_id` int(50) NOT NULL,
  `city_name` varchar(300) NOT NULL,
  `hotel_name` varchar(200) NOT NULL,
  `room_category` varchar(50) NOT NULL,
  `hotel_type` varchar(150) NOT NULL,
  `total_days` varchar(100) NOT NULL,
  `package_id` int(11) NOT NULL,
  `total_rooms` int(11) NOT NULL,
  `hotel_cost` decimal(50,2) NOT NULL,
  `extra_bed` int(11) NOT NULL,
  `extra_bed_cost` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_images`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_images` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `image_url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_master`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_master` (
  `quotation_id` int(100) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `tour_name` varchar(200) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `total_days` varchar(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `mobile_no` varchar(300) NOT NULL,
  `total_adult` varchar(200) NOT NULL,
  `total_children` varchar(200) NOT NULL,
  `total_infant` varchar(200) NOT NULL,
  `total_passangers` varchar(200) NOT NULL,
  `children_without_bed` varchar(100) NOT NULL,
  `children_with_bed` varchar(100) NOT NULL,
  `quotation_date` date NOT NULL,
  `booking_type` varchar(100) NOT NULL,
  `train_cost` decimal(50,2) NOT NULL,
  `flight_cost` decimal(50,2) NOT NULL,
  `cruise_cost` decimal(50,2) NOT NULL,
  `visa_cost` decimal(50,2) NOT NULL,
  `guide_cost` decimal(50,2) NOT NULL,
  `misc_cost` decimal(50,2) NOT NULL,
  `price_str_url` text NOT NULL,
  `package_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `login_id` int(200) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `clone` varchar(20) NOT NULL,
  `pckg_daywise_url` mediumtext NOT NULL,
  `costing_type` int(11) NOT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_plane_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_plane_entries` (
  `id` int(50) NOT NULL,
  `quotation_id` int(50) NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(100) NOT NULL,
  `to_location` varchar(100) NOT NULL,
  `airline_name` varchar(200) NOT NULL,
  `class` varchar(100) NOT NULL,
  `arraval_time` datetime NOT NULL,
  `dapart_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_train_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_train_entries` (
  `id` int(50) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `from_location` varchar(100) NOT NULL,
  `to_location` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `arrival_date` datetime NOT NULL,
  `departure_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_quotation_transport_entries2`
--

CREATE TABLE IF NOT EXISTS `package_tour_quotation_transport_entries2` (
  `id` int(11) NOT NULL,
  `quotation_id` int(11) NOT NULL,
  `vehicle_name` varchar(150) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `package_id` int(11) NOT NULL,
  `transport_cost` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_schedule_master`
--

CREATE TABLE IF NOT EXISTS `package_tour_schedule_master` (
  `entry_id` int(50) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `attraction` varchar(150) NOT NULL,
  `day_wise_program` varchar(2000) NOT NULL,
  `stay` varchar(80) NOT NULL,
  `meal_plan` varchar(10) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_transport_master`
--

CREATE TABLE IF NOT EXISTS `package_tour_transport_master` (
  `entry_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `transport_bus_id` int(11) NOT NULL,
  `transport_from_date` date NOT NULL,
  `transport_to_date` date NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_transport_service_voucher`
--

CREATE TABLE IF NOT EXISTS `package_tour_transport_service_voucher` (
  `id` int(50) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `special_arrangments` text NOT NULL,
  `confirm_by` text NOT NULL,
  `inclusions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_tour_transport_voucher_entries`
--

CREATE TABLE IF NOT EXISTS `package_tour_transport_voucher_entries` (
  `entry_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `transport_bus_id` int(11) NOT NULL,
  `pick_up_from` varchar(50) NOT NULL,
  `drop_to` varchar(50) NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `driver_contact` varchar(50) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_train_master`
--

CREATE TABLE IF NOT EXISTS `package_train_master` (
  `train_id` int(30) NOT NULL,
  `booking_id` int(50) NOT NULL,
  `date` datetime NOT NULL,
  `from_location` varchar(50) NOT NULL,
  `to_location` varchar(50) NOT NULL,
  `train_no` varchar(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `train_priority` varchar(50) NOT NULL,
  `train_class` varchar(20) NOT NULL,
  `service_charge` varchar(20) NOT NULL,
  PRIMARY KEY (`train_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_travelers_details`
--

CREATE TABLE IF NOT EXISTS `package_travelers_details` (
  `traveler_id` int(20) NOT NULL,
  `booking_id` int(100) NOT NULL,
  `m_honorific` varchar(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `birth_date` date NOT NULL,
  `age` varchar(20) NOT NULL,
  `adolescence` varchar(20) NOT NULL,
  `passport_no` varchar(200) NOT NULL,
  `passport_issue_date` varchar(100) NOT NULL,
  `passport_expiry_date` varchar(100) NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`traveler_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_master`
--

CREATE TABLE IF NOT EXISTS `passport_master` (
  `passport_id` int(100) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `passport_issue_amount` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(50) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `passport_total_cost` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`passport_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_master_entries`
--

CREATE TABLE IF NOT EXISTS `passport_master_entries` (
  `entry_id` int(100) NOT NULL,
  `passport_id` int(50) NOT NULL,
  `honorific` varchar(100) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `received_documents` text NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_payment_master`
--

CREATE TABLE IF NOT EXISTS `passport_payment_master` (
  `payment_id` int(100) NOT NULL,
  `passport_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_refund_entries`
--

CREATE TABLE IF NOT EXISTS `passport_refund_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `entry_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_refund_master`
--

CREATE TABLE IF NOT EXISTS `passport_refund_master` (
  `refund_id` int(50) NOT NULL,
  `passport_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_charges` decimal(50,2) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passport_vendor`
--

CREATE TABLE IF NOT EXISTS `passport_vendor` (
  `vendor_id` int(100) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_master`
--

CREATE TABLE IF NOT EXISTS `payment_master` (
  `payment_id` int(50) NOT NULL,
  `tourwise_traveler_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `payment_for` varchar(100) NOT NULL,
  `travel_type` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `advance_status` varchar(30) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `amount_transfer_date` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plane_master`
--

CREATE TABLE IF NOT EXISTS `plane_master` (
  `plane_id` int(20) NOT NULL,
  `tourwise_traveler_id` int(20) NOT NULL,
  `date` datetime NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `from_location` varchar(50) NOT NULL,
  `to_location` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `arraval_time` datetime NOT NULL,
  PRIMARY KEY (`plane_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_master`
--

CREATE TABLE IF NOT EXISTS `receipt_master` (
  `receipt_id` int(50) NOT NULL,
  `tourwise_traveler_id` int(50) NOT NULL,
  `payment_id` varchar(50) NOT NULL,
  `receipt_for` varchar(100) NOT NULL,
  `receipt_of` varchar(100) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `references_master`
--

CREATE TABLE IF NOT EXISTS `references_master` (
  `reference_id` int(100) NOT NULL,
  `reference_name` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  PRIMARY KEY (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `references_master`
--

INSERT INTO `references_master` (`reference_id`, `reference_name`, `created_at`, `active_flag`) VALUES
(1, 'Corporate', '0000-00-00 00:00:00', 'Active'),
(2, 'Walkin', '0000-00-00 00:00:00', 'Active'),
(3, 'B2B', '0000-00-00 00:00:00', 'Active'),
(4, 'Social Media', '0000-00-00 00:00:00', 'Active'),
(5, 'Website', '0000-00-00 00:00:00', 'Active'),
(6, 'Customer Reference', '0000-00-00 00:00:00', 'Active'),
(7, 'Telephone', '0000-00-00 00:00:00', 'Active'),
(8, 'Advertise', '0000-00-00 00:00:00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `refund_tour_cancelation`
--

CREATE TABLE IF NOT EXISTS `refund_tour_cancelation` (
  `refund_id` int(30) NOT NULL,
  `tourwise_traveler_id` int(30) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `traveler_id` varchar(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_mode` varchar(20) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `refund_date` varchar(30) NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refund_tour_estimate`
--

CREATE TABLE IF NOT EXISTS `refund_tour_estimate` (
  `estimate_id` int(100) NOT NULL,
  `tourwise_traveler_id` int(100) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refund_traveler_cancalation_entries`
--

CREATE TABLE IF NOT EXISTS `refund_traveler_cancalation_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `traveler_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refund_traveler_cancelation`
--

CREATE TABLE IF NOT EXISTS `refund_traveler_cancelation` (
  `refund_id` int(30) NOT NULL,
  `tourwise_traveler_id` varchar(20) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `total_refund` decimal(50,2) NOT NULL,
  `refund_mode` varchar(50) NOT NULL,
  `refund_date` date NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `bank_id` int(100) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `unique_timestamp` varchar(400) NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refund_traveler_estimate`
--

CREATE TABLE IF NOT EXISTS `refund_traveler_estimate` (
  `estimate_id` int(100) NOT NULL,
  `tourwise_traveler_id` int(100) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refund_travel_extra_amount`
--

CREATE TABLE IF NOT EXISTS `refund_travel_extra_amount` (
  `refund_id` int(50) NOT NULL,
  `tourwise_traveler_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_mode` varchar(100) NOT NULL,
  `refund_date` date NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `remainder_status`
--

CREATE TABLE IF NOT EXISTS `remainder_status` (
  `id` int(200) NOT NULL,
  `remainder_name` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(30) NOT NULL,
  `role_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `emp_id` int(30) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_id`, `branch_admin_id`, `emp_id`, `user_name`, `password`, `active_flag`) VALUES
(1, 1, 0, 0, 'travwold', 'travwold6300', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `role_master`
--

CREATE TABLE IF NOT EXISTS `role_master` (
  `role_id` int(40) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_master`
--

INSERT INTO `role_master` (`role_id`, `role_name`, `active_flag`) VALUES
(1, 'Admin', 'Active'),
(2, 'Sales', 'Active'),
(3, 'Backoffice', 'Active'),
(4, 'B2b', 'Active'),
(5, 'Branch Admin', 'Active'),
(6, 'Hr', 'Active'),
(7, 'Accountant', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `room_category_master`
--

CREATE TABLE IF NOT EXISTS `room_category_master` (
  `entry_id` int(11) NOT NULL,
  `room_category` varchar(50) NOT NULL,
  `active_status` varchar(10) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_category_master`
--

INSERT INTO `room_category_master` (`entry_id`, `room_category`, `active_status`) VALUES
(1, 'Deluxe', 'Active'),
(2, 'Semi Deluxe', 'Active'),
(3, 'Super Deluxe', 'Active'),
(4, 'Standard', 'Active'),
(5, 'Suit', 'Active'),
(6, 'Superior', 'Active'),
(7, 'Premium', 'Active'),
(8, 'Luxury', 'Active'),
(9, 'Super Luxury', 'Active'),
(10, 'Villa', 'Active'),
(11, 'Hall', 'Active'),
(12, 'Economy', 'Active'),
(13, 'Royal Suite', 'Active'),
(14, 'Executive Suite', 'Active'),
(15, 'Apartment', 'Active'),
(16, 'Connecting Rooms', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `sac_master`
--

CREATE TABLE IF NOT EXISTS `sac_master` (
  `sac_id` int(200) NOT NULL,
  `service_name` varchar(200) NOT NULL,
  `hsn_sac_code` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`sac_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sac_master`
--

INSERT INTO `sac_master` (`sac_id`, `service_name`, `hsn_sac_code`, `created_at`) VALUES
(1, 'Flight', '996334', '2018-04-18'),
(2, 'Train', '996335', '2018-04-18'),
(3, 'Package Tour', '998552', '2018-04-18'),
(4, 'Visa', '1345345', '2018-04-18'),
(5, 'Travel Insurance', '997136', '2018-04-18'),
(6, 'Hotel / Accommodation', '998552', '2018-04-18'),
(7, 'Bus', '996422', '2018-04-18'),
(8, 'Car Rental', '996601', '2018-04-18'),
(9, 'Passport', '123456', '2018-04-18'),
(10, 'Forex', '997157', '2018-04-18'),
(11, 'Excursion', '123456', '2018-08-01'),
(12, 'Group Tour', '66666677', '2018-08-02'),
(13, 'Other Expense', '1234566', '2019-01-03'),
(14, 'Miscellaneous', '999799', '2019-04-25');

-- --------------------------------------------------------

--
-- Table structure for table `sales_projection`
--

CREATE TABLE IF NOT EXISTS `sales_projection` (
  `id` int(200) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `total_g` decimal(50,2) NOT NULL,
  `total_p` decimal(50,2) NOT NULL,
  `total_b` decimal(50,2) NOT NULL,
  `total_c` decimal(50,2) NOT NULL,
  `total_pp` decimal(50,2) NOT NULL,
  `total_h` decimal(50,2) NOT NULL,
  `total_v` decimal(50,2) NOT NULL,
  `total_t` decimal(50,2) NOT NULL,
  `total_f` decimal(50,2) NOT NULL,
  `total` decimal(50,2) NOT NULL,
  `bud_strong_g` decimal(50,2) NOT NULL,
  `bud_cold_g` decimal(50,2) NOT NULL,
  `bud_hot_g` decimal(50,2) NOT NULL,
  `bud_strong_p` decimal(50,2) NOT NULL,
  `bud_hot_p` decimal(50,2) NOT NULL,
  `bud_cold_p` decimal(50,2) NOT NULL,
  `bud_strong_pp` decimal(50,2) NOT NULL,
  `bud_cold_pp` decimal(50,2) NOT NULL,
  `bud_hot_pp` decimal(50,2) NOT NULL,
  `bud_strong_v` decimal(50,2) NOT NULL,
  `bud_hot_v` decimal(50,2) NOT NULL,
  `bud_cold_v` decimal(50,2) NOT NULL,
  `bud_hot_t` decimal(50,2) NOT NULL,
  `bud_strong_t` decimal(50,2) NOT NULL,
  `bud_cold_t` decimal(50,2) NOT NULL,
  `bud_strong_f` decimal(50,2) NOT NULL,
  `bud_hot_f` decimal(50,2) NOT NULL,
  `bud_cold_f` decimal(50,2) NOT NULL,
  `bud_strong_h` decimal(50,2) NOT NULL,
  `bud_hot_h` decimal(50,2) NOT NULL,
  `bud_cold_h` decimal(50,2) NOT NULL,
  `bud_strong_c` decimal(50,2) NOT NULL,
  `bud_hot_c` decimal(50,2) NOT NULL,
  `bud_cold_c` decimal(50,2) NOT NULL,
  `bud_strong_b` decimal(50,2) NOT NULL,
  `bud_hot_b` decimal(50,2) NOT NULL,
  `bud_cold_b` decimal(50,2) NOT NULL,
  `pro_s_g` decimal(50,2) NOT NULL,
  `pro_h_g` decimal(50,2) NOT NULL,
  `pro_c_g` decimal(50,2) NOT NULL,
  `pro_s_p` decimal(50,2) NOT NULL,
  `pro_h_p` decimal(50,2) NOT NULL,
  `pro_c_p` decimal(50,2) NOT NULL,
  `pro_s_v` decimal(50,2) NOT NULL,
  `pro_c_v` decimal(50,2) NOT NULL,
  `pro_h_v` decimal(50,2) NOT NULL,
  `pro_s_pp` decimal(50,2) NOT NULL,
  `pro_c_pp` decimal(50,2) NOT NULL,
  `pro_h_pp` decimal(50,2) NOT NULL,
  `pro_s_f` decimal(50,2) NOT NULL,
  `pro_c_f` decimal(50,2) NOT NULL,
  `pro_h_f` decimal(50,2) NOT NULL,
  `pro_s_t` decimal(50,2) NOT NULL,
  `pro_c_t` decimal(50,2) NOT NULL,
  `pro_h_t` decimal(50,2) NOT NULL,
  `pro_s_c` decimal(50,2) NOT NULL,
  `pro_c_c` decimal(50,2) NOT NULL,
  `pro_h_c` decimal(50,2) NOT NULL,
  `pro_s_h` decimal(50,2) NOT NULL,
  `pro_c_h` decimal(50,2) NOT NULL,
  `pro_h_h` decimal(50,2) NOT NULL,
  `pro_s_b` decimal(50,2) NOT NULL,
  `pro_c_b` decimal(50,2) NOT NULL,
  `pro_h_b` decimal(50,2) NOT NULL,
  `total_ms` decimal(50,2) NOT NULL,
  `bud_strong_ms` decimal(50,2) NOT NULL,
  `bud_cold_ms` decimal(50,2) NOT NULL,
  `bud_hot_ms` decimal(50,2) NOT NULL,
  `pro_s_ms` decimal(50,2) NOT NULL,
  `pro_h_ms` decimal(50,2) NOT NULL,
  `pro_c_ms` decimal(50,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `site_seeing_vendor`
--

CREATE TABLE IF NOT EXISTS `site_seeing_vendor` (
  `vendor_id` int(50) NOT NULL,
  `city_id` int(11) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `mobile_no` varchar(300) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `concern_person_name` varchar(300) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(150) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_email_id`
--

CREATE TABLE IF NOT EXISTS `sms_email_id` (
  `email_id_id` int(11) NOT NULL,
  `email_id` varchar(150) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`email_id_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_group_entries`
--

CREATE TABLE IF NOT EXISTS `sms_group_entries` (
  `id` int(100) NOT NULL,
  `sms_group_id` int(50) NOT NULL,
  `mobile_no_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_group_master`
--

CREATE TABLE IF NOT EXISTS `sms_group_master` (
  `sms_group_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `sms_group_name` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`sms_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_message_master`
--

CREATE TABLE IF NOT EXISTS `sms_message_master` (
  `sms_message_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `message` text NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`sms_message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_mobile_no`
--

CREATE TABLE IF NOT EXISTS `sms_mobile_no` (
  `mobile_no_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`mobile_no_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_sending_log`
--

CREATE TABLE IF NOT EXISTS `sms_sending_log` (
  `log_id` int(100) NOT NULL,
  `sms_message_id` int(50) NOT NULL,
  `sms_group_id` int(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state_and_cities`
--

CREATE TABLE IF NOT EXISTS `state_and_cities` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(23) DEFAULT NULL,
  `city_state` varchar(27) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=606 ;

--
-- Dumping data for table `state_and_cities`
--

INSERT INTO `state_and_cities` (`id`, `city_name`, `city_state`) VALUES
(1, 'North and Middle Andama', 'Andaman and Nicobar'),
(2, 'South Andaman', 'Andaman and Nicobar'),
(3, 'Nicobar', 'Andaman and Nicobar'),
(4, 'Adilabad', 'Andhra Pradesh'),
(5, 'Anantapur', 'Andhra Pradesh'),
(6, 'Chittoor', 'Andhra Pradesh'),
(7, 'East Godavari', 'Andhra Pradesh'),
(8, 'Guntur', 'Andhra Pradesh'),
(9, 'Hyderabad', 'Andhra Pradesh'),
(10, 'Kadapa', 'Andhra Pradesh'),
(11, 'Karimnagar', 'Andhra Pradesh'),
(12, 'Khammam', 'Andhra Pradesh'),
(13, 'Krishna', 'Andhra Pradesh'),
(14, 'Kurnool', 'Andhra Pradesh'),
(15, 'Mahbubnagar', 'Andhra Pradesh'),
(16, 'Medak', 'Andhra Pradesh'),
(17, 'Nalgonda', 'Andhra Pradesh'),
(18, 'Nellore', 'Andhra Pradesh'),
(19, 'Nizamabad', 'Andhra Pradesh'),
(20, 'Prakasam', 'Andhra Pradesh'),
(21, 'Rangareddi', 'Andhra Pradesh'),
(22, 'Srikakulam', 'Andhra Pradesh'),
(23, 'Vishakhapatnam', 'Andhra Pradesh'),
(24, 'Vizianagaram', 'Andhra Pradesh'),
(25, 'Warangal', 'Andhra Pradesh'),
(26, 'West Godavari', 'Andhra Pradesh'),
(27, 'Anjaw', 'Arunachal Pradesh'),
(28, 'Changlang', 'Arunachal Pradesh'),
(29, 'East Kameng', 'Arunachal Pradesh'),
(30, 'Lohit', 'Arunachal Pradesh'),
(31, 'Lower Subansiri', 'Arunachal Pradesh'),
(32, 'Papum Pare', 'Arunachal Pradesh'),
(33, 'Tirap', 'Arunachal Pradesh'),
(34, 'Dibang Valley', 'Arunachal Pradesh'),
(35, 'Upper Subansiri', 'Arunachal Pradesh'),
(36, 'West Kameng', 'Arunachal Pradesh'),
(37, 'Barpeta', 'Assam'),
(38, 'Bongaigaon', 'Assam'),
(39, 'Cachar', 'Assam'),
(40, 'Darrang', 'Assam'),
(41, 'Dhemaji', 'Assam'),
(42, 'Dhubri', 'Assam'),
(43, 'Dibrugarh', 'Assam'),
(44, 'Goalpara', 'Assam'),
(45, 'Golaghat', 'Assam'),
(46, 'Hailakandi', 'Assam'),
(47, 'Jorhat', 'Assam'),
(48, 'Karbi Anglong', 'Assam'),
(49, 'Karimganj', 'Assam'),
(50, 'Kokrajhar', 'Assam'),
(51, 'Lakhimpur', 'Assam'),
(52, 'Marigaon', 'Assam'),
(53, 'Nagaon', 'Assam'),
(54, 'Nalbari', 'Assam'),
(55, 'North Cachar Hills', 'Assam'),
(56, 'Sibsagar', 'Assam'),
(57, 'Sonitpur', 'Assam'),
(58, 'Tinsukia', 'Assam'),
(59, NULL, 'Bihar'),
(60, 'Araria', 'Bihar'),
(61, 'Aurangabad', 'Bihar'),
(62, 'Banka', 'Bihar'),
(63, 'Begusarai', 'Bihar'),
(64, 'Bhagalpur', 'Bihar'),
(65, 'Bhojpur', 'Bihar'),
(66, 'Buxar', 'Bihar'),
(67, 'Darbhanga', 'Bihar'),
(68, 'Purba Champaran', 'Bihar'),
(69, 'Gaya', 'Bihar'),
(70, 'Gopalganj', 'Bihar'),
(71, 'Jamui', 'Bihar'),
(72, 'Jehanabad', 'Bihar'),
(73, 'Khagaria', 'Bihar'),
(74, 'Kishanganj', 'Bihar'),
(75, 'Kaimur', 'Bihar'),
(76, 'Katihar', 'Bihar'),
(77, 'Lakhisarai', 'Bihar'),
(78, 'Madhubani', 'Bihar'),
(79, 'Munger', 'Bihar'),
(80, 'Madhepura', 'Bihar'),
(81, 'Muzaffarpur', 'Bihar'),
(82, 'Nalanda', 'Bihar'),
(83, 'Nawada', 'Bihar'),
(84, 'Patna', 'Bihar'),
(85, 'Purnia', 'Bihar'),
(86, 'Rohtas', 'Bihar'),
(87, 'Saharsa', 'Bihar'),
(88, 'Samastipur', 'Bihar'),
(89, 'Sheohar', 'Bihar'),
(90, 'Sheikhpura', 'Bihar'),
(91, 'Saran', 'Bihar'),
(92, 'Sitamarhi', 'Bihar'),
(93, 'Supaul', 'Bihar'),
(94, 'Siwan', 'Bihar'),
(95, 'Vaishali', 'Bihar'),
(96, 'Pashchim Champaran', 'Bihar'),
(97, 'Bastar', 'Chhattisgarh'),
(98, 'Bilaspur', 'Chhattisgarh'),
(99, 'Dantewada', 'Chhattisgarh'),
(100, 'Dhamtari', 'Chhattisgarh'),
(101, 'Durg', 'Chhattisgarh'),
(102, 'Jashpur', 'Chhattisgarh'),
(103, 'Janjgir-Champa', 'Chhattisgarh'),
(104, 'Korba', 'Chhattisgarh'),
(105, 'Koriya', 'Chhattisgarh'),
(106, 'Kanker', 'Chhattisgarh'),
(107, 'Kawardha', 'Chhattisgarh'),
(108, 'Mahasamund', 'Chhattisgarh'),
(109, 'Raigarh', 'Chhattisgarh'),
(110, 'Rajnandgaon', 'Chhattisgarh'),
(111, 'Raipur', 'Chhattisgarh'),
(112, 'Surguja', 'Chhattisgarh'),
(113, 'Diu', 'Daman and Diu'),
(114, 'Daman', 'Daman and Diu'),
(115, 'Central Delhi', 'Delhi'),
(116, 'East Delhi', 'Delhi'),
(117, 'New Delhi', 'Delhi'),
(118, 'North Delhi', 'Delhi'),
(119, 'North East Delhi', 'Delhi'),
(120, 'North West Delhi', 'Delhi'),
(121, 'South Delhi', 'Delhi'),
(122, 'South West Delhi', 'Delhi'),
(123, 'West Delhi', 'Delhi'),
(124, 'North Goa', 'Goa'),
(125, 'South Goa', 'Goa'),
(126, 'Ahmedabad', 'Gujarat'),
(127, 'Amreli District', 'Gujarat'),
(128, 'Anand', 'Gujarat'),
(129, 'Banaskantha', 'Gujarat'),
(130, 'Bharuch', 'Gujarat'),
(131, 'Bhavnagar', 'Gujarat'),
(132, 'Dahod', 'Gujarat'),
(133, 'The Dangs', 'Gujarat'),
(134, 'Gandhinagar', 'Gujarat'),
(135, 'Jamnagar', 'Gujarat'),
(136, 'Junagadh', 'Gujarat'),
(137, 'Kutch', 'Gujarat'),
(138, 'Kheda', 'Gujarat'),
(139, 'Mehsana', 'Gujarat'),
(140, 'Narmada', 'Gujarat'),
(141, 'Navsari', 'Gujarat'),
(142, 'Patan', 'Gujarat'),
(143, 'Panchmahal', 'Gujarat'),
(144, 'Porbandar', 'Gujarat'),
(145, 'Rajkot', 'Gujarat'),
(146, 'Sabarkantha', 'Gujarat'),
(147, 'Surendranagar', 'Gujarat'),
(148, 'Surat', 'Gujarat'),
(149, 'Vadodara', 'Gujarat'),
(150, 'Valsad', 'Gujarat'),
(151, NULL, 'Haryana'),
(152, 'Ambala', 'Haryana'),
(153, 'Bhiwani', 'Haryana'),
(154, 'Faridabad', 'Haryana'),
(155, 'Fatehabad', 'Haryana'),
(156, 'Gurgaon', 'Haryana'),
(157, 'Hissar', 'Haryana'),
(158, 'Jhajjar', 'Haryana'),
(159, 'Jind', 'Haryana'),
(160, 'Karnal', 'Haryana'),
(161, 'Kaithal', 'Haryana'),
(162, 'Kurukshetra', 'Haryana'),
(163, 'Mahendragarh', 'Haryana'),
(164, 'Mewat', 'Haryana'),
(165, 'Panchkula', 'Haryana'),
(166, 'Panipat', 'Haryana'),
(167, 'Rewari', 'Haryana'),
(168, 'Rohtak', 'Haryana'),
(169, 'Sirsa', 'Haryana'),
(170, 'Sonepat', 'Haryana'),
(171, 'Yamuna Nagar', 'Haryana'),
(172, 'Palwal', 'Haryana'),
(173, 'Bilaspur', 'Himachal Pradesh'),
(174, 'Chamba', 'Himachal Pradesh'),
(175, 'Hamirpur', 'Himachal Pradesh'),
(176, 'Kangra', 'Himachal Pradesh'),
(177, 'Kinnaur', 'Himachal Pradesh'),
(178, 'Kulu', 'Himachal Pradesh'),
(179, 'Lahaul and Spiti', 'Himachal Pradesh'),
(180, 'Mandi', 'Himachal Pradesh'),
(181, 'Shimla', 'Himachal Pradesh'),
(182, 'Sirmaur', 'Himachal Pradesh'),
(183, 'Solan', 'Himachal Pradesh'),
(184, 'Una', 'Himachal Pradesh'),
(185, 'Anantnag', 'Jammu and Kashmir'),
(186, 'Badgam', 'Jammu and Kashmir'),
(187, 'Bandipore', 'Jammu and Kashmir'),
(188, 'Baramula', 'Jammu and Kashmir'),
(189, 'Doda', 'Jammu and Kashmir'),
(190, 'Jammu', 'Jammu and Kashmir'),
(191, 'Kargil', 'Jammu and Kashmir'),
(192, 'Kathua', 'Jammu and Kashmir'),
(193, 'Kupwara', 'Jammu and Kashmir'),
(194, 'Leh', 'Jammu and Kashmir'),
(195, 'Poonch', 'Jammu and Kashmir'),
(196, 'Pulwama', 'Jammu and Kashmir'),
(197, 'Rajauri', 'Jammu and Kashmir'),
(198, 'Srinagar', 'Jammu and Kashmir'),
(199, 'Samba', 'Jammu and Kashmir'),
(200, 'Udhampur', 'Jammu and Kashmir'),
(201, 'Bokaro', 'Jharkhand'),
(202, 'Chatra', 'Jharkhand'),
(203, 'Deoghar', 'Jharkhand'),
(204, 'Dhanbad', 'Jharkhand'),
(205, 'Dumka', 'Jharkhand'),
(206, 'Purba Singhbhum', 'Jharkhand'),
(207, 'Garhwa', 'Jharkhand'),
(208, 'Giridih', 'Jharkhand'),
(209, 'Godda', 'Jharkhand'),
(210, 'Gumla', 'Jharkhand'),
(211, 'Hazaribagh', 'Jharkhand'),
(212, 'Koderma', 'Jharkhand'),
(213, 'Lohardaga', 'Jharkhand'),
(214, 'Pakur', 'Jharkhand'),
(215, 'Palamu', 'Jharkhand'),
(216, 'Ranchi', 'Jharkhand'),
(217, 'Sahibganj', 'Jharkhand'),
(218, 'Seraikela and Kharsawan', 'Jharkhand'),
(219, 'Pashchim Singhbhum', 'Jharkhand'),
(220, 'Ramgarh', 'Jharkhand'),
(221, 'Bidar', 'Karnataka'),
(222, 'Belgaum', 'Karnataka'),
(223, 'Bijapur', 'Karnataka'),
(224, 'Bagalkot', 'Karnataka'),
(225, 'Bellary', 'Karnataka'),
(226, 'Bangalore Rural Distric', 'Karnataka'),
(227, 'Bangalore Urban Distric', 'Karnataka'),
(228, 'Chamarajnagar', 'Karnataka'),
(229, 'Chikmagalur', 'Karnataka'),
(230, 'Chitradurga', 'Karnataka'),
(231, 'Davanagere', 'Karnataka'),
(232, 'Dharwad', 'Karnataka'),
(233, 'Dakshina Kannada', 'Karnataka'),
(234, 'Gadag', 'Karnataka'),
(235, 'Gulbarga', 'Karnataka'),
(236, 'Hassan', 'Karnataka'),
(237, 'Haveri District', 'Karnataka'),
(238, 'Kodagu', 'Karnataka'),
(239, 'Kolar', 'Karnataka'),
(240, 'Koppal', 'Karnataka'),
(241, 'Mandya', 'Karnataka'),
(242, 'Mysore', 'Karnataka'),
(243, 'Raichur', 'Karnataka'),
(244, 'Shimoga', 'Karnataka'),
(245, 'Tumkur', 'Karnataka'),
(246, 'Udupi', 'Karnataka'),
(247, 'Uttara Kannada', 'Karnataka'),
(248, 'Ramanagara', 'Karnataka'),
(249, 'Chikballapur', 'Karnataka'),
(250, 'Yadagiri', 'Karnataka'),
(251, 'Alappuzha', 'Kerala'),
(252, 'Ernakulam', 'Kerala'),
(253, 'Idukki', 'Kerala'),
(254, 'Kollam', 'Kerala'),
(255, 'Kannur', 'Kerala'),
(256, 'Kasaragod', 'Kerala'),
(257, 'Kottayam', 'Kerala'),
(258, 'Kozhikode', 'Kerala'),
(259, 'Malappuram', 'Kerala'),
(260, 'Palakkad', 'Kerala'),
(261, 'Pathanamthitta', 'Kerala'),
(262, 'Thrissur', 'Kerala'),
(263, 'Thiruvananthapuram', 'Kerala'),
(264, 'Wayanad', 'Kerala'),
(265, 'Alirajpur', 'Madhya Pradesh'),
(266, 'Anuppur', 'Madhya Pradesh'),
(267, 'Ashok Nagar', 'Madhya Pradesh'),
(268, 'Balaghat', 'Madhya Pradesh'),
(269, 'Barwani', 'Madhya Pradesh'),
(270, 'Betul', 'Madhya Pradesh'),
(271, 'Bhind', 'Madhya Pradesh'),
(272, 'Bhopal', 'Madhya Pradesh'),
(273, 'Burhanpur', 'Madhya Pradesh'),
(274, 'Chhatarpur', 'Madhya Pradesh'),
(275, 'Chhindwara', 'Madhya Pradesh'),
(276, 'Damoh', 'Madhya Pradesh'),
(277, 'Datia', 'Madhya Pradesh'),
(278, 'Dewas', 'Madhya Pradesh'),
(279, 'Dhar', 'Madhya Pradesh'),
(280, 'Dindori', 'Madhya Pradesh'),
(281, 'Guna', 'Madhya Pradesh'),
(282, 'Gwalior', 'Madhya Pradesh'),
(283, 'Harda', 'Madhya Pradesh'),
(284, 'Hoshangabad', 'Madhya Pradesh'),
(285, 'Indore', 'Madhya Pradesh'),
(286, 'Jabalpur', 'Madhya Pradesh'),
(287, 'Jhabua', 'Madhya Pradesh'),
(288, 'Katni', 'Madhya Pradesh'),
(289, 'Khandwa', 'Madhya Pradesh'),
(290, 'Khargone', 'Madhya Pradesh'),
(291, 'Mandla', 'Madhya Pradesh'),
(292, 'Mandsaur', 'Madhya Pradesh'),
(293, 'Morena', 'Madhya Pradesh'),
(294, 'Narsinghpur', 'Madhya Pradesh'),
(295, 'Neemuch', 'Madhya Pradesh'),
(296, 'Panna', 'Madhya Pradesh'),
(297, 'Rewa', 'Madhya Pradesh'),
(298, 'Rajgarh', 'Madhya Pradesh'),
(299, 'Ratlam', 'Madhya Pradesh'),
(300, 'Raisen', 'Madhya Pradesh'),
(301, 'Sagar', 'Madhya Pradesh'),
(302, 'Satna', 'Madhya Pradesh'),
(303, 'Sehore', 'Madhya Pradesh'),
(304, 'Seoni', 'Madhya Pradesh'),
(305, 'Shahdol', 'Madhya Pradesh'),
(306, 'Shajapur', 'Madhya Pradesh'),
(307, 'Sheopur', 'Madhya Pradesh'),
(308, 'Shivpuri', 'Madhya Pradesh'),
(309, 'Sidhi', 'Madhya Pradesh'),
(310, 'Singrauli', 'Madhya Pradesh'),
(311, 'Tikamgarh', 'Madhya Pradesh'),
(312, 'Ujjain', 'Madhya Pradesh'),
(313, 'Umaria', 'Madhya Pradesh'),
(314, 'Vidisha', 'Madhya Pradesh'),
(315, 'Ahmednagar', 'Maharashtra'),
(316, 'Akola', 'Maharashtra'),
(317, 'Amrawati', 'Maharashtra'),
(318, 'Aurangabad', 'Maharashtra'),
(319, 'Bhandara', 'Maharashtra'),
(320, 'Beed', 'Maharashtra'),
(321, 'Buldhana', 'Maharashtra'),
(322, 'Chandrapur', 'Maharashtra'),
(323, 'Dhule', 'Maharashtra'),
(324, 'Gadchiroli', 'Maharashtra'),
(325, 'Gondiya', 'Maharashtra'),
(326, 'Hingoli', 'Maharashtra'),
(327, 'Jalgaon', 'Maharashtra'),
(328, 'Jalna', 'Maharashtra'),
(329, 'Kolhapur', 'Maharashtra'),
(330, 'Latur', 'Maharashtra'),
(331, 'Mumbai City', 'Maharashtra'),
(332, 'Mumbai suburban', 'Maharashtra'),
(333, 'Nandurbar', 'Maharashtra'),
(334, 'Nanded', 'Maharashtra'),
(335, 'Nagpur', 'Maharashtra'),
(336, 'Nashik', 'Maharashtra'),
(337, 'Osmanabad', 'Maharashtra'),
(338, 'Parbhani', 'Maharashtra'),
(339, 'Pune', 'Maharashtra'),
(340, 'Raigad', 'Maharashtra'),
(341, 'Ratnagiri', 'Maharashtra'),
(342, 'Sindhudurg', 'Maharashtra'),
(343, 'Sangli', 'Maharashtra'),
(344, 'Solapur', 'Maharashtra'),
(345, 'Satara', 'Maharashtra'),
(346, 'Thane', 'Maharashtra'),
(347, 'Wardha', 'Maharashtra'),
(348, 'Washim', 'Maharashtra'),
(349, 'Yavatmal', 'Maharashtra'),
(350, 'Bishnupur', 'Manipur'),
(351, 'Churachandpur', 'Manipur'),
(352, 'Chandel', 'Manipur'),
(353, 'Imphal East', 'Manipur'),
(354, 'Senapati', 'Manipur'),
(355, 'Tamenglong', 'Manipur'),
(356, 'Thoubal', 'Manipur'),
(357, 'Ukhrul', 'Manipur'),
(358, 'Imphal West', 'Manipur'),
(359, 'East Garo Hills', 'Meghalaya'),
(360, 'East Khasi Hills', 'Meghalaya'),
(361, 'Jaintia Hills', 'Meghalaya'),
(362, 'Ri-Bhoi', 'Meghalaya'),
(363, 'South Garo Hills', 'Meghalaya'),
(364, 'West Garo Hills', 'Meghalaya'),
(365, 'West Khasi Hills', 'Meghalaya'),
(366, 'Aizawl', 'Mizoram'),
(367, 'Champhai', 'Mizoram'),
(368, 'Kolasib', 'Mizoram'),
(369, 'Lawngtlai', 'Mizoram'),
(370, 'Lunglei', 'Mizoram'),
(371, 'Mamit', 'Mizoram'),
(372, 'Saiha', 'Mizoram'),
(373, 'Serchhip', 'Mizoram'),
(374, 'Dimapur', 'Nagaland'),
(375, 'Kohima', 'Nagaland'),
(376, 'Mokokchung', 'Nagaland'),
(377, 'Mon', 'Nagaland'),
(378, 'Phek', 'Nagaland'),
(379, 'Tuensang', 'Nagaland'),
(380, 'Wokha', 'Nagaland'),
(381, 'Zunheboto', 'Nagaland'),
(382, 'Angul', 'Orissa'),
(383, 'Boudh', 'Orissa'),
(384, 'Bhadrak', 'Orissa'),
(385, 'Bolangir', 'Orissa'),
(386, 'Bargarh', 'Orissa'),
(387, 'Baleswar', 'Orissa'),
(388, 'Cuttack', 'Orissa'),
(389, 'Debagarh', 'Orissa'),
(390, 'Dhenkanal', 'Orissa'),
(391, 'Ganjam', 'Orissa'),
(392, 'Gajapati', 'Orissa'),
(393, 'Jharsuguda', 'Orissa'),
(394, 'Jajapur', 'Orissa'),
(395, 'Jagatsinghpur', 'Orissa'),
(396, 'Khordha', 'Orissa'),
(397, 'Kendujhar', 'Orissa'),
(398, 'Kalahandi', 'Orissa'),
(399, 'Kandhamal', 'Orissa'),
(400, 'Koraput', 'Orissa'),
(401, 'Kendrapara', 'Orissa'),
(402, 'Malkangiri', 'Orissa'),
(403, 'Mayurbhanj', 'Orissa'),
(404, 'Nabarangpur', 'Orissa'),
(405, 'Nuapada', 'Orissa'),
(406, 'Nayagarh', 'Orissa'),
(407, 'Puri', 'Orissa'),
(408, 'Rayagada', 'Orissa'),
(409, 'Sambalpur', 'Orissa'),
(410, 'Subarnapur', 'Orissa'),
(411, 'Sundargarh', 'Orissa'),
(412, 'Karaikal', 'Puducherry'),
(413, 'Mahe', 'Puducherry'),
(414, 'Puducherry', 'Puducherry'),
(415, 'Yanam', 'Puducherry'),
(416, 'Amritsar', 'Punjab'),
(417, 'Bathinda', 'Punjab'),
(418, 'Firozpur', 'Punjab'),
(419, 'Faridkot', 'Punjab'),
(420, 'Fatehgarh Sahib', 'Punjab'),
(421, 'Gurdaspur', 'Punjab'),
(422, 'Hoshiarpur', 'Punjab'),
(423, 'Jalandhar', 'Punjab'),
(424, 'Kapurthala', 'Punjab'),
(425, 'Ludhiana', 'Punjab'),
(426, 'Mansa', 'Punjab'),
(427, 'Moga', 'Punjab'),
(428, 'Mukatsar', 'Punjab'),
(429, 'Nawan Shehar', 'Punjab'),
(430, 'Patiala', 'Punjab'),
(431, 'Rupnagar', 'Punjab'),
(432, 'Sangrur', 'Punjab'),
(433, 'Ajmer', 'Rajasthan'),
(434, 'Alwar', 'Rajasthan'),
(435, 'Bikaner', 'Rajasthan'),
(436, 'Barmer', 'Rajasthan'),
(437, 'Banswara', 'Rajasthan'),
(438, 'Bharatpur', 'Rajasthan'),
(439, 'Baran', 'Rajasthan'),
(440, 'Bundi', 'Rajasthan'),
(441, 'Bhilwara', 'Rajasthan'),
(442, 'Churu', 'Rajasthan'),
(443, 'Chittorgarh', 'Rajasthan'),
(444, 'Dausa', 'Rajasthan'),
(445, 'Dholpur', 'Rajasthan'),
(446, 'Dungapur', 'Rajasthan'),
(447, 'Ganganagar', 'Rajasthan'),
(448, 'Hanumangarh', 'Rajasthan'),
(449, 'Juhnjhunun', 'Rajasthan'),
(450, 'Jalore', 'Rajasthan'),
(451, 'Jodhpur', 'Rajasthan'),
(452, 'Jaipur', 'Rajasthan'),
(453, 'Jaisalmer', 'Rajasthan'),
(454, 'Jhalawar', 'Rajasthan'),
(455, 'Karauli', 'Rajasthan'),
(456, 'Kota', 'Rajasthan'),
(457, 'Nagaur', 'Rajasthan'),
(458, 'Pali', 'Rajasthan'),
(459, 'Pratapgarh', 'Rajasthan'),
(460, 'Rajsamand', 'Rajasthan'),
(461, 'Sikar', 'Rajasthan'),
(462, 'Sawai Madhopur', 'Rajasthan'),
(463, 'Sirohi', 'Rajasthan'),
(464, 'Tonk', 'Rajasthan'),
(465, 'Udaipur', 'Rajasthan'),
(466, 'East Sikkim', 'Sikkim'),
(467, 'North Sikkim', 'Sikkim'),
(468, 'South Sikkim', 'Sikkim'),
(469, 'West Sikkim', 'Sikkim'),
(470, 'Ariyalur', 'Tamil Nadu'),
(471, 'Chennai', 'Tamil Nadu'),
(472, 'Coimbatore', 'Tamil Nadu'),
(473, 'Cuddalore', 'Tamil Nadu'),
(474, 'Dharmapuri', 'Tamil Nadu'),
(475, 'Dindigul', 'Tamil Nadu'),
(476, 'Erode', 'Tamil Nadu'),
(477, 'Kanchipuram', 'Tamil Nadu'),
(478, 'Kanyakumari', 'Tamil Nadu'),
(479, 'Karur', 'Tamil Nadu'),
(480, 'Madurai', 'Tamil Nadu'),
(481, 'Nagapattinam', 'Tamil Nadu'),
(482, 'The Nilgiris', 'Tamil Nadu'),
(483, 'Namakkal', 'Tamil Nadu'),
(484, 'Perambalur', 'Tamil Nadu'),
(485, 'Pudukkottai', 'Tamil Nadu'),
(486, 'Ramanathapuram', 'Tamil Nadu'),
(487, 'Salem', 'Tamil Nadu'),
(488, 'Sivagangai', 'Tamil Nadu'),
(489, 'Tiruppur', 'Tamil Nadu'),
(490, 'Tiruchirappalli', 'Tamil Nadu'),
(491, 'Theni', 'Tamil Nadu'),
(492, 'Tirunelveli', 'Tamil Nadu'),
(493, 'Thanjavur', 'Tamil Nadu'),
(494, 'Thoothukudi', 'Tamil Nadu'),
(495, 'Thiruvallur', 'Tamil Nadu'),
(496, 'Thiruvarur', 'Tamil Nadu'),
(497, 'Tiruvannamalai', 'Tamil Nadu'),
(498, 'Vellore', 'Tamil Nadu'),
(499, 'Villupuram', 'Tamil Nadu'),
(500, 'Dhalai', 'Tripura'),
(501, 'North Tripura', 'Tripura'),
(502, 'South Tripura', 'Tripura'),
(503, 'West Tripura', 'Tripura'),
(504, 'Almora', 'Uttarakhand'),
(505, 'Bageshwar', 'Uttarakhand'),
(506, 'Chamoli', 'Uttarakhand'),
(507, 'Champawat', 'Uttarakhand'),
(508, 'Dehradun', 'Uttarakhand'),
(509, 'Haridwar', 'Uttarakhand'),
(510, 'Nainital', 'Uttarakhand'),
(511, 'Pauri Garhwal', 'Uttarakhand'),
(512, 'Pithoragharh', 'Uttarakhand'),
(513, 'Rudraprayag', 'Uttarakhand'),
(514, 'Tehri Garhwal', 'Uttarakhand'),
(515, 'Udham Singh Nagar', 'Uttarakhand'),
(516, 'Uttarkashi', 'Uttarakhand'),
(517, 'Agra', 'Uttar Pradesh'),
(518, 'Allahabad', 'Uttar Pradesh'),
(519, 'Aligarh', 'Uttar Pradesh'),
(520, 'Ambedkar Nagar', 'Uttar Pradesh'),
(521, 'Auraiya', 'Uttar Pradesh'),
(522, 'Azamgarh', 'Uttar Pradesh'),
(523, 'Barabanki', 'Uttar Pradesh'),
(524, 'Badaun', 'Uttar Pradesh'),
(525, 'Bagpat', 'Uttar Pradesh'),
(526, 'Bahraich', 'Uttar Pradesh'),
(527, 'Bijnor', 'Uttar Pradesh'),
(528, 'Ballia', 'Uttar Pradesh'),
(529, 'Banda', 'Uttar Pradesh'),
(530, 'Balrampur', 'Uttar Pradesh'),
(531, 'Bareilly', 'Uttar Pradesh'),
(532, 'Basti', 'Uttar Pradesh'),
(533, 'Bulandshahr', 'Uttar Pradesh'),
(534, 'Chandauli', 'Uttar Pradesh'),
(535, 'Chitrakoot', 'Uttar Pradesh'),
(536, 'Deoria', 'Uttar Pradesh'),
(537, 'Etah', 'Uttar Pradesh'),
(538, 'Kanshiram Nagar', 'Uttar Pradesh'),
(539, 'Etawah', 'Uttar Pradesh'),
(540, 'Firozabad', 'Uttar Pradesh'),
(541, 'Farrukhabad', 'Uttar Pradesh'),
(542, 'Fatehpur', 'Uttar Pradesh'),
(543, 'Faizabad', 'Uttar Pradesh'),
(544, 'Gautam Buddha Nagar', 'Uttar Pradesh'),
(545, 'Gonda', 'Uttar Pradesh'),
(546, 'Ghazipur', 'Uttar Pradesh'),
(547, 'Gorkakhpur', 'Uttar Pradesh'),
(548, 'Ghaziabad', 'Uttar Pradesh'),
(549, 'Hamirpur', 'Uttar Pradesh'),
(550, 'Hardoi', 'Uttar Pradesh'),
(551, 'Mahamaya Nagar', 'Uttar Pradesh'),
(552, 'Jhansi', 'Uttar Pradesh'),
(553, 'Jalaun', 'Uttar Pradesh'),
(554, 'Jyotiba Phule Nagar', 'Uttar Pradesh'),
(555, 'Jaunpur District', 'Uttar Pradesh'),
(556, 'Kanpur Dehat', 'Uttar Pradesh'),
(557, 'Kannauj', 'Uttar Pradesh'),
(558, 'Kanpur Nagar', 'Uttar Pradesh'),
(559, 'Kaushambi', 'Uttar Pradesh'),
(560, 'Kushinagar', 'Uttar Pradesh'),
(561, 'Lalitpur', 'Uttar Pradesh'),
(562, 'Lakhimpur Kheri', 'Uttar Pradesh'),
(563, 'Lucknow', 'Uttar Pradesh'),
(564, 'Mau', 'Uttar Pradesh'),
(565, 'Meerut', 'Uttar Pradesh'),
(566, 'Maharajganj', 'Uttar Pradesh'),
(567, 'Mahoba', 'Uttar Pradesh'),
(568, 'Mirzapur', 'Uttar Pradesh'),
(569, 'Moradabad', 'Uttar Pradesh'),
(570, 'Mainpuri', 'Uttar Pradesh'),
(571, 'Mathura', 'Uttar Pradesh'),
(572, 'Muzaffarnagar', 'Uttar Pradesh'),
(573, 'Pilibhit', 'Uttar Pradesh'),
(574, 'Pratapgarh', 'Uttar Pradesh'),
(575, 'Rampur', 'Uttar Pradesh'),
(576, 'Rae Bareli', 'Uttar Pradesh'),
(577, 'Saharanpur', 'Uttar Pradesh'),
(578, 'Sitapur', 'Uttar Pradesh'),
(579, 'Shahjahanpur', 'Uttar Pradesh'),
(580, 'Sant Kabir Nagar', 'Uttar Pradesh'),
(581, 'Siddharthnagar', 'Uttar Pradesh'),
(582, 'Sonbhadra', 'Uttar Pradesh'),
(583, 'Sant Ravidas Nagar', 'Uttar Pradesh'),
(584, 'Sultanpur', 'Uttar Pradesh'),
(585, 'Shravasti', 'Uttar Pradesh'),
(586, 'Unnao', 'Uttar Pradesh'),
(587, 'Varanasi', 'Uttar Pradesh'),
(588, 'Birbhum', 'West Bengal'),
(589, 'Bankura', 'West Bengal'),
(590, 'Bardhaman', 'West Bengal'),
(591, 'Darjeeling', 'West Bengal'),
(592, 'Dakshin Dinajpur', 'West Bengal'),
(593, 'Hooghly', 'West Bengal'),
(594, 'Howrah', 'West Bengal'),
(595, 'Jalpaiguri', 'West Bengal'),
(596, 'Cooch Behar', 'West Bengal'),
(597, 'Kolkata', 'West Bengal'),
(598, 'Malda', 'West Bengal'),
(599, 'Midnapore', 'West Bengal'),
(600, 'Murshidabad', 'West Bengal'),
(601, 'Nadia', 'West Bengal'),
(602, 'North 24 Parganas', 'West Bengal'),
(603, 'South 24 Parganas', 'West Bengal'),
(604, 'Purulia', 'West Bengal'),
(605, 'Uttar Dinajpur', 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE IF NOT EXISTS `state_master` (
  `id` int(200) NOT NULL,
  `state_name` varchar(200) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`id`, `state_name`, `active_flag`) VALUES
(1, 'Overseas', 'Active'),
(2, 'Local', 'Active'),
(3, 'Andaman and Nicobar Islands(35)', 'Active'),
(4, 'Andhra Pradesh(28)', 'Active'),
(5, 'Andhra Pradesh (New)(37)', 'Active'),
(6, ' Arunachal Pradesh(12)', 'Active'),
(7, 'Assam(18)', 'Active'),
(8, 'Bihar(10)', 'Active'),
(9, 'Chandigarh(04)', 'Active'),
(10, 'Dadra and Nagar Haveli(26)', 'Active'),
(11, 'Daman and Diu(25)', 'Active'),
(12, 'Delhi(07)', 'Active'),
(13, 'Gujarat(24)', 'Active'),
(14, 'Haryana(06)', 'Active'),
(15, 'Himachal Pradesh(02)', 'Active'),
(16, 'Jammu and Kashmir(01)', 'Active'),
(17, 'Jharkhand(20)', 'Active'),
(18, 'Karnataka(29)', 'Active'),
(19, 'Kerala(32)', 'Active'),
(20, 'Lakshadweep Islands(31)', 'Active'),
(21, 'Madhya Pradesh(23)', 'Active'),
(22, 'Maharashtra(27)', 'Active'),
(23, 'Manipur(14)', 'Active'),
(24, 'Meghalaya(17)', 'Active'),
(25, 'Mizoram(15)', 'Active'),
(26, 'Nagaland(13)', 'Active'),
(27, 'Odisha(21)', 'Active'),
(28, 'Pondicherry(34)', 'Active'),
(29, 'Punjab(03)', 'Active'),
(30, 'Rajasthan', 'Active'),
(31, 'Sikkim(11)', 'Active'),
(32, 'Tamil Nadu(33)', 'Active'),
(33, 'Telangana(36)', 'Active'),
(34, 'Tripura(16)', 'Active'),
(35, 'Uttar Pradesh(09)', 'Active'),
(36, 'Uttarakhand(05)', 'Active'),
(37, 'West Bengal(19)', 'Active'),
(38, 'Goa', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `subgroup_master`
--

CREATE TABLE IF NOT EXISTS `subgroup_master` (
  `subgroup_id` int(11) NOT NULL,
  `subgroup_name` varchar(300) NOT NULL,
  `group_id` int(11) NOT NULL,
  `dr_cr` varchar(200) NOT NULL,
  PRIMARY KEY (`subgroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subgroup_master`
--

INSERT INTO `subgroup_master` (`subgroup_id`, `subgroup_name`, `group_id`, `dr_cr`) VALUES
(1, 'Capital', 1, 'Cr'),
(2, 'Cash & Cash Equivalents', 2, 'Dr'),
(3, 'Expense (Direct)', 3, 'Dr'),
(4, 'Fixed Assets', 4, 'Dr'),
(5, 'Income (Direct)', 5, 'Cr'),
(6, 'Income (Indirect)', 6, 'Cr'),
(7, 'Indirect Expenses_Staff', 7, 'Dr'),
(8, 'Indirect Expenses_Finance', 8, 'Dr'),
(9, 'Indirect Expenses_Other', 9, 'Dr'),
(10, 'Long Term Borrowing', 10, 'Cr'),
(11, 'Long Term Loans & Advances', 11, 'Dr'),
(12, 'Long Term Provisions', 12, 'Cr'),
(13, 'Non-current Investments', 13, 'Dr'),
(14, 'Other Current Liabilities', 14, 'Cr'),
(15, 'Reserves & Surplus', 15, 'Cr'),
(16, 'Short Term Borrowings', 16, 'Cr'),
(17, 'Short Term Loans & Advances', 17, 'Dr'),
(18, 'Short Term Provisions', 18, 'Cr'),
(19, 'Expense (Other Direct)', 19, 'Dr'),
(20, 'Trade Receivables', 20, 'Dr'),
(21, 'Unsecured Loan', 21, 'Cr'),
(22, 'Advance from customers', 14, 'Cr'),
(23, 'Advances to Suppliers', 17, 'Dr'),
(24, 'Bank Balances', 2, 'Dr'),
(25, 'Bank Overdraft', 16, 'Cr'),
(26, 'Bus Booking Expenses', 3, 'Dr'),
(27, 'Bus Cancellation Expenses', 3, 'Dr'),
(28, 'Capital Advances', 11, 'Dr'),
(29, 'Capital Redemption Reserve', 15, 'Cr'),
(30, 'Capital Reserves', 15, 'Cr'),
(31, 'Car Rental Booking Expenses', 3, 'Dr'),
(32, 'Car Rental Cancellation Expenses', 3, 'Dr'),
(33, 'Cash in Hand', 2, 'Dr'),
(34, 'Commission from Insurance Services', 5, 'Cr'),
(35, 'Communication Expenses', 9, 'Dr'),
(36, 'Cruise Booking Expenses', 3, 'Dr'),
(37, 'Cruise Cancellation Expenses', 3, 'Dr'),
(38, 'Deffered Payment Liabilities', 10, 'Cr'),
(39, 'Deposits (Liabilities)', 10, 'Cr'),
(40, 'Depreciation ', 9, 'Dr'),
(41, 'Dividend received', 6, 'Cr'),
(42, 'DMC Booking Expenses', 3, 'Dr'),
(43, 'Electricity', 9, 'Dr'),
(44, 'Employee Benefit Expenses', 7, 'Dr'),
(45, 'Excursion Cancellation Expenses', 3, 'Dr'),
(46, 'Excursion Purchased', 3, 'Dr'),
(47, 'Finance Charges', 8, 'Dr'),
(48, 'Flight Booking Expenses', 3, 'Dr'),
(49, 'Flight Cancellation Expenses', 3, 'Dr'),
(50, 'Foreign Exchange Gain', 6, 'Cr'),
(51, 'Foreign Exchange Loss', 9, 'Dr'),
(52, 'Gain/(Loss) on Sale of Investment', 6, 'Cr'),
(53, 'Gain/(Loss) on Sale or disposal of Fixed Assets', 6, 'Cr'),
(54, 'General Reserve', 15, 'Cr'),
(55, 'Hotel Booking Expenses', 3, 'Dr'),
(56, 'Hotel Cancellation Expenses', 3, 'Dr'),
(57, 'Housekeeping & Office Maintenance', 9, 'Dr'),
(58, 'Income received in advance', 14, 'Cr'),
(59, 'Insurance Premium Paid', 9, 'Dr'),
(60, 'Intangible Asset', 4, 'Dr'),
(61, 'Interest Accrued but due', 14, 'Cr'),
(62, 'Interest Accrued but not due', 14, 'Cr'),
(63, 'Interest received', 6, 'Cr'),
(64, 'Invesment in Debentures & Bonds', 13, 'Dr'),
(65, 'Invesment in Equity Shares', 13, 'Dr'),
(66, 'Invesment in Government Securities', 13, 'Dr'),
(67, 'Invesment in Mutual Funds', 13, 'Dr'),
(68, 'Invesment in Preference Shares', 13, 'Dr'),
(69, 'Legal & professional Fees', 9, 'Dr'),
(70, 'Loans & Advances from Related Parties', 10, 'Cr'),
(71, 'Loans & Advances to Related Parties', 11, 'Dr'),
(72, 'Miscelleneous Expenses', 9, 'Dr'),
(73, 'Other Cancellation Charges Paid', 3, 'Dr'),
(74, 'Other Vehicle Rental Expenses', 3, 'Dr'),
(75, 'Petrol & Diesel', 9, 'Dr'),
(76, 'Printing & Stationery Expenses', 9, 'Dr'),
(77, 'Provisions for Gratuity (Long Term)', 12, 'Cr'),
(78, 'Provsion for gratuity (Short Term)', 18, 'Cr'),
(79, 'Purchase Return', 3, 'Dr'),
(80, 'Rates & Taxes', 9, 'Dr'),
(81, 'Rent', 9, 'Dr'),
(82, 'Repairs & Maintenance', 9, 'Dr'),
(83, 'Revaluation Reserve', 15, 'Cr'),
(84, 'Salaries & Wages', 7, 'Dr'),
(85, 'Salary & Other payables', 14, 'Cr'),
(86, 'Sale of Scrap', 6, 'Cr'),
(87, 'Sale of Services', 5, 'Cr'),
(88, 'Sales Promotion Expenses', 9, 'Dr'),
(89, 'Sales Return', 5, 'Dr'),
(90, 'Securities Premium Reserve', 15, 'Cr'),
(91, 'Security Deposits (Liability)', 11, 'Dr'),
(92, 'Security Expenses', 9, 'Dr'),
(93, 'Service Charges Received', 6, 'Cr'),
(94, 'Share Capital', 1, 'Cr'),
(95, 'Sight Seeing Cancellation Expenses', 3, 'Dr'),
(96, 'Sight Seeing Expenses', 3, 'Dr'),
(97, 'Staff Recruitment Expenses', 9, 'Dr'),
(98, 'Staff training Expenses', 9, 'Dr'),
(99, 'Statutory Dues', 14, 'Cr'),
(100, 'Tangible Asset', 4, 'Dr'),
(101, 'Train Ticket Cancellation  Expenses', 3, 'Dr'),
(102, 'Train Ticket Expenses', 3, 'Dr'),
(103, 'Travelling Cost', 9, 'Dr'),
(104, 'Unpaid dividends', 14, 'Cr'),
(105, 'Trade Payable', 14, 'Cr'),
(106, 'Gst', 17, 'Dr'),
(107, 'Vat', 17, 'Dr'),
(108, 'Visa Cancellation Expenses', 3, 'Dr'),
(109, 'Passport Cancellation Expenses', 3, 'Dr'),
(110, 'Dmc Cancellation Expenses', 3, 'Dr'),
(111, 'Equity', 1, 'Cr');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_packages`
--

CREATE TABLE IF NOT EXISTS `supplier_packages` (
  `package_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `supplier_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `active_flag` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `image_upload_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_master`
--

CREATE TABLE IF NOT EXISTS `tasks_master` (
  `task_id` int(100) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `task_name` text NOT NULL,
  `due_date` datetime NOT NULL,
  `remind` varchar(200) NOT NULL,
  `remind_due_date` datetime NOT NULL,
  `remind_by` varchar(100) NOT NULL,
  `task_type` varchar(200) NOT NULL,
  `task_type_field_id` varchar(100) NOT NULL,
  `extra_note` text NOT NULL,
  `reference_task_id` int(50) NOT NULL,
  `task_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `status_date` datetime NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `taxation_master`
--

CREATE TABLE IF NOT EXISTS `taxation_master` (
  `taxation_id` int(100) NOT NULL,
  `tax_type_id` int(100) NOT NULL,
  `tax_in_percentage` decimal(50,2) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `gl_id` int(50) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`taxation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tax_country_master`
--

CREATE TABLE IF NOT EXISTS `tax_country_master` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(300) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax_country_master`
--

INSERT INTO `tax_country_master` (`country_id`, `country_name`) VALUES
(1, 'India'),
(2, 'Dubai'),
(3, 'South Africa'),
(4, 'Germany'),
(5, 'Australia');

-- --------------------------------------------------------

--
-- Table structure for table `tax_type_master`
--

CREATE TABLE IF NOT EXISTS `tax_type_master` (
  `tax_type_id` int(50) NOT NULL,
  `tax_type` varchar(200) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`tax_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax_type_master`
--

INSERT INTO `tax_type_master` (`tax_type_id`, `tax_type`, `country_id`) VALUES
(1, 'SGST+CGST', 1),
(2, 'UGST', 1),
(3, 'IGST', 1),
(4, 'VAT', 2),
(5, 'VAT', 3),
(6, 'VAT', 4),
(7, 'SGST+CGST', 5),
(8, 'UGST', 5),
(9, 'IGST', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tds_entry_master`
--

CREATE TABLE IF NOT EXISTS `tds_entry_master` (
  `payment_id` int(100) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_side` varchar(100) NOT NULL,
  `payment_for` varchar(100) NOT NULL,
  `payment_against` text NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `terms_and_conditions`
--

CREATE TABLE IF NOT EXISTS `terms_and_conditions` (
  `terms_and_conditions_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `type` varchar(150) NOT NULL,
  `title` varchar(300) NOT NULL,
  `terms_and_conditions` text NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`terms_and_conditions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master`
--

CREATE TABLE IF NOT EXISTS `ticket_master` (
  `ticket_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `type_of_tour` varchar(100) NOT NULL,
  `due_date` date NOT NULL,
  `adults` varchar(100) NOT NULL,
  `childrens` varchar(100) NOT NULL,
  `infant` varchar(100) NOT NULL,
  `adult_fair` decimal(50,2) NOT NULL,
  `children_fair` decimal(50,2) NOT NULL,
  `infant_fair` decimal(50,2) NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `basic_cost_markup` decimal(50,2) NOT NULL,
  `basic_cost_discount` decimal(50,2) NOT NULL,
  `yq_tax` decimal(50,2) NOT NULL,
  `yq_tax_markup` decimal(50,2) NOT NULL,
  `yq_tax_discount` decimal(50,2) NOT NULL,
  `g1_plus_f2_tax` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` varchar(100) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `ticket_total_cost` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_entries`
--

CREATE TABLE IF NOT EXISTS `ticket_master_entries` (
  `entry_id` int(100) NOT NULL,
  `ticket_id` int(50) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(300) NOT NULL,
  `ticket_no` varchar(300) NOT NULL,
  `gds_pnr` varchar(300) NOT NULL,
  `passport_no` varchar(500) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_expiry_date` date NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_upload_entries`
--

CREATE TABLE IF NOT EXISTS `ticket_master_upload_entries` (
  `entry_id` int(100) NOT NULL,
  `ticket_id` int(100) NOT NULL,
  `ticket_url` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_payment_master`
--

CREATE TABLE IF NOT EXISTS `ticket_payment_master` (
  `payment_id` int(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `ticket_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_refund_entries`
--

CREATE TABLE IF NOT EXISTS `ticket_refund_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `entry_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_refund_master`
--

CREATE TABLE IF NOT EXISTS `ticket_refund_master` (
  `refund_id` int(50) NOT NULL,
  `ticket_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_trip_entries`
--

CREATE TABLE IF NOT EXISTS `ticket_trip_entries` (
  `entry_id` int(100) NOT NULL,
  `ticket_id` int(100) NOT NULL,
  `departure_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `airlines_name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `flight_no` varchar(100) NOT NULL,
  `airlin_pnr` varchar(100) NOT NULL,
  `from_city` int(200) NOT NULL,
  `to_city` int(200) NOT NULL,
  `departure_city` varchar(100) NOT NULL,
  `arrival_city` varchar(100) NOT NULL,
  `meal_plan` text NOT NULL,
  `luggage` text NOT NULL,
  `special_note` text NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_vendor`
--

CREATE TABLE IF NOT EXISTS `ticket_vendor` (
  `vendor_id` int(100) NOT NULL,
  `state_id` int(200) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `website` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` int(11) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tourism_attractions`
--

CREATE TABLE IF NOT EXISTS `tourism_attractions` (
  `attr_id` int(200) NOT NULL,
  `country_id` int(200) NOT NULL,
  `tourist_place` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `image_path` varchar(200) NOT NULL,
  PRIMARY KEY (`attr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tourwise_traveler_details`
--

CREATE TABLE IF NOT EXISTS `tourwise_traveler_details` (
  `id` int(20) NOT NULL,
  `traveler_group_id` int(20) NOT NULL,
  `tour_id` int(20) NOT NULL,
  `tour_group_id` varchar(20) NOT NULL,
  `emp_id` int(20) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `relative_honorofic` varchar(20) NOT NULL,
  `relative_name` varchar(100) NOT NULL,
  `relative_relation` varchar(40) NOT NULL,
  `relative_mobile_no` varchar(30) NOT NULL,
  `s_single_bed_room` int(11) NOT NULL,
  `s_double_bed_room` varchar(50) NOT NULL,
  `s_extra_bed` varchar(50) NOT NULL,
  `s_on_floor` varchar(50) NOT NULL,
  `train_expense` decimal(50,2) NOT NULL,
  `train_service_charge` decimal(50,2) NOT NULL,
  `train_taxation_id` int(50) NOT NULL,
  `train_service_tax` decimal(50,2) NOT NULL,
  `train_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_train_expense` decimal(50,2) NOT NULL,
  `plane_expense` decimal(50,2) NOT NULL,
  `plane_service_charge` decimal(50,2) NOT NULL,
  `plane_taxation_id` varchar(100) NOT NULL,
  `plane_service_tax` decimal(50,2) NOT NULL,
  `plane_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_plane_expense` decimal(50,2) NOT NULL,
  `cruise_expense` decimal(50,2) NOT NULL,
  `cruise_service_charge` decimal(50,2) NOT NULL,
  `cruise_taxation_id` int(11) NOT NULL,
  `cruise_service_tax` decimal(50,2) NOT NULL,
  `cruise_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_cruise_expense` decimal(50,2) NOT NULL,
  `total_travel_expense` decimal(50,2) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_amount` decimal(50,2) NOT NULL,
  `visa_service_charge` decimal(50,2) NOT NULL,
  `visa_taxation_id` int(50) NOT NULL,
  `visa_service_tax` decimal(50,2) NOT NULL,
  `visa_service_tax_subtotal` decimal(50,2) NOT NULL,
  `visa_total_amount` decimal(50,2) NOT NULL,
  `insuarance_company_name` varchar(200) NOT NULL,
  `insuarance_amount` decimal(50,2) NOT NULL,
  `insuarance_service_charge` decimal(50,2) NOT NULL,
  `insuarance_taxation_id` int(50) NOT NULL,
  `insuarance_service_tax` decimal(50,2) NOT NULL,
  `insuarance_service_tax_subtotal` decimal(50,2) NOT NULL,
  `insuarance_total_amount` decimal(50,2) NOT NULL,
  `train_upload_ticket` varchar(300) NOT NULL,
  `plane_upload_ticket` varchar(300) NOT NULL,
  `cruise_upload_ticket` varchar(200) NOT NULL,
  `adult_expense` decimal(50,2) NOT NULL,
  `children_expense` decimal(50,2) NOT NULL,
  `infant_expense` decimal(50,2) NOT NULL,
  `tour_fee` decimal(50,2) NOT NULL,
  `repeater_discount` decimal(50,2) NOT NULL,
  `adjustment_discount` decimal(50,2) NOT NULL,
  `tour_fee_subtotal_1` decimal(50,2) NOT NULL,
  `tour_taxation_id` int(50) NOT NULL,
  `service_tax_per` decimal(50,2) NOT NULL,
  `service_tax` varchar(20) NOT NULL,
  `tour_fee_subtotal_2` decimal(50,2) NOT NULL,
  `total_tour_fee` decimal(50,2) NOT NULL,
  `form_date` varchar(20) NOT NULL,
  `current_booked_seats` varchar(400) NOT NULL,
  `special_request` varchar(600) NOT NULL,
  `balance_due_date` varchar(50) NOT NULL,
  `tour_group_status` varchar(30) NOT NULL,
  `unique_timestamp` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_budget_entities`
--

CREATE TABLE IF NOT EXISTS `tour_budget_entities` (
  `entity_id` int(100) NOT NULL,
  `budget_type_id` int(50) NOT NULL,
  `entity_name` varchar(200) NOT NULL,
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_budget_type`
--

CREATE TABLE IF NOT EXISTS `tour_budget_type` (
  `budget_type_id` int(50) NOT NULL,
  `budget_type` varchar(200) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  PRIMARY KEY (`budget_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour_budget_type`
--

INSERT INTO `tour_budget_type` (`budget_type_id`, `budget_type`, `tour_type`) VALUES
(1, 'Domestic', 'Group Tour'),
(2, 'International', 'Group Tour'),
(3, 'Domestic', 'Package Tour'),
(4, 'International', 'Package Tour');

-- --------------------------------------------------------

--
-- Table structure for table `tour_city_names`
--

CREATE TABLE IF NOT EXISTS `tour_city_names` (
  `id` int(50) NOT NULL,
  `tour_id` int(50) NOT NULL,
  `city_id` int(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_groups`
--

CREATE TABLE IF NOT EXISTS `tour_groups` (
  `group_id` int(10) NOT NULL,
  `tour_id` int(10) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `capacity` varchar(100) NOT NULL,
  `feedback_mail_status` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_master`
--

CREATE TABLE IF NOT EXISTS `tour_master` (
  `tour_id` int(10) NOT NULL,
  `tour_name` varchar(100) NOT NULL,
  `tour_type` varchar(50) NOT NULL,
  `tour_days` varchar(10) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `children_cost` decimal(50,2) NOT NULL,
  `infant_cost` decimal(50,2) NOT NULL,
  `with_bed_cost` decimal(50,2) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  `adnary_url` varchar(200) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `pdf_url` varchar(200) NOT NULL,
  PRIMARY KEY (`tour_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `to_do_entries`
--

CREATE TABLE IF NOT EXISTS `to_do_entries` (
  `id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `entity_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_master`
--

CREATE TABLE IF NOT EXISTS `train_master` (
  `train_id` int(30) NOT NULL,
  `tourwise_traveler_id` int(30) NOT NULL,
  `date` datetime NOT NULL,
  `from_location` varchar(50) NOT NULL,
  `to_location` varchar(50) NOT NULL,
  `train_no` varchar(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `train_priority` varchar(200) NOT NULL,
  `train_class` varchar(500) NOT NULL,
  PRIMARY KEY (`train_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master`
--

CREATE TABLE IF NOT EXISTS `train_ticket_master` (
  `train_ticket_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `type_of_tour` varchar(100) NOT NULL,
  `basic_fair` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `delivery_charges` decimal(50,2) NOT NULL,
  `gst_on` varchar(100) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(100) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `payment_due_date` date NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `refund_net_total` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`train_ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_entries`
--

CREATE TABLE IF NOT EXISTS `train_ticket_master_entries` (
  `entry_id` int(100) NOT NULL,
  `train_ticket_id` int(50) NOT NULL,
  `honorific` varchar(100) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `coach_number` varchar(100) NOT NULL,
  `seat_number` varchar(100) NOT NULL,
  `ticket_number` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_trip_entries`
--

CREATE TABLE IF NOT EXISTS `train_ticket_master_trip_entries` (
  `entry_id` int(100) NOT NULL,
  `train_ticket_id` int(100) NOT NULL,
  `travel_datetime` datetime NOT NULL,
  `travel_from` varchar(300) NOT NULL,
  `travel_to` varchar(300) NOT NULL,
  `train_name` varchar(300) NOT NULL,
  `train_no` varchar(300) NOT NULL,
  `ticket_status` varchar(300) NOT NULL,
  `class` varchar(300) NOT NULL,
  `booking_from` varchar(300) NOT NULL,
  `boarding_at` varchar(300) NOT NULL,
  `arriving_datetime` datetime NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_upload_entries`
--

CREATE TABLE IF NOT EXISTS `train_ticket_master_upload_entries` (
  `entry_id` int(100) NOT NULL,
  `train_ticket_id` int(100) NOT NULL,
  `train_ticket_url` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_payment_master`
--

CREATE TABLE IF NOT EXISTS `train_ticket_payment_master` (
  `payment_id` int(100) NOT NULL,
  `train_ticket_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_refund_entries`
--

CREATE TABLE IF NOT EXISTS `train_ticket_refund_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `entry_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_refund_master`
--

CREATE TABLE IF NOT EXISTS `train_ticket_refund_master` (
  `refund_id` int(50) NOT NULL,
  `train_ticket_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_vendor`
--

CREATE TABLE IF NOT EXISTS `train_ticket_vendor` (
  `vendor_id` int(100) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(100) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transport_agency_bus_master`
--

CREATE TABLE IF NOT EXISTS `transport_agency_bus_master` (
  `bus_id` int(50) NOT NULL,
  `bus_name` varchar(100) NOT NULL,
  `bus_capacity` varchar(100) NOT NULL,
  `per_day_cost` decimal(50,2) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transport_agency_bus_master`
--

INSERT INTO `transport_agency_bus_master` (`bus_id`, `bus_name`, `bus_capacity`, `per_day_cost`, `active_flag`) VALUES
(1, 'Innova', '8', '0.00', 'Active'),
(2, 'Swift Dzire', '8', '0.00', 'Active'),
(3, 'Amaze', '5', '0.00', 'Active'),
(4, 'Honda City', '5', '0.00', 'Active'),
(5, 'Indica', '5', '0.00', 'Active'),
(6, 'Indigo', '5', '0.00', 'Active'),
(7, 'Scorpio', '8', '0.00', 'Active'),
(8, 'Bus', '35', '0.00', 'Active'),
(9, 'Duster', '6', '0.00', 'Active'),
(10, 'Maruti', '4', '0.00', 'Active'),
(11, '15 Seat Traveller', '15', '0.00', 'Active'),
(12, '19 Seat Traveller', '19', '0.00', 'Active'),
(13, '22 Seat Traveller', '19', '0.00', 'Active'),
(14, '30 Seat Traveller', '30', '0.00', 'Active'),
(15, 'SIC', '0', '0.00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `transport_agency_master`
--

CREATE TABLE IF NOT EXISTS `transport_agency_master` (
  `transport_agency_id` int(50) NOT NULL,
  `city_id` int(50) NOT NULL,
  `transport_agency_name` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(100) NOT NULL,
  `transport_agency_address` varchar(500) NOT NULL,
  `country` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(300) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`transport_agency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `travelers_details`
--

CREATE TABLE IF NOT EXISTS `travelers_details` (
  `traveler_id` int(20) NOT NULL,
  `traveler_group_id` int(20) NOT NULL,
  `m_honorific` varchar(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `birth_date` varchar(20) NOT NULL,
  `age` varchar(20) NOT NULL,
  `adolescence` varchar(20) NOT NULL,
  `passport_no` varchar(200) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_expiry_date` date NOT NULL,
  `handover_adnary` varchar(20) NOT NULL,
  `handover_gift` varchar(20) NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`traveler_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `traveler_personal_info`
--

CREATE TABLE IF NOT EXISTS `traveler_personal_info` (
  `personal_info_id` int(50) NOT NULL,
  `tourwise_traveler_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  PRIMARY KEY (`personal_info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_tour_offers_master`
--

CREATE TABLE IF NOT EXISTS `upcoming_tour_offers_master` (
  `offer_id` int(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(700) NOT NULL,
  `valid_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_assigned_roles`
--

CREATE TABLE IF NOT EXISTS `user_assigned_roles` (
  `id` int(100) NOT NULL,
  `role_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `rank` varchar(50) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `description` varchar(400) NOT NULL,
  `icon` text NOT NULL,
  `title` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_assigned_roles`
--

INSERT INTO `user_assigned_roles` (`id`, `role_id`, `name`, `link`, `rank`, `priority`, `description`, `icon`, `title`) VALUES
(4696, 14, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', 'Dashbaord Testing'),
(4697, 14, 'Tour Master', '', '3', '1', '', 'fa fa-book', ''),
(4698, 14, 'Other Masters', 'other_masters/index.php', '3', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(4699, 14, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '3', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(4700, 14, 'Group Tours', 'tours/master/index.php', '3', '2', 'This is tour master', 'fa fa-users', ''),
(4701, 14, 'Package Tours', 'custom_packages/master/index.php', '3', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(4702, 14, 'Visa', 'visa_master/index.php', '3', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(4703, 14, 'Excursion', 'paid_services/index.php', '3', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(4704, 14, 'B2B Packages', 'b2b_packages/index.php', '3', '2', 'B2B Packages', 'fa fa-eye', ''),
(4705, 14, 'Supplier Packages', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(8097, 10, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8098, 10, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8099, 10, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8100, 10, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8101, 10, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8426, 12, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8427, 12, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8428, 12, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(8429, 12, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8430, 12, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8431, 12, 'Tour Master', '', '3', '1', '', 'fa fa-book', ''),
(8432, 12, 'Other Masters', 'other_masters/index.php', '3', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(8433, 12, 'Supplier Master', '', '4', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8434, 12, 'Hotels', 'hotels/master/index.php', '4', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8435, 12, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '4', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8436, 12, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8437, 12, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8438, 12, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '4', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8559, 8, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8560, 8, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8561, 8, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8562, 8, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8563, 8, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(8564, 8, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8565, 8, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8566, 8, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(8567, 8, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(8568, 8, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(8569, 8, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8570, 8, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8571, 8, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(8572, 8, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(8573, 8, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8574, 8, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8575, 8, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(8576, 8, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(8577, 8, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(8578, 8, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(8579, 8, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(8580, 8, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(8581, 8, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(8582, 8, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(8583, 8, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(8584, 8, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(8585, 8, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(8586, 8, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(8587, 8, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(8588, 8, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(8589, 8, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8590, 8, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8591, 8, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8592, 8, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8593, 8, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(8594, 8, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(8595, 8, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(8596, 8, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(8597, 8, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(8598, 8, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(8599, 8, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(8600, 8, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(8601, 8, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(8602, 8, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(8603, 8, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(8604, 8, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(8605, 8, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(8606, 8, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(8607, 8, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(8608, 8, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(8609, 8, 'Complete Tour Cancel', 'tour_cancelation_and_refund/cancel_tour_main.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(8610, 8, 'Complete Tour Refund', 'tour_cancelation_and_refund/refund_tour/refund_cancelled_tour_group.php', '9', '2', 'This is refund of cancelled tour.', 'fa fa-angle-right', ''),
(8611, 8, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(8612, 8, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8613, 8, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(8614, 8, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8615, 8, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(8616, 8, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(8617, 8, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8618, 8, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8619, 8, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(8620, 8, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(8621, 8, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(8622, 8, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(8623, 8, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(8624, 8, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(8625, 8, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(8626, 8, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(8627, 8, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8628, 8, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8629, 8, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8630, 8, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8631, 8, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8632, 8, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(8633, 8, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(8634, 8, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(8635, 8, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(8636, 8, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8637, 8, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8638, 8, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(8639, 8, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(8640, 8, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8641, 8, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8642, 8, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(8643, 8, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8644, 8, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(8645, 8, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(8646, 8, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(8647, 8, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(8648, 8, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(8767, 9, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8768, 9, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8769, 9, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(8770, 9, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(8771, 9, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(8772, 9, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8773, 9, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8774, 9, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(8775, 9, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(8776, 9, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', ''),
(8777, 9, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8778, 9, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8779, 9, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(8780, 9, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(8781, 9, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(8782, 9, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8783, 9, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8784, 9, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(8785, 9, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(8786, 9, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8787, 9, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8788, 9, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(8789, 9, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(8790, 9, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(8791, 9, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(8792, 9, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(8793, 9, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(8794, 9, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(8795, 9, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(8796, 9, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(8797, 9, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(8798, 9, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(8799, 9, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(8800, 9, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(8801, 9, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(8802, 9, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(8803, 9, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(8804, 9, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(8805, 9, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(8806, 9, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(8807, 9, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(8808, 9, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(8809, 9, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8810, 9, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8811, 9, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8812, 9, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8813, 9, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(8814, 9, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(8815, 9, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-print', ''),
(8816, 9, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(8817, 9, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(8818, 9, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(8819, 9, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(8820, 9, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(8821, 9, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(8822, 9, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(8823, 9, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(8824, 9, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(8825, 9, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(8826, 9, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(8827, 9, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(8828, 9, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(8829, 9, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(8830, 9, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(8831, 9, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(8832, 9, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(8833, 9, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(8834, 9, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(8835, 9, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(8836, 9, 'Complete Tour Cancel', 'tour_cancelation_and_refund/cancel_tour_main.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(8837, 9, 'Complete Tour Refund', 'tour_cancelation_and_refund/refund_tour/refund_cancelled_tour_group.php', '9', '2', 'This is refund of cancelled tour.', 'fa fa-angle-right', ''),
(8838, 9, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(8839, 9, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8840, 9, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(8841, 9, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8842, 9, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(8843, 9, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(8844, 9, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(8845, 9, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8846, 9, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8847, 9, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(8848, 9, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(8849, 9, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(8850, 9, 'Miscellaneous Can / Ref', 'miscellaneous/cancel_and_refund/index.php', '9', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(8851, 9, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(8852, 9, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(8853, 9, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(8854, 9, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(8855, 9, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(8856, 9, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8857, 9, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8858, 9, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8859, 9, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8860, 9, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8861, 9, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(8862, 9, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(8863, 9, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(8864, 9, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(8865, 9, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8866, 9, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8867, 9, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8868, 9, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(8869, 9, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(8870, 9, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8871, 9, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8872, 9, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(8873, 9, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8874, 9, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(8875, 9, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(8876, 9, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(8877, 9, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(8878, 9, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(8879, 9, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(8880, 9, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(8881, 9, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(8882, 9, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(8883, 9, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(8884, 9, 'Data Backup', 'backup_installer/index.php', '16', '3', 'Data Backup', 'fa fa-download', ''),
(8885, 7, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8886, 7, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8887, 7, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(8888, 7, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(8889, 7, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(8890, 7, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8891, 7, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8892, 7, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(8893, 7, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(8894, 7, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', ''),
(8895, 7, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8896, 7, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8897, 7, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(8898, 7, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(8899, 7, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(8900, 7, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8901, 7, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8902, 7, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(8903, 7, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(8904, 7, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8905, 7, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8906, 7, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(8907, 7, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(8908, 7, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(8909, 7, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(8910, 7, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(8911, 7, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(8912, 7, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(8913, 7, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(8914, 7, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(8915, 7, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(8916, 7, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(8917, 7, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(8918, 7, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(8919, 7, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(8920, 7, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(8921, 7, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(8922, 7, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(8923, 7, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(8924, 7, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(8925, 7, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(8926, 7, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(8927, 7, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8928, 7, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8929, 7, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8930, 7, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8931, 7, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(8932, 7, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(8933, 7, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-print', ''),
(8934, 7, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(8935, 7, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(8936, 7, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(8937, 7, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(8938, 7, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(8939, 7, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(8940, 7, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(8941, 7, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(8942, 7, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(8943, 7, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(8944, 7, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(8945, 7, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(8946, 7, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(8947, 7, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(8948, 7, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(8949, 7, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(8950, 7, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(8951, 7, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(8952, 7, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(8953, 7, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(8954, 7, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(8955, 7, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8956, 7, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(8957, 7, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8958, 7, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(8959, 7, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(8960, 7, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(8961, 7, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8962, 7, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8963, 7, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(8964, 7, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(8965, 7, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(8966, 7, 'Miscellaneous Can / Ref', 'miscellaneous/cancel_and_refund/index.php', '9', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(8967, 7, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(8968, 7, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(8969, 7, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(8970, 7, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(8971, 7, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(8972, 7, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8973, 7, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8974, 7, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8975, 7, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8976, 7, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8977, 7, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(8978, 7, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(8979, 7, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(8980, 7, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(8981, 7, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8982, 7, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8983, 7, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8984, 7, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(8985, 7, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(8986, 7, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8987, 7, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8988, 7, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(8989, 7, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8990, 7, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(8991, 7, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(8992, 7, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(8993, 7, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(8994, 7, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(8995, 7, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(8996, 7, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(8997, 7, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(8998, 7, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(8999, 7, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(9000, 7, 'Data Backup', 'backup_installer/index.php', '16', '3', 'Data Backup', 'fa fa-download', ''),
(9776, 6, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(9777, 6, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(9778, 6, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(9779, 6, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(9780, 6, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(9781, 6, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(9782, 6, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(9783, 6, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(9784, 6, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(9785, 6, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(9786, 6, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(9787, 6, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(9788, 6, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(9789, 6, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(9790, 6, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(9791, 6, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(9792, 6, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(9793, 6, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(9794, 6, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(9795, 6, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(9796, 6, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(9797, 6, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(9798, 6, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(9799, 6, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(9800, 6, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(9801, 6, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(9802, 6, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(9803, 6, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(9804, 6, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(9805, 6, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(9806, 6, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(9807, 6, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(9808, 6, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(9809, 6, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(9810, 6, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(9811, 6, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(9812, 6, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(9813, 6, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(9814, 6, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(9815, 6, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(9816, 6, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(9817, 6, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(9818, 6, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(9819, 6, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(9820, 6, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(9821, 6, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(9822, 6, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(9823, 6, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(9824, 6, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(9825, 6, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(9826, 6, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(9827, 6, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(9828, 6, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(9829, 6, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(9830, 6, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(9831, 6, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(9832, 6, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(9833, 6, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', '');
INSERT INTO `user_assigned_roles` (`id`, `role_id`, `name`, `link`, `rank`, `priority`, `description`, `icon`, `title`) VALUES
(9834, 6, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(9835, 6, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(9836, 6, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(9837, 6, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(9838, 6, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(9839, 6, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(9840, 6, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(9841, 6, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(9842, 6, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(9843, 6, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(9844, 6, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(9845, 6, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(9846, 6, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(9847, 6, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(9848, 6, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(9849, 6, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(9850, 6, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(9851, 6, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(9852, 6, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(9853, 6, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(9854, 6, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(9855, 6, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(9856, 6, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(9857, 6, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(9858, 6, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(9859, 6, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(9860, 6, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(9861, 6, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(9862, 6, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(9863, 6, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(9864, 6, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(9865, 6, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(9866, 6, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(9867, 6, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(9868, 6, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(9869, 6, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(9870, 6, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(9871, 6, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(9872, 6, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(9873, 6, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(9874, 6, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(9875, 6, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(9876, 6, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(9877, 6, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(9878, 6, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(9879, 6, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(9880, 6, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(9881, 6, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(9882, 6, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(10005, 5, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(10006, 5, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(10007, 5, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(10008, 5, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(10009, 5, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(10010, 5, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(10011, 5, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(10012, 5, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(10013, 5, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', ''),
(10014, 5, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(10015, 5, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(10016, 5, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(10017, 5, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(10018, 5, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(10019, 5, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(10020, 5, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(10021, 5, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(10022, 5, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(10023, 5, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(10024, 5, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(10025, 5, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(10026, 5, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(10027, 5, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(10028, 5, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(10029, 5, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(10030, 5, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(10031, 5, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(10032, 5, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(10033, 5, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(10034, 5, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(10035, 5, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(10036, 5, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(10037, 5, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(10038, 5, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(10039, 5, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(10040, 5, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(10041, 5, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(10042, 5, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(10043, 5, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(10044, 5, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(10045, 5, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(10046, 5, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10047, 5, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10048, 5, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10049, 5, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10050, 5, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(10051, 5, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10052, 5, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10053, 5, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(10054, 5, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(10055, 5, 'Inventory', 'inventory/index.php', '6', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(10056, 5, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(10057, 5, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(10058, 5, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(10059, 5, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(10060, 5, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(10061, 5, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(10062, 5, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(10063, 5, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(10064, 5, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(10065, 5, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(10066, 5, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(10067, 5, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(10068, 5, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(10069, 5, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(10070, 5, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(10071, 5, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(10072, 5, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(10073, 5, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(10074, 5, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(10075, 5, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10076, 5, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(10077, 5, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10078, 5, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(10079, 5, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(10080, 5, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(10081, 5, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10082, 5, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10083, 5, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(10084, 5, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(10085, 5, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(10086, 5, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(10087, 5, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(10088, 5, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(10089, 5, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(10090, 5, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(10091, 5, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(10092, 5, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(10093, 5, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(10094, 5, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(10095, 5, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(10096, 5, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(10097, 5, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(10098, 5, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(10099, 5, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(10100, 5, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10101, 5, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10102, 5, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10103, 5, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(10104, 5, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(10105, 5, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10106, 5, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10107, 5, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(10108, 5, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10109, 5, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(10110, 5, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(10111, 5, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(10112, 5, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(10113, 5, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(10114, 5, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(10115, 5, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(10116, 5, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(10117, 5, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(10118, 5, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(10119, 4, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(10120, 4, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(10121, 4, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(10122, 4, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(10123, 4, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(10124, 4, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(10125, 4, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(10126, 4, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(10127, 4, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(10128, 4, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(10129, 4, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(10130, 4, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(10131, 4, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(10132, 4, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(10133, 4, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(10134, 4, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(10135, 4, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(10136, 4, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(10137, 4, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(10138, 4, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(10139, 4, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(10140, 4, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(10141, 4, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(10142, 4, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(10143, 4, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(10144, 4, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(10145, 4, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(10146, 4, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(10147, 4, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(10148, 4, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(10149, 4, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(10150, 4, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(10151, 4, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(10152, 4, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(10153, 4, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(10154, 4, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(10155, 4, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(10156, 4, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(10157, 4, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(10158, 4, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(10159, 4, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10160, 4, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10161, 4, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10162, 4, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10163, 4, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(10164, 4, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10165, 4, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10166, 4, 'Excursion Service Voucher', 'excursion/service_voucher/index.php', '6', '2', 'This excursion service voucher screen.', 'fa fa-file-image-o', ''),
(10167, 4, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(10168, 4, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(10169, 4, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(10170, 4, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(10171, 4, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(10172, 4, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(10173, 4, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(10174, 4, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(10175, 4, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(10176, 4, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(10177, 4, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(10178, 4, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(10179, 4, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(10180, 4, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(10181, 4, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(10182, 4, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(10183, 4, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(10184, 4, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(10185, 4, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(10186, 4, 'Complete Tour Can/Refund', 'tour_cancelation_and_refund/index.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(10187, 4, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(10188, 4, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10189, 4, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(10190, 4, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10191, 4, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(10192, 4, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(10193, 4, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(10194, 4, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10195, 4, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10196, 4, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(10197, 4, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(10198, 4, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(10199, 4, 'Miscellaneous Can / Ref', 'miscellaneous/cancel_and_refund/index.php', '9', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(10200, 4, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(10201, 4, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(10202, 4, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(10203, 4, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(10204, 4, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(10205, 4, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(10206, 4, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(10207, 4, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(10208, 4, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(10209, 4, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(10210, 4, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(10211, 4, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(10212, 4, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(10213, 4, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(10214, 4, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10215, 4, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10216, 4, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10217, 4, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(10218, 4, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(10219, 4, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10220, 4, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10221, 4, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(10222, 4, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10223, 4, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(10224, 4, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(10225, 4, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(10226, 4, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(10227, 4, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(10228, 4, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(10229, 4, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(10230, 4, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(10231, 4, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(10232, 4, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(10459, 1, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', 'Dashboard Details', 'fa fa-tachometer', ''),
(10460, 1, 'Admin Master', '', '2', '1', 'Admin Master Details', 'fa fa-user', ''),
(10461, 1, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(10462, 1, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(10463, 1, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(10464, 1, 'User Privilege', 'role_mgt/assign_user_roles.php', '2', '2', 'This is form where we assign menu to user.', 'fa fa-users', ''),
(10465, 1, 'Branch Privilege', 'branch_mgt/assign_branch_filter.php', '2', '2', 'This is form where we assign branch to user.', 'fa fa-filter', ''),
(10466, 1, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(10467, 1, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(10468, 1, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(10469, 1, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', ''),
(10470, 1, 'Supplier Management', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(10471, 1, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(10472, 1, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(10473, 1, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(10474, 1, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(10475, 1, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(10476, 1, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(10477, 1, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(10478, 1, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(10479, 1, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(10480, 1, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(10481, 1, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(10482, 1, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(10483, 1, 'Tour Management', '', '4', '1', 'Tour Master Details', 'fa fa-book', ''),
(10484, 1, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(10485, 1, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(10486, 1, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(10487, 1, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(10488, 1, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(10489, 1, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(10490, 1, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(10491, 1, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(10492, 1, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(10493, 1, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(10494, 1, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(10495, 1, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(10496, 1, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(10497, 1, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(10498, 1, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(10499, 1, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(10500, 1, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(10501, 1, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(10502, 1, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10503, 1, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10504, 1, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10505, 1, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(10506, 1, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(10507, 1, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10508, 1, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(10509, 1, 'Excursion Service Voucher', 'excursion/service_voucher/index.php', '6', '2', 'This excursion service voucher screen.', 'fa fa-file-image-o', ''),
(10510, 1, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(10511, 1, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(10512, 1, 'Inventory', 'inventory/index.php', '6', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(10513, 1, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(10514, 1, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(10515, 1, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(10516, 1, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(10517, 1, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(10518, 1, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(10519, 1, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(10520, 1, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(10521, 1, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(10522, 1, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(10523, 1, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(10524, 1, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(10525, 1, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(10526, 1, 'Receipt', '#', '8', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(10527, 1, 'Group Tour', 'group_tour/payment/index.php', '8', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(10528, 1, 'Package Tour', 'package_booking/payments/index.php', '8', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(10529, 1, 'Car Rental', 'car_rental/payment/index.php', '8', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(10530, 1, 'Other Receipts', 'other_receipts/index.php', '8', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(10531, 1, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(10532, 1, 'Complete Tour Can/Refund', 'tour_cancelation_and_refund/index.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(10533, 1, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(10534, 1, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10535, 1, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(10536, 1, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(10537, 1, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(10538, 1, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(10539, 1, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(10540, 1, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10541, 1, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(10542, 1, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(10543, 1, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(10544, 1, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(10545, 1, 'Miscellaneous Can / Ref', 'miscellaneous/cancel_and_refund/index.php', '9', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(10546, 1, 'Purchase', '', '10', '1', '', 'fa fa-handshake-o', ''),
(10547, 1, 'Quotation Request', 'vendor/quotation_request/index.php', '10', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(10548, 1, ' Purchase Management', 'vendor/dashboard/index.php', '10', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(10549, 1, ' Cancel And Refund ', 'vendor/refund/index.php', '10', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(10550, 1, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(10551, 1, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(10552, 1, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(10553, 1, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(10554, 1, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(10555, 1, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(10556, 1, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(10557, 1, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(10558, 1, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(10559, 1, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10560, 1, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10561, 1, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10562, 1, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(10563, 1, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(10564, 1, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(10565, 1, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10566, 1, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(10567, 1, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(10568, 1, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(10569, 1, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(10570, 1, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(10571, 1, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(10572, 1, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(10573, 1, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(10574, 1, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(10575, 1, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(10576, 1, 'Training', 'dashboard/dashboard_main.php', '16', '2', 'Training', 'fa fa-laptop', ''),
(10577, 1, 'User Manual', 'dashboard/dashboard_main.php', '16', '2', 'Documentation home', 'fa fa-info', ''),
(10578, 1, 'Ticket Support', 'dashboard/dashboard_main.php', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(10579, 1, 'Data Backup', 'backup_installer/index.php', '16', '2', 'Data Backup', 'fa fa-download', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE IF NOT EXISTS `user_logs` (
  `log_id` int(100) NOT NULL,
  `login_id` int(50) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL,
  `logout_date` date NOT NULL,
  `logout_time` time NOT NULL,
  `status` varchar(200) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `user_ip` varchar(200) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_advance_master`
--

CREATE TABLE IF NOT EXISTS `vendor_advance_master` (
  `payment_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `vendor_type` varchar(200) NOT NULL,
  `vendor_type_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(222) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(2000) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `remark` text NOT NULL,
  `bank_id` int(11) NOT NULL,
  `payment_evidence_url` text NOT NULL,
  `clearance_status` varchar(200) NOT NULL,
  `created_at` int(11) NOT NULL,
  `ledger_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_estimate`
--

CREATE TABLE IF NOT EXISTS `vendor_estimate` (
  `estimate_id` int(100) NOT NULL,
  `estimate_type` varchar(100) NOT NULL,
  `estimate_type_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `vendor_type_id` int(50) NOT NULL,
  `remark` text NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `non_recoverable_taxes` varchar(100) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `other_charges` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` varchar(100) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `discount` decimal(50,2) NOT NULL,
  `our_commission` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `invoice_proof_url` varchar(500) NOT NULL,
  `invoice_id` varchar(300) NOT NULL,
  `due_date` date NOT NULL,
  `purchase_date` date NOT NULL,
  PRIMARY KEY (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_hotel_reply_master`
--

CREATE TABLE IF NOT EXISTS `vendor_hotel_reply_master` (
  `id` int(200) NOT NULL,
  `request_id` int(200) NOT NULL,
  `supplier_id` int(200) NOT NULL,
  `hotel_cost` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `enquiry_spec` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  `created_by` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_login`
--

CREATE TABLE IF NOT EXISTS `vendor_login` (
  `login_id` int(100) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_payment_master`
--

CREATE TABLE IF NOT EXISTS `vendor_payment_master` (
  `payment_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `vendor_type_id` int(100) NOT NULL,
  `estimate_type` varchar(300) NOT NULL,
  `estimate_type_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `remark` text NOT NULL,
  `bank_id` int(50) NOT NULL,
  `payment_evidence_url` text NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_refund_master`
--

CREATE TABLE IF NOT EXISTS `vendor_refund_master` (
  `refund_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `estimate_id` int(100) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_reply_master`
--

CREATE TABLE IF NOT EXISTS `vendor_reply_master` (
  `id` int(200) NOT NULL,
  `quotation_for` varchar(200) NOT NULL,
  `request_id` int(200) NOT NULL,
  `supplier_id` int(200) NOT NULL,
  `transport_cost` decimal(50,2) NOT NULL,
  `excursion_cost` decimal(50,2) NOT NULL,
  `visa_cost` decimal(50,2) NOT NULL,
  `hotel_cost` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `currency_code` int(200) NOT NULL,
  `enquiry_spec` text NOT NULL,
  `created_at` date NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_request_master`
--

CREATE TABLE IF NOT EXISTS `vendor_request_master` (
  `request_id` int(50) NOT NULL,
  `enquiry_id` int(100) NOT NULL,
  `emp_id` int(200) NOT NULL,
  `quotation_for` varchar(100) NOT NULL,
  `city_id` varchar(200) NOT NULL,
  `vendor_city_id` varchar(100) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `quotation_date` date NOT NULL,
  `airport_pickup` varchar(100) NOT NULL,
  `cab_type` varchar(100) NOT NULL,
  `transfer_type` varchar(100) NOT NULL,
  `enquiry_specification` text NOT NULL,
  `dynamic_fields` text NOT NULL,
  `hotel_entries` text NOT NULL,
  `dmc_entries` text NOT NULL,
  `transport_entries` text NOT NULL,
  `excursion_specification` text NOT NULL,
  `bid_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_response_entries`
--

CREATE TABLE IF NOT EXISTS `vendor_response_entries` (
  `response_id` int(100) NOT NULL,
  `entry_id` int(100) NOT NULL,
  `services` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  PRIMARY KEY (`response_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_type_master`
--

CREATE TABLE IF NOT EXISTS `vendor_type_master` (
  `id` int(50) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_type_master`
--

INSERT INTO `vendor_type_master` (`id`, `vendor_type`) VALUES
(1, 'Hotel Vendor'),
(2, 'Transport Vendor'),
(3, 'Car Rental Vendor'),
(4, 'DMC Vendor'),
(5, 'Visa Vendor'),
(6, 'Passport Vendor'),
(7, 'Ticket Vendor'),
(8, 'Excursion Vendor'),
(9, 'Insurance Vendor'),
(10, 'Train Ticket Vendor'),
(11, 'Other Vendor'),
(12, 'Cruise Vendor');

-- --------------------------------------------------------

--
-- Table structure for table `visa_crm_master`
--

CREATE TABLE IF NOT EXISTS `visa_crm_master` (
  `entry_id` int(11) NOT NULL,
  `country_id` varchar(200) NOT NULL,
  `visa_type` varchar(200) NOT NULL,
  `fees` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `time_taken` varchar(200) NOT NULL,
  `upload_url` varchar(200) NOT NULL,
  `upload_url2` varchar(200) NOT NULL,
  `list_of_documents` text NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visa_crm_master`
--

INSERT INTO `visa_crm_master` (`entry_id`, `country_id`, `visa_type`, `fees`, `markup`, `time_taken`, `upload_url`, `upload_url2`, `list_of_documents`) VALUES
(1, 'Afghanistan', 'Tourist Visa', '9000.00', '0.00', '8 Days', '../../uploads//Visa_document_required//2019//Jul//18//1563429796/invoice-May-2019.pdf', '../../uploads//Visa_document_required//2019//Jul//18//1563429919/invoice-Feb2019-WCT-INC.pdf', '<b><i>aadhat card</i></b><div><br></div>'),
(2, 'Afghanistan', 'Student Visa', '0.00', '0.00', '45', '', '', 'Adhar |Card<div>Pan Card</div>'),
(3, 'Algeria', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(4, 'Argentina', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(5, 'Armenia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(6, 'Australia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(7, 'Austria', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(8, 'United Arab Emirates (Uae)', 'Tourist Visa', '5000.00', '500.00', '6 Days', '', '', 'Passport Front Copy<div>Passport Back Copy<br></div>'),
(9, 'Turkey', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(10, 'Thailand', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(11, 'Taiwan', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(12, 'Shrilanka', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(13, 'Singapore', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(14, 'South Arabia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(15, 'Qatar', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(16, 'Combodia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(17, 'Hongkong', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(18, 'Indonesia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(19, 'Iran', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(20, 'Japan', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(21, 'Kuwait', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(22, 'Malaysia', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(23, 'Maldives', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(24, 'Myanmar Burma', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(25, 'Nepal', 'Tourist Visa', '0.00', '0.00', '', '', '', '\n1. Original travel document with at least 6 months? validity.\n2. One recent passport-size photograph\n3. Duly filled in and signed visa application form\n4. Self-signed sponsorship letter by a Nepalese national\n5. A copy of the citizenship certificate of the sponsor\nIf you do not have a sponsor letter the following additional document are required:\n6. Details of Hotel reservation\n7. Valid Air Ticket\n8. Latest Bank Statement\n9. Application letter & Form (Download)\n'),
(26, 'India', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(27, 'Albania', 'Business Visa', '0.00', '0.00', '', '', '', ''),
(28, 'Afghanistan', 'Business Visa', '0.00', '0.00', '', '', '', ' '),
(29, 'Algeria', 'Family Visa', '0.00', '0.00', '', '', '', ''),
(30, 'United Arab Emirates', 'Business Visa', '0.00', '0.00', '', '', '', ''),
(31, 'Afghanistan', 'Business Visa', '0.00', '0.00', '', '', '', ' '),
(32, 'India', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(33, 'United States', 'Employee Visa', '0.00', '0.00', '', '', '', ' '),
(34, 'India', 'Family Visa', '0.00', '0.00', '', '', '', ' '),
(35, 'Afghanistan', 'Business Visa', '0.00', '0.00', '', '', '', ' '),
(36, 'Afghanistan', 'Family Visa', '0.00', '0.00', '', '', '', ' '),
(37, 'Algeria', 'Family Visa', '0.00', '0.00', '', '', '', ' '),
(38, 'India', 'Family Visa', '0.00', '0.00', '', '', '', ' '),
(39, 'India', 'Family Visa', '0.00', '0.00', '', '', '', ' '),
(40, 'United Arab Emirates', 'Business Visa', '0.00', '0.00', '', '', '', ''),
(41, 'Bhutan', 'Business Visa', '0.00', '0.00', '', '', '', ''),
(42, 'Afghanistan', 'Business Visa', '0.00', '0.00', '', '', '', ''),
(43, 'China', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(44, 'Kenya', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(45, 'United States', 'Tourist Visa', '0.00', '0.00', '', '', '', ''),
(46, 'United Kingdom', '90 Days', '5000.00', '200.00', '4 Days', '../../uploads//emp_photo_proof//2018//Dec//28//1545976234/Online Booking (1).pdf', '', ' '),
(47, 'India', 'Family Visa', '500000.00', '100.00', '', '', '', '1-Aadhar Card<div>2-Voting Card</div><div>3-License</div>'),
(48, 'Zambia', 'Business Visa', '0.00', '0.00', '', '', '', ' '),
(49, 'Zimbabwe', 'Tourist Visa', '15000.00', '2000.00', '10 Days', '', '', '1-Aadhar Card<div>2-PAN Card</div><div>3-Voting Card</div>'),
(50, 'India', 'Family Visa', '15000.00', '20.00', '10 Days', '', '', '1- Aadhar Card<div>2- PAN Card</div><div>3- Passport</div><div>4- Visa</div>'),
(51, 'Jamaica', 'Tourist Visa', '0.00', '0.00', '1 Month', '', '', ' '),
(52, 'Afghanistan', 'Family Visa', '25000.00', '5000.00', '1 Month', '', '', ' '),
(53, 'Afghanistan', 'Transit Visa', '7000.00', '800.00', '2 Days', '', '', '<h3><ol><li>dfgdfgg</li><li>fghfghfg</li><li>dfsdf</li><li>df</li></ol></h3>');

-- --------------------------------------------------------

--
-- Table structure for table `visa_master`
--

CREATE TABLE IF NOT EXISTS `visa_master` (
  `visa_id` int(100) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `visa_issue_amount` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `taxation_id` int(50) NOT NULL,
  `service_tax` varchar(100) NOT NULL,
  `service_tax_subtotal` decimal(50,2) NOT NULL,
  `due_date` date NOT NULL,
  `visa_total_cost` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`visa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_master_entries`
--

CREATE TABLE IF NOT EXISTS `visa_master_entries` (
  `entry_id` int(100) NOT NULL,
  `visa_id` int(100) NOT NULL,
  `honorific` varchar(100) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_type` varchar(200) NOT NULL,
  `passport_id` varchar(200) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `nationality` varchar(200) NOT NULL,
  `received_documents` text NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_payment_master`
--

CREATE TABLE IF NOT EXISTS `visa_payment_master` (
  `payment_id` int(100) NOT NULL,
  `visa_id` int(50) NOT NULL,
  `branch_admin_id` int(200) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_refund_entries`
--

CREATE TABLE IF NOT EXISTS `visa_refund_entries` (
  `id` int(50) NOT NULL,
  `refund_id` int(50) NOT NULL,
  `entry_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_refund_master`
--

CREATE TABLE IF NOT EXISTS `visa_refund_master` (
  `refund_id` int(50) NOT NULL,
  `visa_id` int(50) NOT NULL,
  `financial_year_id` int(50) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `bank_id` int(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_status_entries`
--

CREATE TABLE IF NOT EXISTS `visa_status_entries` (
  `id` int(11) NOT NULL,
  `booking_type` varchar(300) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `doc_status` varchar(300) NOT NULL,
  `traveler_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_supplier_payment`
--

CREATE TABLE IF NOT EXISTS `visa_supplier_payment` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(300) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `bank_id` varchar(100) NOT NULL,
  `clearance_status` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visa_type_master`
--

CREATE TABLE IF NOT EXISTS `visa_type_master` (
  `visa_type_id` int(50) NOT NULL,
  `visa_type` varchar(300) NOT NULL,
  PRIMARY KEY (`visa_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visa_type_master`
--

INSERT INTO `visa_type_master` (`visa_type_id`, `visa_type`) VALUES
(1, 'Tourist Visa'),
(2, 'Business Visa'),
(3, 'Student Visa'),
(4, 'Exchange visitor Visa'),
(5, 'Transit Visa'),
(6, '30 Days Tourist Visa'),
(7, '96 Hour Transit Visa'),
(8, '90 Day Visit Visa'),
(9, 'Single Entry Long Term Visa: 90 Days'),
(10, 'Multi-Entry Long Term Visa: 90 Days'),
(11, 'Multi-Entry Short Term Visa: 30 Days');

-- --------------------------------------------------------

--
-- Table structure for table `visa_vendor`
--

CREATE TABLE IF NOT EXISTS `visa_vendor` (
  `vendor_id` int(100) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `city_id` int(200) NOT NULL,
  `state_id` int(200) NOT NULL,
  `side` varchar(200) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
