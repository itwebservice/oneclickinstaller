<?php 

include "../../model/model.php";

include "../../model/attractions_offers_enquiry/attraction_images.php";
$attraction_images= new attraction_images;
$attraction_images->update();
?>